
-- Dump of TYPO3 Connection "Default"
-- MySQL dump 10.19  Distrib 10.3.29-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: db    Database: db
-- ------------------------------------------------------
-- Server version	10.3.30-MariaDB-1:10.3.30+maria~focal-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `backend_layout`
--

DROP TABLE IF EXISTS `backend_layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backend_layout` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `config` text NOT NULL,
  `icon` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_layout`
--

LOCK TABLES `backend_layout` WRITE;
/*!40000 ALTER TABLE `backend_layout` DISABLE KEYS */;
/*!40000 ALTER TABLE `backend_layout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_dashboards`
--

DROP TABLE IF EXISTS `be_dashboards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_dashboards` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `identifier` varchar(120) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `title` varchar(120) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `widgets` text COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_dashboards`
--

LOCK TABLES `be_dashboards` WRITE;
/*!40000 ALTER TABLE `be_dashboards` DISABLE KEYS */;
INSERT INTO `be_dashboards` VALUES (1,0,1633586401,1633586401,1,0,0,0,0,'e03f4772850a5196ac12827aca28b5ca22369aa6','My dashboard','{\"0b07d07cdb5c0d4bac40d94df95f217e782e9db9\":{\"identifier\":\"t3information\"},\"c2c591de8cedd1f6a8f1e1d99bc4908de014d61f\":{\"identifier\":\"t3news\"},\"28f94dfda6be78c710093ac34d6d8075269bdd5e\":{\"identifier\":\"docGettingStarted\"}}');
/*!40000 ALTER TABLE `be_dashboards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_groups`
--

DROP TABLE IF EXISTS `be_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `non_exclude_fields` text DEFAULT NULL,
  `explicit_allowdeny` text DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `custom_options` text DEFAULT NULL,
  `db_mountpoints` text DEFAULT NULL,
  `pagetypes_select` text DEFAULT NULL,
  `tables_select` text DEFAULT NULL,
  `tables_modify` text DEFAULT NULL,
  `groupMods` text DEFAULT NULL,
  `file_mountpoints` text DEFAULT NULL,
  `file_permissions` text DEFAULT NULL,
  `lockToDomain` varchar(50) NOT NULL DEFAULT '',
  `TSconfig` text DEFAULT NULL,
  `subgroup` text DEFAULT NULL,
  `workspace_perms` smallint(6) NOT NULL DEFAULT 1,
  `category_perms` text DEFAULT NULL,
  `availableWidgets` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_groups`
--

LOCK TABLES `be_groups` WRITE;
/*!40000 ALTER TABLE `be_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `be_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_users`
--

DROP TABLE IF EXISTS `be_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `username` varchar(50) NOT NULL DEFAULT '',
  `avatar` int(10) unsigned NOT NULL DEFAULT 0,
  `password` varchar(100) NOT NULL DEFAULT '',
  `admin` smallint(5) unsigned NOT NULL DEFAULT 0,
  `usergroup` varchar(255) NOT NULL DEFAULT '',
  `lang` varchar(6) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `db_mountpoints` text DEFAULT NULL,
  `options` smallint(5) unsigned NOT NULL DEFAULT 0,
  `realName` varchar(80) NOT NULL DEFAULT '',
  `userMods` text DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `uc` mediumblob DEFAULT NULL,
  `file_mountpoints` text DEFAULT NULL,
  `file_permissions` text DEFAULT NULL,
  `workspace_perms` smallint(6) NOT NULL DEFAULT 1,
  `lockToDomain` varchar(50) NOT NULL DEFAULT '',
  `disableIPlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `TSconfig` text DEFAULT NULL,
  `lastlogin` int(10) unsigned NOT NULL DEFAULT 0,
  `createdByAction` int(11) NOT NULL DEFAULT 0,
  `usergroup_cached_list` text DEFAULT NULL,
  `workspace_id` int(11) NOT NULL DEFAULT 0,
  `category_perms` text DEFAULT NULL,
  `password_reset_token` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `username` (`username`),
  KEY `parent` (`pid`,`deleted`,`disable`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_users`
--

LOCK TABLES `be_users` WRITE;
/*!40000 ALTER TABLE `be_users` DISABLE KEYS */;
INSERT INTO `be_users` VALUES (1,0,1634545462,1550653930,0,0,0,0,0,NULL,'admin',0,'$argon2i$v=19$m=65536,t=16,p=1$eFNaZS5zUm0ubmguSXhSUA$foOpAgOnfNOUoswnTTHJ7PfEp2dJnbi/tYf+Vy8cXM4',1,'','','',NULL,0,'',NULL,'','a:39:{s:14:\"interfaceSetup\";s:0:\"\";s:10:\"moduleData\";a:20:{s:10:\"web_layout\";a:3:{s:8:\"function\";s:1:\"1\";s:8:\"language\";s:1:\"0\";s:21:\"tt_content_showHidden\";s:1:\"1\";}s:8:\"web_list\";a:1:{s:15:\"bigControlPanel\";s:1:\"1\";}s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";a:0:{}s:10:\"FormEngine\";a:2:{i:0;a:5:{s:32:\"5a483b631b0967a26c7077f79b2bf502\";a:4:{i:0;s:0:\"\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:1015;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:36:\"&edit%5Btt_content%5D%5B1015%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:1015;s:3:\"pid\";i:227;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"322c6aa036860ff9611cc6c428f56180\";a:4:{i:0;s:12:\"participants\";i:1;a:5:{s:4:\"edit\";a:1:{s:9:\"fe_groups\";a:1:{i:3;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:32:\"&edit%5Bfe_groups%5D%5B3%5D=edit\";i:3;a:5:{s:5:\"table\";s:9:\"fe_groups\";s:3:\"uid\";i:3;s:3:\"pid\";i:225;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"3338380b8b1dbd26b7a7487c0099813b\";a:4:{i:0;s:23:\"Event 1, 08.12.21 17:08\";i:1;a:5:{s:4:\"edit\";a:1:{s:29:\"tx_grevman_domain_model_event\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:52:\"&edit%5Btx_grevman_domain_model_event%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:29:\"tx_grevman_domain_model_event\";s:3:\"uid\";i:1;s:3:\"pid\";i:224;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"b67eeb013afba640ffa672ec0cba1429\";a:4:{i:0;s:23:\"Event 1, 16.02.22 17:08\";i:1;a:5:{s:4:\"edit\";a:1:{s:29:\"tx_grevman_domain_model_event\";a:1:{i:50;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:53:\"&edit%5Btx_grevman_domain_model_event%5D%5B50%5D=edit\";i:3;a:5:{s:5:\"table\";s:29:\"tx_grevman_domain_model_event\";s:3:\"uid\";i:50;s:3:\"pid\";i:224;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"eed2902fe26944fd1a97520e84fe9de4\";a:4:{i:0;s:33:\"participant1, Participant1, Last1\";i:1;a:5:{s:4:\"edit\";a:1:{s:8:\"fe_users\";a:1:{i:10;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:32:\"&edit%5Bfe_users%5D%5B10%5D=edit\";i:3;a:5:{s:5:\"table\";s:8:\"fe_users\";s:3:\"uid\";i:10;s:3:\"pid\";i:225;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}}i:1;s:32:\"eed2902fe26944fd1a97520e84fe9de4\";}s:16:\"opendocs::recent\";a:8:{s:32:\"bdd5feb796f24eef5a90e18f476ced8d\";a:4:{i:0;s:33:\"participant1, Participant1, Last1\";i:1;a:5:{s:4:\"edit\";a:1:{s:8:\"fe_users\";a:1:{s:14:\"10,11,12,13,16\";s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";s:5:\"email\";s:6:\"noView\";N;}i:2;s:70:\"&edit%5Bfe_users%5D%5B10%2C11%2C12%2C13%2C16%5D=edit&columnsOnly=email\";i:3;a:5:{s:5:\"table\";s:8:\"fe_users\";s:3:\"uid\";i:10;s:3:\"pid\";i:225;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"a7e00bf9038852cc317820c754117645\";a:4:{i:0;s:33:\"participant1, Participant1, Last1\";i:1;a:5:{s:4:\"edit\";a:1:{s:8:\"fe_users\";a:1:{s:14:\"10,16,11,12,13\";s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";s:5:\"email\";s:6:\"noView\";N;}i:2;s:70:\"&edit%5Bfe_users%5D%5B10%2C16%2C11%2C12%2C13%5D=edit&columnsOnly=email\";i:3;a:5:{s:5:\"table\";s:8:\"fe_users\";s:3:\"uid\";i:10;s:3:\"pid\";i:225;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"7ad1ab903df888dbfd5a8f841524b38c\";a:4:{i:0;s:17:\"leader1, Trainer1\";i:1;a:5:{s:4:\"edit\";a:1:{s:8:\"fe_users\";a:1:{s:5:\"14,15\";s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";s:5:\"email\";s:6:\"noView\";N;}i:2;s:55:\"&edit%5Bfe_users%5D%5B14%2C15%5D=edit&columnsOnly=email\";i:3;a:5:{s:5:\"table\";s:8:\"fe_users\";s:3:\"uid\";i:14;s:3:\"pid\";i:226;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"e065cbbe13b4f747e23e397a132cd407\";a:4:{i:0;s:5:\"Login\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:227;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:30:\"&edit%5Bpages%5D%5B227%5D=edit\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:227;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"a6cd83422dadbf20adb87eb1a860acd4\";a:4:{i:0;s:9:\"Messenger\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:234;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:30:\"&edit%5Bpages%5D%5B234%5D=edit\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:234;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"8618f6a2ee56eaf286b0e3b6e3c83b22\";a:4:{i:0;s:58:\"participant1, Participant1, Last1, Event 1, 08.06.22 17:08\";i:1;a:5:{s:4:\"edit\";a:1:{s:36:\"tx_grevman_domain_model_registration\";a:1:{i:154;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:61:\"&edit%5Btx_grevman_domain_model_registration%5D%5B154%5D=edit\";i:3;a:5:{s:5:\"table\";s:36:\"tx_grevman_domain_model_registration\";s:3:\"uid\";i:154;s:3:\"pid\";i:224;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"3338380b8b1dbd26b7a7487c0099813b\";a:4:{i:0;s:6:\"event1\";i:1;a:5:{s:4:\"edit\";a:1:{s:29:\"tx_grevman_domain_model_event\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:52:\"&edit%5Btx_grevman_domain_model_event%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:29:\"tx_grevman_domain_model_event\";s:3:\"uid\";i:1;s:3:\"pid\";i:224;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"bb446d40a9fc8f71a123d2e2c73cff77\";a:4:{i:0;s:7:\"Event 1\";i:1;a:5:{s:4:\"edit\";a:1:{s:29:\"tx_grevman_domain_model_event\";a:1:{i:45;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:53:\"&edit%5Btx_grevman_domain_model_event%5D%5B45%5D=edit\";i:3;a:5:{s:5:\"table\";s:29:\"tx_grevman_domain_model_event\";s:3:\"uid\";i:45;s:3:\"pid\";i:224;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}}s:4:\"list\";a:3:{s:32:\"tx_timelog_domain_model_interval\";s:1:\"0\";s:31:\"tx_timelog_domain_model_project\";s:1:\"0\";s:33:\"tx_timelog_domain_model_taskgroup\";s:1:\"0\";}s:6:\"web_ts\";a:11:{s:8:\"function\";s:88:\"TYPO3\\CMS\\Tstemplate\\Controller\\TypoScriptTemplateConstantEditorModuleFunctionController\";s:19:\"constant_editor_cat\";s:23:\"pizpalue: customer base\";s:15:\"ts_browser_type\";s:5:\"const\";s:16:\"ts_browser_const\";s:1:\"0\";s:19:\"ts_browser_fixedLgd\";s:1:\"1\";s:23:\"ts_browser_showComments\";s:1:\"1\";s:25:\"tsbrowser_depthKeys_setup\";a:120:{s:24:\"page.jsFooterInline.1020\";i:1;s:24:\"page.jsFooterInline.1030\";i:1;s:14:\"module.tx_form\";i:1;s:23:\"module.tx_form.settings\";i:1;s:42:\"module.tx_form.settings.yamlConfigurations\";i:1;s:9:\"page.1.10\";i:1;s:18:\"tt_content.stdWrap\";i:1;s:24:\"plugin.tx_ttaddress.view\";i:1;s:42:\"plugin.tx_ttaddress.view.templateRootPaths\";i:1;s:41:\"plugin.tx_ttaddress.view.partialRootPaths\";i:1;s:40:\"plugin.tx_ttaddress.view.layoutRootPaths\";i:1;s:26:\"lib.dynamicContentSlide.20\";i:1;s:20:\"lib.dynamicContent.5\";i:1;s:35:\"lib.dynamicContent.5.colPos.cObject\";i:1;s:43:\"lib.dynamicContent.5.colPos.cObject.ifEmpty\";i:1;s:51:\"lib.dynamicContent.5.colPos.cObject.ifEmpty.cObject\";i:1;s:57:\"lib.dynamicContent.5.colPos.cObject.ifEmpty.cObject.value\";i:1;s:34:\"lib.dynamicContent.5.slide.cObject\";i:1;s:43:\"lib.dynamicContent.5.slide.cObject.override\";i:1;s:46:\"lib.dynamicContent.5.slide.cObject.override.if\";i:1;s:55:\"lib.dynamicContent.5.slide.cObject.override.if.isInList\";i:1;s:26:\"lib.contentElement.gallery\";i:1;s:23:\"plugin.tx_form.settings\";i:1;s:42:\"plugin.tx_form.settings.yamlConfigurations\";i:1;s:44:\"lib.contentElement.settings.responsiveimages\";i:1;s:23:\"tt_content.ce-container\";i:1;s:34:\"plugin.tx_news.settings.list.media\";i:1;s:40:\"plugin.tx_news.settings.list.media.image\";i:1;s:29:\"plugin.tx_news.settings.media\";i:1;s:36:\"plugin.tx_news.view.partialRootPaths\";i:1;s:35:\"plugin.tx_news.view.layoutRootPaths\";i:1;s:15:\"plugin.pizpalue\";i:1;s:27:\"plugin.pizpalue._LOCAL_LANG\";i:1;s:35:\"plugin.pizpalue._LOCAL_LANG.default\";i:1;s:39:\"plugin.tx_bootstrap_package._LOCAL_LANG\";i:1;s:47:\"plugin.tx_bootstrap_package._LOCAL_LANG.default\";i:1;s:36:\"lib.parseFunc_RTE.tags.link.typolink\";i:1;s:46:\"lib.parseFunc_RTE.tags.link.typolink.parameter\";i:1;s:37:\"lib.parseFunc_RTE.tags.link.parseFunc\";i:1;s:33:\"lib.parseFunc_RTE.tags.a.typolink\";i:1;s:43:\"lib.parseFunc_RTE.tags.a.typolink.extTarget\";i:1;s:52:\"lib.parseFunc_RTE.tags.a.typolink.extTarget.override\";i:1;s:34:\"lib.parseFunc_RTE.tags.a.parseFunc\";i:1;s:68:\"lib.contentElement.settings.responsiveimages.noFrameVariants.default\";i:1;s:65:\"lib.contentElement.settings.responsiveimages.pageVariants.default\";i:1;s:27:\"plugin.tx_fluxelements.view\";i:1;s:43:\"plugin.tx_fluxelements.view.layoutRootPaths\";i:1;s:44:\"plugin.tx_fluxelements.view.partialRootPaths\";i:1;s:45:\"plugin.tx_fluxelements.view.templateRootPaths\";i:1;s:29:\"plugin.tx_news._LOCAL_LANG.es\";i:1;s:11:\"lib.tx_news\";i:1;s:23:\"lib.tt_content.shortcut\";i:1;s:18:\"tt_content.list.20\";i:1;s:24:\"plugin.tx_news.variables\";i:1;s:28:\"plugin.tx_news.settings.list\";i:1;s:45:\"lib.containerContentElement.templateRootPaths\";i:1;s:61:\"lib.contentElement.settings.responsiveimages.variants.default\";i:1;s:59:\"lib.contentElement.settings.responsiveimages.variants.large\";i:1;s:60:\"lib.contentElement.settings.responsiveimages.variants.medium\";i:1;s:59:\"lib.contentElement.settings.responsiveimages.variants.small\";i:1;s:64:\"lib.contentElement.settings.responsiveimages.variants.extrasmall\";i:1;s:27:\"tt_content.shortcut.20.conf\";i:1;s:53:\"tt_content.shortcut.20.conf.tx_news_domain_model_news\";i:1;s:29:\"tt_content.shortcut.variables\";i:1;s:39:\"tt_content.shortcut.variables.shortcuts\";i:1;s:44:\"tt_content.shortcut.variables.shortcuts.conf\";i:1;s:52:\"tt_content.shortcut.variables.shortcuts.conf.pages.5\";i:1;s:82:\"tt_content.shortcut.variables.shortcuts.conf.pages.5.tt_content_shortcut_recursive\";i:1;s:46:\"tt_content.shortcut.variables.shortcuts.source\";i:1;s:36:\"tt_content.pp_modal_dialog.variables\";i:1;s:46:\"tt_content.pp_modal_dialog.variables.shortcuts\";i:1;s:51:\"tt_content.pp_modal_dialog.variables.shortcuts.conf\";i:1;s:57:\"tt_content.pp_modal_dialog.variables.shortcuts.conf.pages\";i:1;s:53:\"tt_content.pp_modal_dialog.variables.shortcuts.source\";i:1;s:49:\"tt_content.pp_modal_dialog.variables.shortcuts.20\";i:1;s:56:\"tt_content.pp_modal_dialog.variables.shortcuts.20.source\";i:1;s:54:\"tt_content.pp_modal_dialog.variables.shortcuts.20.conf\";i:1;s:84:\"lib.contentElement.settings.responsiveimages.contentelements.textpic.left.multiplier\";i:1;s:76:\"lib.contentElement.settings.responsiveimages.contentelements.pp_modal_dialog\";i:1;s:68:\"lib.contentElement.settings.responsiveimages.contentelements.textpic\";i:1;s:73:\"lib.contentElement.settings.responsiveimages.contentelements.textpic.left\";i:1;s:81:\"lib.contentElement.settings.responsiveimages.contentelements.textpic.left.gutters\";i:1;s:70:\"lib.contentElement.settings.responsiveimages.backendlayout.2_columns.0\";i:1;s:81:\"lib.contentElement.settings.responsiveimages.backendlayout.2_columns.0.multiplier\";i:1;s:78:\"lib.contentElement.settings.responsiveimages.backendlayout.2_columns.0.gutters\";i:1;s:78:\"lib.contentElement.settings.responsiveimages.backendlayout.subnavigation_right\";i:1;s:80:\"lib.contentElement.settings.responsiveimages.backendlayout.subnavigation_right.0\";i:1;s:91:\"lib.contentElement.settings.responsiveimages.backendlayout.subnavigation_right.0.multiplier\";i:1;s:88:\"lib.contentElement.settings.responsiveimages.backendlayout.subnavigation_right.0.gutters\";i:1;s:43:\"lib.contentElement.settings.gallery.columns\";i:1;s:18:\"page.headerData.10\";i:1;s:24:\"page.includeJSFooterlibs\";i:1;s:32:\"plugin.tx_felogin_login.settings\";i:1;s:21:\"lib.dynamicContent.10\";i:1;s:29:\"lib.dynamicContent.10.stdWrap\";i:1;s:33:\"lib.contentElement.dataProcessing\";i:1;s:32:\"tt_content.list.20.powermail_pi1\";i:1;s:32:\"tt_content.list.20.powermail_pi2\";i:1;s:23:\"tt_content.default.wrap\";i:1;s:36:\"lib.containerContentElement.settings\";i:1;s:54:\"lib.containerContentElement.settings.containerElements\";i:1;s:14:\"styles.content\";i:1;s:18:\"styles.content.get\";i:1;s:25:\"styles.content.get.select\";i:1;s:46:\"lib.parseFunc_RTE.externalBlocks.table.stdWrap\";i:1;s:42:\"lib.parseFunc.nonTypoTagStdWrap.HTMLparser\";i:1;s:32:\"lib.parseFunc_RTE.externalBlocks\";i:1;s:61:\"lib.parseFunc_RTE.externalBlocks.table.stdWrap.parseFunc.tags\";i:1;s:43:\"lib.parseFunc_RTE.externalBlocks.pp:gettext\";i:1;s:40:\"lib.parseFunc_RTE.externalBlocks.gettext\";i:1;s:22:\"lib.parseFunc_RTE.tags\";i:1;s:18:\"lib.parseFunc.tags\";i:1;s:35:\"lib.parseFunc_RTE.externalBlocks.ol\";i:1;s:43:\"lib.parseFunc_RTE.externalBlocks.ol.stdWrap\";i:1;s:35:\"lib.parseFunc_RTE.externalBlocks.ul\";i:1;s:43:\"lib.parseFunc_RTE.externalBlocks.pp-gettext\";i:1;s:51:\"lib.parseFunc_RTE.externalBlocks.pp-gettext.stdWrap\";i:1;s:6:\"plugin\";i:1;s:26:\"plugin.tx_news._LOCAL_LANG\";i:1;s:10:\"tt_content\";i:1;}s:20:\"tsbrowser_conditions\";a:7:{s:32:\"4f5b345c1e805a673ddc410db8568348\";s:0:\"\";s:32:\"8d603c08ff24469dcd95c7cd95556376\";s:0:\"\";s:32:\"31a5ee3355ea1fe5e2136f0597c24dd8\";s:0:\"\";s:32:\"5d872687d14b03945fefc8f61eedd660\";s:0:\"\";s:32:\"8d5162ca104fa7e79fe80fd92bb657fb\";s:0:\"\";s:32:\"ffb7c399fe1d1c6c494fdaf47b419bd4\";s:8:\"[1 == 1]\";s:32:\"23112cc5ca5eddcbc1338b155c8beb7c\";s:0:\"\";}s:25:\"tsbrowser_depthKeys_const\";a:16:{s:14:\"styles.content\";i:1;s:20:\"pizpalue.animation.1\";i:1;s:19:\"plugin.tx_news.view\";i:1;s:23:\"plugin.tx_news.view.twb\";i:1;s:33:\"plugin.bootstrap_package.settings\";i:1;s:20:\"page.theme.copyright\";i:1;s:19:\"page.theme.language\";i:1;s:23:\"plugin.tx_bookmarkpages\";i:1;s:32:\"plugin.tx_bookmarkpages.settings\";i:1;s:36:\"plugin.tx_containerelements.settings\";i:1;s:50:\"plugin.tx_containerelements.settings.imageVariants\";i:1;s:57:\"plugin.tx_containerelements.settings.imageVariants.gutter\";i:1;s:66:\"plugin.tx_containerelements.settings.imageVariants.gutter.variants\";i:1;s:6:\"plugin\";i:1;s:19:\"plugin.tx_ttaddress\";i:1;s:24:\"plugin.tx_ttaddress.view\";i:1;}s:24:\"ts_analyzer_checkLinenum\";s:1:\"1\";s:23:\"ts_analyzer_checkSyntax\";s:1:\"1\";}s:9:\"tx_beuser\";s:530:\"O:40:\"TYPO3\\CMS\\Beuser\\Domain\\Model\\ModuleData\":2:{s:9:\"\0*\0demand\";O:36:\"TYPO3\\CMS\\Beuser\\Domain\\Model\\Demand\":12:{s:11:\"\0*\0userName\";s:0:\"\";s:11:\"\0*\0userType\";i:0;s:9:\"\0*\0status\";i:0;s:9:\"\0*\0logins\";i:0;s:19:\"\0*\0backendUserGroup\";N;s:6:\"\0*\0uid\";N;s:16:\"\0*\0_localizedUid\";N;s:15:\"\0*\0_languageUid\";N;s:16:\"\0*\0_versionedUid\";N;s:6:\"\0*\0pid\";N;s:61:\"\0TYPO3\\CMS\\Extbase\\DomainObject\\AbstractDomainObject\0_isClone\";b:0;s:69:\"\0TYPO3\\CMS\\Extbase\\DomainObject\\AbstractDomainObject\0_cleanProperties\";a:0:{}}s:18:\"\0*\0compareUserList\";a:0:{}}\";s:13:\"system_config\";a:9:{s:4:\"tree\";s:3:\"tca\";s:11:\"regexSearch\";b:0;s:8:\"node_tca\";a:132:{s:37:\"tt_content.columns.pi_flexform.config\";i:1;s:40:\"tt_content.columns.pi_flexform.config.ds\";i:1;s:31:\"tt_content.columns.CType.config\";i:1;s:37:\"tt_content.columns.CType.config.items\";i:1;s:14:\"pages.palettes\";i:1;s:11:\"pages.types\";i:1;s:13:\"pages.types.4\";i:1;s:32:\"tt_content.columns.colPos.config\";i:1;s:38:\"tt_content.columns.colPos.config.items\";i:1;s:31:\"tt_content.columns.image.config\";i:1;s:54:\"tt_content.columns.image.config.overrideChildTca.types\";i:1;s:56:\"tt_content.columns.image.config.overrideChildTca.columns\";i:1;s:66:\"tt_content.columns.image.config.overrideChildTca.columns.uid_local\";i:1;s:73:\"tt_content.columns.image.config.overrideChildTca.columns.uid_local.config\";i:1;s:84:\"tt_content.columns.image.config.overrideChildTca.columns.uid_local.config.appearance\";i:1;s:56:\"tt_content.columns.image.config.overrideChildTca.types.0\";i:1;s:56:\"tt_content.columns.image.config.overrideChildTca.types.1\";i:1;s:23:\"sys_file_reference.ctrl\";i:1;s:56:\"tt_content.columns.image.config.overrideChildTca.types.2\";i:1;s:56:\"tt_content.columns.image.config.overrideChildTca.types.3\";i:1;s:56:\"tt_content.columns.image.config.overrideChildTca.types.4\";i:1;s:56:\"tt_content.columns.image.config.overrideChildTca.types.5\";i:1;s:27:\"sys_file_reference.palettes\";i:1;s:47:\"sys_file_reference.palettes.videoOverlayPalette\";i:1;s:43:\"tt_content.types.textmedia.columnsOverrides\";i:1;s:50:\"tt_content.types.textmedia.columnsOverrides.assets\";i:1;s:57:\"tt_content.types.textmedia.columnsOverrides.assets.config\";i:1;s:74:\"tt_content.types.textmedia.columnsOverrides.assets.config.overrideChildTca\";i:1;s:82:\"tt_content.types.textmedia.columnsOverrides.assets.config.overrideChildTca.columns\";i:1;s:87:\"tt_content.types.textmedia.columnsOverrides.assets.config.overrideChildTca.columns.crop\";i:1;s:94:\"tt_content.types.textmedia.columnsOverrides.assets.config.overrideChildTca.columns.crop.config\";i:1;s:107:\"tt_content.types.textmedia.columnsOverrides.assets.config.overrideChildTca.columns.crop.config.cropVariants\";i:1;s:32:\"tt_content.columns.assets.config\";i:1;s:49:\"tt_content.columns.assets.config.overrideChildTca\";i:1;s:57:\"tt_content.columns.assets.config.overrideChildTca.columns\";i:1;s:67:\"tt_content.columns.assets.config.overrideChildTca.columns.uid_local\";i:1;s:74:\"tt_content.columns.assets.config.overrideChildTca.columns.uid_local.config\";i:1;s:85:\"tt_content.columns.assets.config.overrideChildTca.columns.uid_local.config.appearance\";i:1;s:39:\"tt_content.types.table.columnsOverrides\";i:1;s:48:\"tt_content.types.table.columnsOverrides.bodytext\";i:1;s:55:\"tt_content.types.table.columnsOverrides.bodytext.config\";i:1;s:37:\"tt_content.columns.frame_class.config\";i:1;s:46:\"tt_content.types.ce_container.columnsOverrides\";i:1;s:58:\"tt_content.types.ce_container.columnsOverrides.frame_class\";i:1;s:65:\"tt_content.types.ce_container.columnsOverrides.frame_class.config\";i:1;s:27:\"tt_content.palettes.headers\";i:1;s:27:\"tt_content.palettes.general\";i:1;s:42:\"tt_content.columns.CType.config.itemGroups\";i:1;s:45:\"tt_content.containerConfiguration.ce_columns2\";i:1;s:38:\"tx_vinfo_domain_model_business.columns\";i:1;s:43:\"tx_vinfo_domain_model_business.columns.vote\";i:1;s:50:\"tx_vinfo_domain_model_business.columns.vote.config\";i:1;s:35:\"tx_vinfo_domain_model_business.vote\";i:1;s:42:\"tx_vinfo_domain_model_business.vote.config\";i:1;s:61:\"tx_vinfo_domain_model_business.columns.vote.config.renderType\";i:1;s:35:\"tx_vinfo_domain_model_query.columns\";i:1;s:42:\"tx_vinfo_domain_model_query.columns.status\";i:1;s:49:\"tx_vinfo_domain_model_query.columns.status.config\";i:1;s:55:\"tx_vinfo_domain_model_query.columns.status.config.items\";i:1;s:31:\"tx_news_domain_model_news.types\";i:1;s:33:\"tx_news_domain_model_news.types.0\";i:1;s:50:\"tx_news_domain_model_news.types.0.columnsOverrides\";i:1;s:60:\"tx_news_domain_model_news.types.0.columnsOverrides.fal_media\";i:1;s:67:\"tx_news_domain_model_news.types.0.columnsOverrides.fal_media.config\";i:1;s:84:\"tx_news_domain_model_news.types.0.columnsOverrides.fal_media.config.overrideChildTca\";i:1;s:92:\"tx_news_domain_model_news.types.0.columnsOverrides.fal_media.config.overrideChildTca.columns\";i:1;s:97:\"tx_news_domain_model_news.types.0.columnsOverrides.fal_media.config.overrideChildTca.columns.crop\";i:1;s:104:\"tx_news_domain_model_news.types.0.columnsOverrides.fal_media.config.overrideChildTca.columns.crop.config\";i:1;s:117:\"tx_news_domain_model_news.types.0.columnsOverrides.fal_media.config.overrideChildTca.columns.crop.config.cropVariants\";i:1;s:145:\"tx_news_domain_model_news.types.0.columnsOverrides.fal_media.config.overrideChildTca.columns.crop.config.cropVariants.default.allowedAspectRatios\";i:1;s:134:\"tx_news_domain_model_news.types.0.columnsOverrides.fal_media.config.overrideChildTca.columns.crop.config.cropVariants.default.cropArea\";i:1;s:149:\"tx_news_domain_model_news.types.0.columnsOverrides.fal_media.config.overrideChildTca.columns.crop.config.cropVariants.default.allowedAspectRatios.1:1\";i:1;s:149:\"tx_news_domain_model_news.types.0.columnsOverrides.fal_media.config.overrideChildTca.columns.crop.config.cropVariants.default.allowedAspectRatios.1:2\";i:1;s:149:\"tx_news_domain_model_news.types.0.columnsOverrides.fal_media.config.overrideChildTca.columns.crop.config.cropVariants.default.allowedAspectRatios.2:1\";i:1;s:149:\"tx_news_domain_model_news.types.0.columnsOverrides.fal_media.config.overrideChildTca.columns.crop.config.cropVariants.default.allowedAspectRatios.3:4\";i:1;s:149:\"tx_news_domain_model_news.types.0.columnsOverrides.fal_media.config.overrideChildTca.columns.crop.config.cropVariants.default.allowedAspectRatios.4:3\";i:1;s:150:\"tx_news_domain_model_news.types.0.columnsOverrides.fal_media.config.overrideChildTca.columns.crop.config.cropVariants.default.allowedAspectRatios.9:16\";i:1;s:39:\"tt_content.types.image.columnsOverrides\";i:1;s:45:\"tt_content.types.image.columnsOverrides.image\";i:1;s:52:\"tt_content.types.image.columnsOverrides.image.config\";i:1;s:69:\"tt_content.types.image.columnsOverrides.image.config.overrideChildTca\";i:1;s:77:\"tt_content.types.image.columnsOverrides.image.config.overrideChildTca.columns\";i:1;s:82:\"tt_content.types.image.columnsOverrides.image.config.overrideChildTca.columns.crop\";i:1;s:89:\"tt_content.types.image.columnsOverrides.image.config.overrideChildTca.columns.crop.config\";i:1;s:102:\"tt_content.types.image.columnsOverrides.image.config.overrideChildTca.columns.crop.config.cropVariants\";i:1;s:110:\"tt_content.types.image.columnsOverrides.image.config.overrideChildTca.columns.crop.config.cropVariants.default\";i:1;s:24:\"tt_content.columns.image\";i:1;s:21:\"tt_content.types.list\";i:1;s:38:\"tt_content.types.list.columnsOverrides\";i:1;s:45:\"tt_content.types.list.columnsOverrides.assets\";i:1;s:52:\"tt_content.types.list.columnsOverrides.assets.config\";i:1;s:77:\"tt_content.types.list.columnsOverrides.assets.config.overrideChildTca.columns\";i:1;s:82:\"tt_content.types.list.columnsOverrides.assets.config.overrideChildTca.columns.crop\";i:1;s:89:\"tt_content.types.list.columnsOverrides.assets.config.overrideChildTca.columns.crop.config\";i:1;s:102:\"tt_content.types.list.columnsOverrides.assets.config.overrideChildTca.columns.crop.config.cropVariants\";i:1;s:110:\"tt_content.types.list.columnsOverrides.assets.config.overrideChildTca.columns.crop.config.cropVariants.default\";i:1;s:22:\"tt_content.types.media\";i:1;s:39:\"tt_content.types.media.columnsOverrides\";i:1;s:46:\"tt_content.types.media.columnsOverrides.assets\";i:1;s:62:\"tt_content.types.media.columnsOverrides.assets.config.filter.0\";i:1;s:73:\"tt_content.types.media.columnsOverrides.assets.config.filter.0.parameters\";i:1;s:53:\"tt_content.types.media.columnsOverrides.assets.config\";i:1;s:78:\"tt_content.types.media.columnsOverrides.assets.config.overrideChildTca.columns\";i:1;s:95:\"tt_content.types.media.columnsOverrides.assets.config.overrideChildTca.columns.uid_local.config\";i:1;s:106:\"tt_content.types.media.columnsOverrides.assets.config.overrideChildTca.columns.uid_local.config.appearance\";i:1;s:83:\"tt_content.types.media.columnsOverrides.assets.config.overrideChildTca.columns.crop\";i:1;s:90:\"tt_content.types.media.columnsOverrides.assets.config.overrideChildTca.columns.crop.config\";i:1;s:103:\"tt_content.types.media.columnsOverrides.assets.config.overrideChildTca.columns.crop.config.cropVariants\";i:1;s:111:\"tt_content.types.media.columnsOverrides.assets.config.overrideChildTca.columns.crop.config.cropVariants.default\";i:1;s:69:\"tt_content.types.list.columnsOverrides.assets.config.overrideChildTca\";i:1;s:70:\"tt_content.types.media.columnsOverrides.assets.config.overrideChildTca\";i:1;s:87:\"tt_content.types.list.columnsOverrides.assets.config.overrideChildTca.columns.uid_local\";i:1;s:94:\"tt_content.types.list.columnsOverrides.assets.config.overrideChildTca.columns.uid_local.config\";i:1;s:105:\"tt_content.types.list.columnsOverrides.assets.config.overrideChildTca.columns.uid_local.config.appearance\";i:1;s:88:\"tt_content.types.media.columnsOverrides.assets.config.overrideChildTca.columns.uid_local\";i:1;s:17:\"fe_groups.columns\";i:1;s:24:\"fe_groups.columns.events\";i:1;s:31:\"fe_groups.columns.events.config\";i:1;s:16:\"fe_users.columns\";i:1;s:33:\"fe_users.columns.usergroup.config\";i:1;s:36:\"tx_grevman_domain_model_note.columns\";i:1;s:43:\"tx_grevman_domain_model_note.columns.member\";i:1;s:50:\"tx_grevman_domain_model_note.columns.member.config\";i:1;s:35:\"tx_grevman_domain_model_group.types\";i:1;s:37:\"tx_grevman_domain_model_group.types.1\";i:1;s:34:\"tx_grevman_domain_model_group.ctrl\";i:1;s:51:\"tx_grevman_domain_model_event.ctrl.typeicon_classes\";i:1;s:8:\"fe_users\";i:1;s:30:\"fe_users.columns.registrations\";i:1;s:37:\"fe_users.columns.registrations.config\";i:1;s:22:\"fe_users.columns.notes\";i:1;s:29:\"fe_users.columns.notes.config\";i:1;}s:25:\"node_httpMiddlewareStacks\";a:2:{s:8:\"frontend\";i:1;s:7:\"backend\";i:1;}s:13:\"node_confVars\";a:13:{s:51:\"SC_OPTIONS.GLOBAL.extTablesInclusion-PostProcessing\";i:1;s:22:\"SC_OPTIONS.t3lib/class\";i:1;s:36:\"SC_OPTIONS.t3lib/class.t3lib_tcemain\";i:1;s:60:\"SC_OPTIONS.t3lib/class.t3lib_tcemain.php.processDatamapClass\";i:1;s:28:\"SYS.formEngine.formDataGroup\";i:1;s:44:\"SYS.formEngine.formDataGroup.flexFormSegment\";i:1;s:46:\"SYS.formEngine.formDataGroup.tcaDatabaseRecord\";i:1;s:22:\"MAIL.templateRootPaths\";i:1;s:20:\"MAIL.layoutRootPaths\";i:1;s:11:\"RTE.Presets\";i:1;s:22:\"SC_OPTIONS.tslib/class\";i:1;s:31:\"SC_OPTIONS.tslib/class.tslib_fe\";i:1;s:35:\"SC_OPTIONS.tslib/class.tslib_fe.php\";i:1;}s:26:\"node_formYamlConfiguration\";a:39:{s:31:\"mixins.translationSettingsMixin\";i:1;s:43:\"mixins.translationSettingsMixin.translation\";i:1;s:60:\"mixins.translationSettingsMixin.translation.translationFiles\";i:1;s:93:\"prototypes.standard.finishersDefinition.EmailToReceiver.formEditor.predefinedDefaults.options\";i:1;s:81:\"prototypes.standard.finishersDefinition.EmailToReceiver.options.templateRootPaths\";i:1;s:85:\"prototypes.standard.finishersDefinition.EmailToReceiver.formEditor.predefinedDefaults\";i:1;s:64:\"prototypes.standard.finishersDefinition.EmailToSender.formEditor\";i:1;s:83:\"prototypes.standard.finishersDefinition.EmailToSender.formEditor.predefinedDefaults\";i:1;s:91:\"prototypes.standard.finishersDefinition.EmailToSender.formEditor.predefinedDefaults.options\";i:1;s:83:\"prototypes.standard.finishersDefinition.EmailToSystem.formEditor.predefinedDefaults\";i:1;s:91:\"prototypes.standard.finishersDefinition.EmailToSystem.formEditor.predefinedDefaults.options\";i:1;s:10:\"prototypes\";i:1;s:19:\"prototypes.standard\";i:1;s:47:\"prototypes.standard.formElementsDefinition.Form\";i:1;s:58:\"prototypes.standard.formElementsDefinition.Form.formEditor\";i:1;s:78:\"prototypes.standard.formElementsDefinition.Form.formEditor.propertyCollections\";i:1;s:88:\"prototypes.standard.formElementsDefinition.Form.formEditor.propertyCollections.finishers\";i:1;s:92:\"prototypes.standard.formElementsDefinition.Form.formEditor.propertyCollections.finishers.110\";i:1;s:100:\"prototypes.standard.formElementsDefinition.Form.formEditor.propertyCollections.finishers.110.editors\";i:1;s:91:\"prototypes.standard.formElementsDefinition.Form.formEditor.propertyCollections.finishers.20\";i:1;s:117:\"prototypes.standard.formElementsDefinition.Form.formEditor.propertyCollections.finishers.20.editors.750.gridColumns.0\";i:1;s:117:\"prototypes.standard.formElementsDefinition.Form.formEditor.propertyCollections.finishers.20.editors.750.gridColumns.1\";i:1;s:104:\"prototypes.standard.formElementsDefinition.Form.formEditor.propertyCollections.finishers.110.editors.300\";i:1;s:99:\"prototypes.standard.formElementsDefinition.Form.formEditor.propertyCollections.finishers.20.editors\";i:1;s:115:\"prototypes.standard.formElementsDefinition.Form.formEditor.propertyCollections.finishers.20.editors.350.gridColumns\";i:1;s:117:\"prototypes.standard.formElementsDefinition.Form.formEditor.propertyCollections.finishers.20.editors.350.gridColumns.0\";i:1;s:117:\"prototypes.standard.formElementsDefinition.Form.formEditor.propertyCollections.finishers.20.editors.350.gridColumns.1\";i:1;s:105:\"prototypes.standard.formElementsDefinition.Form.formEditor.propertyCollections.finishers.110.editors.1300\";i:1;s:53:\"prototypes.standard.finishersDefinition.EmailToSystem\";i:1;s:55:\"prototypes.standard.finishersDefinition.EmailToReceiver\";i:1;s:73:\"prototypes.standard.finishersDefinition.EmailToSystem.FormEngine.elements\";i:1;s:74:\"prototypes.standard.finishersDefinition.EmailToSystem.FormEngine._elements\";i:1;s:75:\"prototypes.standard.finishersDefinition.EmailToReceiver.FormEngine.elements\";i:1;s:66:\"prototypes.standard.finishersDefinition.EmailToReceiver.formEditor\";i:1;s:64:\"prototypes.standard.finishersDefinition.EmailToSystem.formEditor\";i:1;s:103:\"prototypes.standard.formElementsDefinition.Form.formEditor.propertyCollections.finishers.20.editors.100\";i:1;s:104:\"prototypes.standard.formElementsDefinition.Form.formEditor.propertyCollections.finishers.20.editors.1300\";i:1;s:104:\"prototypes.standard.formElementsDefinition.Form.formEditor.propertyCollections.finishers.20.editors.1400\";i:1;s:39:\"prototypes.standard.finishersDefinition\";i:1;}s:19:\"node_eventListeners\";a:9:{s:50:\"TYPO3\\CMS\\Frontend\\Event\\ModifyHrefLangTagsEvent.0\";i:1;s:58:\"TYPO3\\CMS\\Extbase\\Event\\Persistence\\EntityPersistedEvent.0\";i:1;s:58:\"TYPO3\\CMS\\Extbase\\Event\\Persistence\\EntityPersistedEvent.1\";i:1;s:72:\"TYPO3\\CMS\\Backend\\Controller\\Event\\AfterFormEnginePageInitializedEvent.0\";i:1;s:72:\"TYPO3\\CMS\\Backend\\Controller\\Event\\AfterFormEnginePageInitializedEvent.1\";i:1;s:56:\"TYPO3\\CMS\\Core\\Package\\Event\\AfterPackageActivationEvent\";i:1;s:58:\"TYPO3\\CMS\\Core\\Package\\Event\\AfterPackageActivationEvent.0\";i:1;s:58:\"TYPO3\\CMS\\Core\\Package\\Event\\AfterPackageActivationEvent.1\";i:1;s:58:\"TYPO3\\CMS\\Core\\Package\\Event\\AfterPackageActivationEvent.2\";i:1;}s:15:\"node_pagesTypes\";a:4:{s:7:\"default\";i:1;i:255;i:1;i:254;i:1;i:6;i:1;}s:22:\"node_siteConfiguration\";a:0:{}}s:9:\"file_list\";a:1:{s:13:\"displayThumbs\";s:1:\"1\";}s:16:\"browse_links.php\";a:1:{s:12:\"expandFolder\";s:21:\"1:/grevman/Documents/\";}s:8:\"web_info\";a:5:{s:8:\"function\";s:60:\"TYPO3\\CMS\\Info\\Controller\\InfoPageTyposcriptConfigController\";s:12:\"tsconf_parts\";s:2:\"1d\";s:5:\"pages\";s:1:\"0\";s:5:\"depth\";s:1:\"0\";s:4:\"lang\";s:1:\"0\";}s:4:\"page\";a:1:{s:28:\"gridelementsCollapsedColumns\";a:4:{s:7:\"365_101\";s:1:\"1\";s:7:\"468_101\";s:1:\"1\";s:7:\"469_101\";s:1:\"1\";s:7:\"468_201\";s:1:\"1\";}}s:9:\"clipboard\";a:5:{s:6:\"normal\";a:2:{s:2:\"el\";a:0:{}s:4:\"mode\";s:0:\"\";}s:5:\"tab_1\";a:2:{s:4:\"mode\";s:0:\"\";s:2:\"el\";a:0:{}}s:5:\"tab_2\";a:0:{}s:5:\"tab_3\";a:0:{}s:7:\"current\";s:5:\"tab_1\";}s:16:\"extensionbuilder\";a:1:{s:9:\"firstTime\";i:0;}s:18:\"list/displayFields\";a:7:{s:33:\"tx_timelog_domain_model_taskgroup\";a:1:{i:0;s:0:\"\";}s:28:\"tx_timelog_domain_model_task\";a:2:{i:0;s:0:\"\";i:1;s:10:\"task_group\";}s:25:\"tx_news_domain_model_news\";a:5:{i:0;s:0:\"\";i:1;s:8:\"datetime\";i:2;s:9:\"event_end\";i:3;s:9:\"organizer\";i:4;s:8:\"location\";}s:27:\"tx_vinfo_domain_model_query\";a:2:{i:0;s:0:\"\";i:1;s:6:\"status\";}s:8:\"fe_users\";a:3:{i:0;s:0:\"\";i:1;s:8:\"password\";i:2;s:5:\"email\";}s:36:\"tx_grevman_domain_model_registration\";a:3:{i:0;s:0:\"\";i:1;s:5:\"state\";i:2;s:5:\"event\";}s:29:\"tx_grevman_domain_model_event\";a:5:{i:0;s:0:\"\";i:1;s:9:\"startdate\";i:2;s:7:\"enddate\";i:3;s:17:\"enable_recurrence\";i:4;s:3:\"uid\";}}s:28:\"dashboard/current_dashboard/\";s:40:\"e03f4772850a5196ac12827aca28b5ca22369aa6\";s:12:\"system_dbint\";a:3:{s:8:\"function\";s:8:\"refindex\";s:6:\"search\";s:3:\"raw\";s:22:\"search_query_makeQuery\";s:3:\"all\";}s:20:\"system_txschedulerM1\";a:1:{s:8:\"function\";s:9:\"scheduler\";}s:47:\"TYPO3\\CMS\\Belog\\Controller\\BackendLogController\";s:353:\"O:39:\"TYPO3\\CMS\\Belog\\Domain\\Model\\Constraint\":12:{s:14:\"\0*\0userOrGroup\";s:1:\"0\";s:9:\"\0*\0number\";i:20;s:15:\"\0*\0workspaceUid\";i:-99;s:12:\"\0*\0timeFrame\";i:0;s:9:\"\0*\0action\";i:-1;s:14:\"\0*\0groupByPage\";b:0;s:17:\"\0*\0startTimestamp\";i:0;s:15:\"\0*\0endTimestamp\";i:0;s:18:\"\0*\0manualDateStart\";N;s:17:\"\0*\0manualDateStop\";N;s:9:\"\0*\0pageId\";i:0;s:8:\"\0*\0depth\";i:0;}\";}s:19:\"thumbnailsByDefault\";i:1;s:14:\"emailMeAtLogin\";i:0;s:11:\"startModule\";s:0:\"\";s:8:\"titleLen\";s:2:\"50\";s:8:\"edit_RTE\";i:1;s:20:\"edit_docModuleUpload\";i:1;s:15:\"resizeTextareas\";i:1;s:25:\"resizeTextareas_MaxHeight\";s:3:\"500\";s:24:\"resizeTextareas_Flexible\";i:0;s:4:\"lang\";s:0:\"\";s:19:\"firstLoginTimeStamp\";i:1550653944;s:15:\"moduleSessionID\";a:17:{s:10:\"web_layout\";s:32:\"80752a3cde1ee17090c6c3b7ee011b3c\";s:8:\"web_list\";s:32:\"2636b9364ad923e6b0e30abbbd2dd09c\";s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";s:40:\"96d0f33f47b036540bec13baf0a4dbad55460da0\";s:10:\"FormEngine\";s:40:\"96d0f33f47b036540bec13baf0a4dbad55460da0\";s:16:\"opendocs::recent\";s:40:\"cef93fb6b48ff828ef3a6246a6df66505cbaccba\";s:6:\"web_ts\";s:40:\"9375959f7199385e42613e89934aaf369a2331de\";s:9:\"tx_beuser\";s:40:\"727f7614b5d2df317d9d1df672012fc835466337\";s:9:\"file_list\";s:32:\"21ef62a3917ad2a2c8dd1717915f81e4\";s:16:\"browse_links.php\";s:40:\"fc3132236081252b5e9f361a50f38a272243b8c0\";s:8:\"web_info\";s:40:\"e4ee8a090a9894d91f0c8c8f5b447b09ae5e1e8a\";s:9:\"clipboard\";s:40:\"96d0f33f47b036540bec13baf0a4dbad55460da0\";s:16:\"extensionbuilder\";s:40:\"fdf21a2e497df6c100fd699da8e9b3c2123850ce\";s:18:\"list/displayFields\";s:40:\"cef93fb6b48ff828ef3a6246a6df66505cbaccba\";s:28:\"dashboard/current_dashboard/\";s:40:\"c6b9350d27d7b7730388cfb53c9ba604154abafe\";s:12:\"system_dbint\";s:40:\"727f7614b5d2df317d9d1df672012fc835466337\";s:20:\"system_txschedulerM1\";s:40:\"727f7614b5d2df317d9d1df672012fc835466337\";s:47:\"TYPO3\\CMS\\Belog\\Controller\\BackendLogController\";s:40:\"6139d1bcdcb300d945fb3357defdfcd8ab52b93e\";}s:17:\"BackendComponents\";a:1:{s:6:\"States\";a:3:{s:8:\"Pagetree\";a:1:{s:9:\"stateHash\";a:30:{s:3:\"0_1\";s:1:\"1\";s:4:\"0_80\";s:1:\"1\";s:4:\"0_91\";s:1:\"0\";s:4:\"0_82\";s:1:\"0\";s:5:\"0_103\";s:1:\"0\";s:5:\"0_109\";s:1:\"0\";s:4:\"0_18\";s:1:\"0\";s:4:\"0_27\";s:1:\"0\";s:4:\"0_97\";s:1:\"1\";s:4:\"0_52\";s:1:\"0\";s:5:\"0_117\";s:1:\"0\";s:4:\"0_94\";s:1:\"0\";s:4:\"0_67\";s:1:\"0\";s:4:\"0_57\";s:1:\"1\";s:4:\"0_93\";s:1:\"1\";s:5:\"0_120\";s:1:\"1\";s:5:\"0_190\";s:1:\"1\";s:5:\"0_192\";s:1:\"0\";s:5:\"0_123\";s:1:\"1\";s:5:\"0_194\";s:1:\"0\";s:5:\"0_200\";s:1:\"0\";s:5:\"0_201\";s:1:\"1\";s:4:\"0_88\";s:1:\"0\";s:5:\"0_205\";s:1:\"0\";s:5:\"0_187\";s:1:\"1\";s:5:\"0_207\";s:1:\"0\";s:5:\"0_206\";s:1:\"0\";s:5:\"0_197\";s:1:\"0\";s:5:\"0_220\";s:1:\"0\";s:5:\"0_223\";s:1:\"1\";}}s:17:\"typo3-module-menu\";a:1:{s:9:\"collapsed\";s:4:\"true\";}s:16:\"ExtensionManager\";a:1:{s:6:\"filter\";s:5:\"Local\";}}}s:10:\"inlineView\";s:5584:\"{\"site\":{\"1\":{\"site_language\":{\"4\":\"2\",\"5\":\"0\"},\"site_route\":{\"2\":\"0\"}}},\"tx_timelog_domain_model_task\":{\"11\":{\"tx_timelog_domain_model_interval\":[30,\"\"]},\"NEW5eabe448b4c9b302528992\":{\"tx_timelog_domain_model_interval\":[31]},\"15\":{\"tx_timelog_domain_model_interval\":{\"1\":\"31\"}},\"NEW5eabe81cee99f334710387\":{\"tx_timelog_domain_model_interval\":[32]},\"NEW5eabf241e11fd679532143\":{\"tx_timelog_domain_model_interval\":[33]},\"NEW5eabf497299b3463044971\":{\"tx_timelog_domain_model_interval\":[34]},\"NEW5eb3fcf14db0e244144717\":{\"tx_timelog_domain_model_interval\":[38]},\"21\":{\"tx_timelog_domain_model_interval\":[39,40]},\"NEW5eb6de97b6021897549832\":{\"tx_timelog_domain_model_interval\":[42]},\"23\":{\"tx_timelog_domain_model_interval\":[43]}},\"tx_timelog_domain_model_project\":{\"5\":{\"tx_timelog_domain_model_task\":[\"\"],\"tx_timelog_domain_model_taskgroup\":[3,4,5]},\"6\":{\"tx_timelog_domain_model_interval\":{\"0\":35,\"1\":36,\"2\":37,\"7\":\"39\",\"8\":\"38\",\"10\":\"40\"},\"tx_timelog_domain_model_task\":{\"1\":\"20\",\"12\":\"21\"},\"tx_timelog_domain_model_task_group\":[1],\"tx_timelog_domain_model_taskgroup\":{\"13\":\"\"}}},\"tx_timelog_domain_model_taskgroup\":{\"2\":{\"tx_timelog_domain_model_task\":[\"20\"],\"tx_timelog_domain_model_interval\":[41]},\"1\":{\"tx_timelog_domain_model_task\":{\"4\":\"19\"}}},\"tt_content\":{\"NEW5f2add01b7e53469777127\":{\"sys_file_reference\":[385]},\"780\":{\"sys_file_reference\":{\"0\":386,\"1\":387,\"5\":\"\"}},\"NEW5f3179d7b02b5269450631\":{\"sys_file_reference\":[389]},\"NEW5f317c6399b20292267607\":{\"sys_file_reference\":[390]},\"807\":{\"sys_file_reference\":[\"390\"]},\"NEW5f31819ba800d813646479\":{\"sys_file_reference\":[391]},\"NEW5f3181f0681c2273223467\":{\"sys_file_reference\":[392]},\"NEW5f318993c25af964292760\":{\"sys_file_reference\":[393]},\"NEW5f318b9daca8e298441350\":{\"sys_file_reference\":[394]},\"NEW5f351f4dda72b615681307\":{\"sys_file_reference\":[395]},\"NEW5f351f88d1f72931649153\":{\"sys_file_reference\":[396]},\"840\":{\"sys_file_reference\":[\"396\"]},\"908\":{\"sys_file_reference\":[400,401]},\"NEW5f97dd7244ed0897313902\":{\"sys_file_reference\":[408]},\"NEW5f9a6e96df043290247570\":{\"sys_file_reference\":[409]},\"NEW5fb386ed1d64e053298664\":{\"sys_file_reference\":[410]},\"933\":{\"sys_file_reference\":[\"410\"]},\"NEW5fb396c89acca079747674\":{\"sys_file_reference\":[411]},\"939\":{\"sys_file_reference\":[\"412\",\"413\",\"414\",\"415\",\"416\",\"417\"]},\"940\":{\"sys_file_reference\":[\"418\",\"419\",\"420\",\"421\"]},\"927\":{\"sys_file_reference\":[422]},\"NEW5fb794acb4ea3704436116\":{\"sys_file_reference\":[429]},\"NEW5fe0d8a11839d583393456\":{\"sys_file_reference\":[430]},\"NEW5fe0d8bad2fb7671705414\":{\"sys_file_reference\":[431]},\"952\":{\"sys_file_reference\":[]},\"953\":{\"sys_file_reference\":[433]},\"NEW5fe197f5c6c0c276005224\":{\"sys_file_reference\":[434,435,436,437]},\"NEW5fe1991baa27c056409945\":{\"sys_file_reference\":[438]},\"NEW5fe199ab2c7bc243589434\":{\"sys_file_reference\":[439]},\"NEW5fe199c208da8146119236\":{\"sys_file_reference\":[440]},\"NEW6030e278a968e209674347\":{\"sys_file_reference\":[441]},\"969\":{\"sys_file_reference\":{\"2\":\"441\"}},\"NEW6069ec3edb7ce036425900\":{\"sys_file_reference\":[442]},\"NEW6069eca507b42031334515\":{\"sys_file_reference\":[443]},\"NEW6069eccce24a2531932335\":{\"sys_file_reference\":[444]},\"NEW6069ece29bb88066886438\":{\"sys_file_reference\":[445]},\"NEW6069ed067aced069585528\":{\"sys_file_reference\":[446]},\"NEW6069ed1ce1fe7802245241\":{\"sys_file_reference\":[447]},\"NEW6069ed319c04b349158762\":{\"sys_file_reference\":[448]},\"997\":{\"sys_file_reference\":[449]},\"NEW6069eda81e75c784806946\":{\"sys_file_reference\":[450]},\"1000\":{\"sys_file_reference\":{\"1\":\"\"}},\"112\":{\"sys_file_reference\":[\"\",453,455]},\"NEW607091ee560d5021641125\":{\"sys_file_reference\":[456]},\"NEW60719598dcac7591053873\":{\"sys_file_reference\":[457]},\"NEW607195ccba83e628579393\":{\"sys_file_reference\":[458]},\"NEW607195e344db9750093181\":{\"sys_file_reference\":[459]},\"957\":{\"sys_file_reference\":[\"438\",460]},\"350\":{\"sys_file_reference\":[461]},\"NEW60db43dcb2af9413926434\":{\"sys_file_reference\":[465]},\"1018\":{\"sys_file_reference\":[\"465\"]}},\"tx_realer_domain_model_property\":{\"1\":{\"sys_file_reference\":[399]}},\"tx_news_domain_model_news\":{\"4\":{\"sys_file_reference\":[402]},\"7\":{\"sys_file_reference\":{\"1\":\"\"}},\"6\":{\"sys_file_reference\":[407],\"tx_news_domain_model_link\":[1]},\"1\":{\"sys_file_reference\":[\"4\"]},\"3\":{\"sys_file_reference\":{\"2\":\"6\"}},\"2\":{\"sys_file_reference\":[\"5\"]}},\"tx_vinfo_domain_model_vote\":{\"1\":{\"tx_vinfo_domain_model_business\":{\"1\":6,\"2\":\"1\",\"5\":\"4\",\"6\":\"5\",\"7\":\"3\"},\"tx_vinfo_domain_model_query\":[\"1\",8,9,10,11]},\"2\":{\"tx_vinfo_domain_model_business\":[\"2\"]},\"3\":{\"tx_vinfo_domain_model_query\":{\"6\":\"13\",\"7\":\"12\"},\"tx_vinfo_domain_model_business\":{\"1\":8,\"4\":\"7\"}}},\"tx_vinfo_domain_model_business\":{\"1\":{\"tx_vinfo_domain_model_query\":{\"4\":\"\"}},\"2\":{\"tx_vinfo_domain_model_query\":[2]},\"5\":{\"tx_vinfo_domain_model_query\":{\"1\":\"\"}}},\"tx_powermail_domain_model_form\":{\"NEW6089929b75ed9148230161\":{\"tx_powermail_domain_model_field\":[1,2,3],\"tx_powermail_domain_model_page\":[1]},\"1\":{\"tx_powermail_domain_model_page\":[\"1\"],\"tx_powermail_domain_model_field\":[\"\",4]}},\"tx_grevman_domain_model_event\":{\"1\":{\"tx_grevman_domain_model_registration\":{\"9\":\"1\",\"10\":\"2\"},\"tx_grevman_domain_model_note\":{\"5\":\"\"},\"sys_file_reference\":{\"0\":462,\"1\":463,\"2\":470,\"4\":471,\"5\":472,\"6\":473,\"7\":474,\"8\":478,\"9\":\"502\"}},\"NEW60d2daae692c9447735987\":{\"sys_file_reference\":[464]},\"2\":{\"tx_grevman_domain_model_registration\":[3,4]},\"50\":{\"tx_grevman_domain_model_registration\":{\"1\":\"\"}}},\"fe_users\":{\"11\":{\"tx_grevman_domain_model_note\":{\"2\":\"\"}},\"10\":{\"tx_grevman_domain_model_registration\":{\"2\":\"\"},\"tx_grevman_domain_model_note\":[\"\"]}},\"tt_address\":{\"3\":{\"sys_file_reference\":[\"466\"]},\"2\":{\"sys_file_reference\":[\"467\"]}}}\";s:10:\"AdminPanel\";a:19:{s:11:\"display_top\";b:1;s:12:\"tsdebug_tree\";s:1:\"0\";s:20:\"tsdebug_displayTimes\";s:1:\"0\";s:23:\"tsdebug_displayMessages\";s:1:\"0\";s:10:\"tsdebug_LR\";s:1:\"0\";s:22:\"tsdebug_displayContent\";s:1:\"0\";s:28:\"tsdebug_forceTemplateParsing\";s:1:\"0\";s:26:\"debug_log_groupByComponent\";s:1:\"0\";s:22:\"debug_log_groupByLevel\";s:1:\"0\";s:20:\"debug_log_startLevel\";s:1:\"0\";s:23:\"preview_showHiddenPages\";s:1:\"0\";s:25:\"preview_showHiddenRecords\";s:1:\"0\";s:22:\"preview_showFluidDebug\";s:1:\"0\";s:20:\"preview_clearCacheId\";s:3:\"109\";s:20:\"preview_simulateDate\";s:0:\"\";s:25:\"preview_simulateUserGroup\";s:1:\"0\";s:13:\"cache_noCache\";s:1:\"0\";s:22:\"edit_displayFieldIcons\";s:1:\"1\";s:17:\"edit_displayIcons\";s:1:\"1\";}s:8:\"realName\";s:0:\"\";s:5:\"email\";s:0:\"\";s:8:\"password\";s:0:\"\";s:9:\"password2\";s:0:\"\";s:6:\"avatar\";s:0:\"\";s:25:\"showHiddenFilesAndFolders\";i:1;s:10:\"copyLevels\";s:3:\"100\";s:15:\"recursiveDelete\";i:1;s:18:\"resetConfiguration\";s:0:\"\";s:16:\"frontend_editing\";i:0;s:24:\"frontend_editing_overlay\";i:1;s:42:\"dragAndDropHideNewElementWizardInfoOverlay\";i:0;s:17:\"hideColumnHeaders\";i:0;s:18:\"hideContentPreview\";i:0;s:19:\"showGridInformation\";i:0;s:11:\"newsoverlay\";s:1:\"0\";s:11:\"browseTrees\";a:2:{s:6:\"folder\";s:117:\"{\"25218\":{\"62822724\":1,\"108689290\":1,\"218175286\":1,\"95683263\":1,\"66702825\":1,\"14248556\":1,\"67225282\":1,\"79480688\":1}}\";s:11:\"browsePages\";s:45:\"[{\"0\":1,\"1\":1,\"117\":1,\"91\":1,\"207\":1,\"97\":1}]\";}s:19:\"disableDragInWizard\";i:0;s:25:\"disableCopyFromPageButton\";i:0;s:21:\"recentSwitchedToUsers\";a:0:{}s:11:\"tx_recycler\";a:3:{s:14:\"depthSelection\";i:999;s:14:\"tableSelection\";s:0:\"\";s:11:\"resultLimit\";i:25;}s:17:\"systeminformation\";s:45:\"{\"system_BelogLog\":{\"lastAccess\":1639150633}}\";}',NULL,NULL,1,'',0,'',1645076153,0,NULL,0,NULL,''),(6,0,1634547047,1634547047,0,0,0,0,0,NULL,'_cli_',0,'$argon2i$v=19$m=65536,t=16,p=1$ZHJzSktDRm9vRnQ0dFgwSg$xKq98eYv3MNo70MtZt6UzBg/CzT8Maf4IVdD0Li19kg',1,'','','',NULL,0,'',NULL,'','a:12:{s:14:\"interfaceSetup\";s:0:\"\";s:10:\"moduleData\";a:0:{}s:19:\"thumbnailsByDefault\";i:1;s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";i:50;s:8:\"edit_RTE\";s:1:\"1\";s:20:\"edit_docModuleUpload\";s:1:\"1\";s:15:\"resizeTextareas\";i:1;s:25:\"resizeTextareas_MaxHeight\";i:500;s:24:\"resizeTextareas_Flexible\";i:0;s:4:\"lang\";s:0:\"\";s:19:\"firstLoginTimeStamp\";i:1634547047;}',NULL,NULL,1,'',0,NULL,0,0,NULL,0,NULL,'');
/*!40000 ALTER TABLE `be_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_groups`
--

DROP TABLE IF EXISTS `fe_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fe_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_extbase_type` varchar(255) NOT NULL DEFAULT '0',
  `title` varchar(50) NOT NULL DEFAULT '',
  `lockToDomain` varchar(50) NOT NULL DEFAULT '',
  `subgroup` tinytext DEFAULT NULL,
  `TSconfig` text DEFAULT NULL,
  `felogin_redirectPid` tinytext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_groups`
--

LOCK TABLES `fe_groups` WRITE;
/*!40000 ALTER TABLE `fe_groups` DISABLE KEYS */;
INSERT INTO `fe_groups` VALUES (3,225,1624269519,1624269519,1,0,0,'','0','participants','','','',''),(4,226,1624619257,1624269526,1,0,0,'','0','leaders','','','','');
/*!40000 ALTER TABLE `fe_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_users`
--

DROP TABLE IF EXISTS `fe_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fe_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_extbase_type` varchar(255) NOT NULL DEFAULT '',
  `username` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(100) NOT NULL DEFAULT '',
  `usergroup` tinytext DEFAULT NULL,
  `name` varchar(160) NOT NULL DEFAULT '',
  `first_name` varchar(50) NOT NULL DEFAULT '',
  `middle_name` varchar(50) NOT NULL DEFAULT '',
  `last_name` varchar(50) NOT NULL DEFAULT '',
  `address` varchar(255) NOT NULL DEFAULT '',
  `telephone` varchar(30) NOT NULL DEFAULT '',
  `fax` varchar(30) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `lockToDomain` varchar(50) NOT NULL DEFAULT '',
  `uc` blob DEFAULT NULL,
  `title` varchar(40) NOT NULL DEFAULT '',
  `zip` varchar(10) NOT NULL DEFAULT '',
  `city` varchar(50) NOT NULL DEFAULT '',
  `country` varchar(40) NOT NULL DEFAULT '',
  `www` varchar(80) NOT NULL DEFAULT '',
  `company` varchar(80) NOT NULL DEFAULT '',
  `image` tinytext DEFAULT NULL,
  `TSconfig` text DEFAULT NULL,
  `lastlogin` int(10) unsigned NOT NULL DEFAULT 0,
  `is_online` int(10) unsigned NOT NULL DEFAULT 0,
  `felogin_redirectPid` tinytext DEFAULT NULL,
  `felogin_forgotHash` varchar(80) DEFAULT '',
  `member_groups` int(10) unsigned NOT NULL DEFAULT 0,
  `registrations` int(10) unsigned NOT NULL DEFAULT 0,
  `notes` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`username`(100)),
  KEY `username` (`username`(100)),
  KEY `is_online` (`is_online`),
  KEY `felogin_forgotHash` (`felogin_forgotHash`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_users`
--

LOCK TABLES `fe_users` WRITE;
/*!40000 ALTER TABLE `fe_users` DISABLE KEYS */;
INSERT INTO `fe_users` VALUES (10,225,1645096569,1624269453,1,0,0,0,0,'','Tx_Grevman_Member','participant1','$argon2i$v=19$m=65536,t=16,p=1$aG9SQ1NUd0ZjLnJudlh2QQ$mQZygI24MWftGLEQf2UQVoBXHlRurK2PrSSUMc+CXzE','3','','Participant1','','Last1','','','','participant1@grevman.ddev.site','',NULL,'','','','','','','0','',1645095899,1645095899,'','',1,0,0),(11,225,1645016303,1624269566,1,0,0,0,0,'','Tx_Grevman_Member','participant2','$argon2i$v=19$m=65536,t=16,p=1$RkZhR2x6UXg1RHRYLkJKVA$MQJbTByuCRoiMd8PiTZ4lqs1aseg7WU3xhNGeN6sJ2I','3','','Participant2','','Last2','','','','participant2@grevman.ddev.site','',NULL,'','','','','','','0','',1644941215,1644944723,'','',2,2,0),(12,225,1645016303,1624269577,1,0,0,0,0,'','Tx_Grevman_Member','participant3','$argon2i$v=19$m=65536,t=16,p=1$ZzAxN3JIR2FJTTh5RmFsYg$7sbzid0oWBvYK6jAhShHThm3fTF9lJWkZjwPzAJg6VM','3','','Participant3','','Last3','','','','participant3@grevman.ddev.site','',NULL,'','','','','','',NULL,'',1626856058,1626856895,'','',0,0,0),(13,225,1645016303,1624269590,1,0,0,0,0,'','Tx_Grevman_Member','participant4','$argon2i$v=19$m=65536,t=16,p=1$eGlZeUwzWjlSdnpEeDRHcg$jqIFQKSzgo+IOEJy6HQTH6TEJCk++tlZYrvCBWkM2Wc','3','','Participant4','','Last4','','','','participant4@grevman.ddev.site','',NULL,'','','','','','',NULL,'',1634741427,1634746573,'','',0,0,0),(14,226,1645014558,1624269607,1,0,0,0,0,'','Tx_Grevman_Member','leader1','$argon2i$v=19$m=65536,t=16,p=1$eDVvR1BiSS83S0hnQUppcA$MAMv8GcnbxCPiA0W7E4e7d+Z6EbUhkZm7bR2Y1y1FWo','4','','Trainer1','','','','','','leader1@grevman.ddev.site','',NULL,'','','','','','','0','',1645014406,1645032865,'','',1,0,0),(15,226,1645014558,1624269618,1,0,0,0,0,'','Tx_Grevman_Member','leader2','$argon2i$v=19$m=65536,t=16,p=1$bEgyVWxMRUh2Qm83eG5VSQ$g/2kEvI//xkQG+pCSeBoD/hP3DnN3NyYREWmHtl1QHM','4','','Trainer2','','','','','','leader2@grevman.ddev.site','',NULL,'','','','','','','0','',0,0,'','',1,0,0),(16,225,1645016303,1624600945,1,0,0,0,0,'','Tx_Grevman_Member','participant11','$argon2i$v=19$m=65536,t=16,p=1$dFFmRk9WRUJRLzRmY0dpMw$51dIvMnmCtbq07YS+Znq9oegP3IPcoG/6N1O0H4aOVY','3','','Participant11','','Last11','','','','participant11@grevman.ddev.site','',NULL,'','','','','','','0','',1624602576,1624610848,'','',0,1,0);
/*!40000 ALTER TABLE `fe_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_groupid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_user` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_group` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_everybody` smallint(5) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `slug` varchar(2048) DEFAULT NULL,
  `doktype` int(10) unsigned NOT NULL DEFAULT 0,
  `TSconfig` text DEFAULT NULL,
  `is_siteroot` smallint(6) NOT NULL DEFAULT 0,
  `php_tree_stop` smallint(6) NOT NULL DEFAULT 0,
  `url` varchar(255) NOT NULL DEFAULT '',
  `shortcut` int(10) unsigned NOT NULL DEFAULT 0,
  `shortcut_mode` int(10) unsigned NOT NULL DEFAULT 0,
  `subtitle` varchar(255) NOT NULL DEFAULT '',
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `target` varchar(80) NOT NULL DEFAULT '',
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `lastUpdated` int(10) unsigned NOT NULL DEFAULT 0,
  `keywords` text DEFAULT NULL,
  `cache_timeout` int(10) unsigned NOT NULL DEFAULT 0,
  `cache_tags` varchar(255) NOT NULL DEFAULT '',
  `newUntil` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `no_search` smallint(5) unsigned NOT NULL DEFAULT 0,
  `SYS_LASTCHANGED` int(10) unsigned NOT NULL DEFAULT 0,
  `abstract` text DEFAULT NULL,
  `module` varchar(255) NOT NULL DEFAULT '',
  `extendToSubpages` smallint(5) unsigned NOT NULL DEFAULT 0,
  `author` varchar(255) NOT NULL DEFAULT '',
  `author_email` varchar(255) NOT NULL DEFAULT '',
  `nav_title` varchar(255) NOT NULL DEFAULT '',
  `nav_hide` smallint(6) NOT NULL DEFAULT 0,
  `content_from_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid_ol` smallint(6) NOT NULL DEFAULT 0,
  `l18n_cfg` smallint(6) NOT NULL DEFAULT 0,
  `fe_login_mode` smallint(6) NOT NULL DEFAULT 0,
  `backend_layout` varchar(64) NOT NULL DEFAULT '',
  `backend_layout_next_level` varchar(64) NOT NULL DEFAULT '',
  `tsconfig_includes` text DEFAULT NULL,
  `legacy_overlay_uid` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `no_index` smallint(6) NOT NULL DEFAULT 0,
  `no_follow` smallint(6) NOT NULL DEFAULT 0,
  `og_title` varchar(255) NOT NULL DEFAULT '',
  `og_description` text DEFAULT NULL,
  `og_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_title` varchar(255) NOT NULL DEFAULT '',
  `twitter_description` text DEFAULT NULL,
  `twitter_image` int(10) unsigned NOT NULL DEFAULT 0,
  `canonical_link` varchar(2048) NOT NULL DEFAULT '',
  `categories` int(11) NOT NULL DEFAULT 0,
  `nav_icon` int(10) unsigned DEFAULT 0,
  `thumbnail` int(10) unsigned DEFAULT 0,
  `twitter_card` varchar(255) NOT NULL DEFAULT '',
  `sitemap_priority` decimal(2,1) NOT NULL DEFAULT 0.5,
  `sitemap_changefreq` varchar(10) NOT NULL DEFAULT '',
  `nav_icon_set` varchar(255) NOT NULL DEFAULT '',
  `nav_icon_identifier` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `determineSiteRoot` (`is_siteroot`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `slug` (`slug`(127)),
  KEY `translation_source` (`l10n_source`),
  KEY `legacy_overlay` (`legacy_overlay_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=235 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES (1,0,1634546075,1550653971,1,0,0,0,0,'',256,NULL,0,0,0,0,NULL,0,'a:36:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:9:\"nav_title\";N;s:8:\"subtitle\";N;s:12:\"nav_icon_set\";N;s:8:\"nav_icon\";N;s:13:\"shortcut_mode\";N;s:8:\"shortcut\";N;s:8:\"abstract\";N;s:6:\"author\";N;s:12:\"author_email\";N;s:11:\"lastUpdated\";N;s:6:\"layout\";N;s:8:\"newUntil\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:9:\"thumbnail\";N;s:6:\"target\";N;s:11:\"is_siteroot\";N;s:9:\"no_search\";N;s:13:\"php_tree_stop\";N;s:5:\"media\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:8:\"l18n_cfg\";N;s:6:\"hidden\";N;s:8:\"nav_hide\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:16:\"extendToSubpages\";N;s:8:\"fe_group\";N;s:13:\"fe_login_mode\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,1,1,31,27,0,'Pizpalue','/',1,'',1,0,'',0,0,'',0,'',0,0,'',0,'',0,'Diese Webseite dient als Basis zur Erstellung professioneller TYPO3-Webseiten. Das Grundgerüst besteht aus der Erweiterung bootstrap_package von Benjamin Kott. Dank der sorgfältigen Einbindung von zusätzlichen Erweiterungen können Inhalte ansprechend präsentiert und leicht verwaltet werden.',0,1634546075,'','',0,'','','',0,0,0,0,0,0,'pagets__default','pagets__default','',0,1,'',0,0,'',NULL,0,'',NULL,0,'',0,0,0,'summary',0.5,'','',''),(223,1,1644934113,1624269364,1,0,0,0,0,'',1232,NULL,0,0,0,0,NULL,0,'a:52:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:9:\"nav_title\";N;s:8:\"subtitle\";N;s:8:\"nav_icon\";N;s:9:\"seo_title\";N;s:11:\"description\";N;s:8:\"no_index\";N;s:9:\"no_follow\";N;s:14:\"canonical_link\";N;s:18:\"sitemap_changefreq\";N;s:16:\"sitemap_priority\";N;s:8:\"og_title\";N;s:14:\"og_description\";N;s:8:\"og_image\";N;s:13:\"twitter_title\";N;s:19:\"twitter_description\";N;s:13:\"twitter_image\";N;s:12:\"twitter_card\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:6:\"author\";N;s:12:\"author_email\";N;s:11:\"lastUpdated\";N;s:6:\"layout\";N;s:8:\"newUntil\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:9:\"thumbnail\";N;s:16:\"content_from_pid\";N;s:6:\"target\";N;s:13:\"cache_timeout\";N;s:10:\"cache_tags\";N;s:11:\"is_siteroot\";N;s:9:\"no_search\";N;s:13:\"php_tree_stop\";N;s:6:\"module\";N;s:5:\"media\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:8:\"l18n_cfg\";N;s:6:\"hidden\";N;s:8:\"nav_hide\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:16:\"extendToSubpages\";N;s:8:\"fe_group\";N;s:13:\"fe_login_mode\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,1,1,31,31,0,'Grevman','/grevman',1,'',0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1644934113,NULL,'',0,'','','',0,0,0,0,0,0,'','','EXT:grevman/Configuration/TsConfig/Page/Storage.tsconfig',0,0,'',0,0,'',NULL,0,'',NULL,0,'',0,0,0,'summary',0.5,'','',''),(224,223,1624269373,1624269373,1,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,0,'',0,0,0,0,0,0,0,1,1,31,31,0,'Data','/grevman/data',254,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,0,'','',NULL,0,0,'',0,0,'',NULL,0,'',NULL,0,'',0,0,0,'summary',0.5,'','',''),(225,223,1624356225,1624269489,1,0,0,0,0,'0',128,NULL,0,0,0,0,NULL,0,'a:13:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:6:\"module\";N;s:5:\"media\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:6:\"hidden\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,1,1,31,31,0,'Participants','/grevman/users',254,'TCAdefaults {\r\n  fe_users {\r\n    usergroup = 3\r\n  }\r\n}',0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,0,'','',NULL,0,0,'',0,0,'',NULL,0,'',NULL,0,'',0,0,0,'summary',0.5,'','',''),(226,223,1624619241,1624341123,1,0,0,0,0,'0',192,NULL,0,0,0,0,NULL,0,'a:13:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:6:\"module\";N;s:5:\"media\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:6:\"hidden\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,1,1,31,31,0,'Leaders','/grevman/leaders',254,'TCAdefaults {\r\n  fe_users {\r\n    usergroup = 4\r\n  }\r\n}',0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,0,'','',NULL,0,0,'',0,0,'',NULL,0,'',NULL,0,'',0,0,0,'summary',0.5,'','',''),(227,1,1644935093,1624547407,1,0,0,0,0,'',2464,NULL,0,0,0,0,NULL,0,'a:53:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:9:\"nav_title\";N;s:8:\"subtitle\";N;s:12:\"nav_icon_set\";N;s:8:\"nav_icon\";N;s:9:\"seo_title\";N;s:11:\"description\";N;s:8:\"no_index\";N;s:9:\"no_follow\";N;s:14:\"canonical_link\";N;s:18:\"sitemap_changefreq\";N;s:16:\"sitemap_priority\";N;s:8:\"og_title\";N;s:14:\"og_description\";N;s:8:\"og_image\";N;s:13:\"twitter_title\";N;s:19:\"twitter_description\";N;s:13:\"twitter_image\";N;s:12:\"twitter_card\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:6:\"author\";N;s:12:\"author_email\";N;s:11:\"lastUpdated\";N;s:6:\"layout\";N;s:8:\"newUntil\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:9:\"thumbnail\";N;s:16:\"content_from_pid\";N;s:6:\"target\";N;s:13:\"cache_timeout\";N;s:10:\"cache_tags\";N;s:11:\"is_siteroot\";N;s:9:\"no_search\";N;s:13:\"php_tree_stop\";N;s:6:\"module\";N;s:5:\"media\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:8:\"l18n_cfg\";N;s:6:\"hidden\";N;s:8:\"nav_hide\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:16:\"extendToSubpages\";N;s:8:\"fe_group\";N;s:13:\"fe_login_mode\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,1,1,31,31,0,'Login','/login',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1644935093,NULL,'',0,'','','',0,0,0,0,0,0,'','',NULL,0,0,'',0,0,'',NULL,0,'',NULL,0,'',0,0,0,'summary',0.5,'','',''),(234,1,1644935079,1639141074,1,0,0,0,0,'',1848,NULL,0,0,0,0,NULL,0,'a:53:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:9:\"nav_title\";N;s:8:\"subtitle\";N;s:12:\"nav_icon_set\";N;s:8:\"nav_icon\";N;s:9:\"seo_title\";N;s:11:\"description\";N;s:8:\"no_index\";N;s:9:\"no_follow\";N;s:14:\"canonical_link\";N;s:18:\"sitemap_changefreq\";N;s:16:\"sitemap_priority\";N;s:8:\"og_title\";N;s:14:\"og_description\";N;s:8:\"og_image\";N;s:13:\"twitter_title\";N;s:19:\"twitter_description\";N;s:13:\"twitter_image\";N;s:12:\"twitter_card\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:6:\"author\";N;s:12:\"author_email\";N;s:11:\"lastUpdated\";N;s:6:\"layout\";N;s:8:\"newUntil\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:9:\"thumbnail\";N;s:16:\"content_from_pid\";N;s:6:\"target\";N;s:13:\"cache_timeout\";N;s:10:\"cache_tags\";N;s:11:\"is_siteroot\";N;s:9:\"no_search\";N;s:13:\"php_tree_stop\";N;s:6:\"module\";N;s:5:\"media\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:8:\"l18n_cfg\";N;s:6:\"hidden\";N;s:8:\"nav_hide\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:16:\"extendToSubpages\";N;s:8:\"fe_group\";N;s:13:\"fe_login_mode\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,1,1,31,31,0,'Messenger','/messenger',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1639141078,NULL,'',0,'','','',0,0,0,0,0,0,'','',NULL,0,0,'',0,0,'',NULL,0,'',NULL,0,'',0,0,0,'summary',0.5,'','','');
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_be_shortcuts`
--

DROP TABLE IF EXISTS `sys_be_shortcuts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_be_shortcuts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `module_name` varchar(255) NOT NULL DEFAULT '',
  `url` text DEFAULT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sc_group` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts`
--

LOCK TABLES `sys_be_shortcuts` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category`
--

DROP TABLE IF EXISTS `sys_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_category` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `title` tinytext NOT NULL,
  `parent` int(11) NOT NULL DEFAULT 0,
  `items` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `category_parent` (`parent`),
  KEY `category_list` (`pid`,`deleted`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category`
--

LOCK TABLES `sys_category` WRITE;
/*!40000 ALTER TABLE `sys_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category_record_mm`
--

DROP TABLE IF EXISTS `sys_category_record_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_category_record_mm` (
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(255) NOT NULL DEFAULT '',
  `fieldname` varchar(255) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  KEY `uid_local_foreign` (`uid_local`,`uid_foreign`),
  KEY `uid_foreign_tablefield` (`uid_foreign`,`tablenames`(40),`fieldname`(3),`sorting_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category_record_mm`
--

LOCK TABLES `sys_category_record_mm` WRITE;
/*!40000 ALTER TABLE `sys_category_record_mm` DISABLE KEYS */;
INSERT INTO `sys_category_record_mm` VALUES (1,339,'tt_content','categories',3,1),(1,342,'tt_content','categories',2,1),(2,1,'tx_news_domain_model_news','categories',1,0),(2,2,'tx_news_domain_model_news','categories',2,1),(2,3,'tx_news_domain_model_news','categories',3,2),(1,75,'pages','categories',1,0),(1,150,'pages','categories',0,1),(1,471,'tt_content','categories',0,1),(1,558,'tt_content','categories',0,1),(1,639,'tt_content','categories',0,1),(1,702,'tt_content','categories',0,1),(1,706,'tt_content','categories',0,1),(1,710,'tt_content','categories',0,1),(1,712,'tt_content','categories',0,1),(1,722,'tt_content','categories',0,1),(1,727,'tt_content','categories',0,1),(1,733,'tt_content','categories',0,1),(1,741,'tt_content','categories',0,1),(1,761,'tt_content','categories',0,1),(3,471,'tt_content','categories',1,0),(3,558,'tt_content','categories',2,0),(3,702,'tt_content','categories',3,0),(3,722,'tt_content','categories',4,0),(3,706,'tt_content','categories',5,0),(3,710,'tt_content','categories',6,0),(3,712,'tt_content','categories',7,0),(3,727,'tt_content','categories',8,0),(3,741,'tt_content','categories',9,0),(3,150,'pages','categories',10,0),(3,733,'tt_content','categories',11,0),(3,639,'tt_content','categories',12,0),(4,4,'tx_news_domain_model_news','categories',0,1),(5,5,'tx_news_domain_model_news','categories',0,1),(4,6,'tx_news_domain_model_news','categories',0,1),(5,6,'tx_news_domain_model_news','categories',0,2),(3,3,'tx_news_domain_model_news','categories',0,1),(1,3,'tx_news_domain_model_news','categories',0,3);
/*!40000 ALTER TABLE `sys_category_record_mm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_collection`
--

DROP TABLE IF EXISTS `sys_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_collection` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `type` varchar(32) NOT NULL DEFAULT 'static',
  `table_name` tinytext DEFAULT NULL,
  `items` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_collection`
--

LOCK TABLES `sys_collection` WRITE;
/*!40000 ALTER TABLE `sys_collection` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_collection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_collection_entries`
--

DROP TABLE IF EXISTS `sys_collection_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_collection_entries` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_collection_entries`
--

LOCK TABLES `sys_collection_entries` WRITE;
/*!40000 ALTER TABLE `sys_collection_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_collection_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file`
--

DROP TABLE IF EXISTS `sys_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `last_indexed` int(11) NOT NULL DEFAULT 0,
  `missing` smallint(6) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `type` varchar(10) NOT NULL DEFAULT '',
  `metadata` int(11) NOT NULL DEFAULT 0,
  `identifier` text DEFAULT NULL,
  `identifier_hash` varchar(40) NOT NULL DEFAULT '',
  `folder_hash` varchar(40) NOT NULL DEFAULT '',
  `extension` varchar(255) NOT NULL DEFAULT '',
  `mime_type` varchar(255) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `sha1` varchar(40) NOT NULL DEFAULT '',
  `size` bigint(20) unsigned NOT NULL DEFAULT 0,
  `creation_date` int(11) NOT NULL DEFAULT 0,
  `modification_date` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `sel01` (`storage`,`identifier_hash`),
  KEY `folder` (`storage`,`folder_hash`),
  KEY `tstamp` (`tstamp`),
  KEY `lastindex` (`last_indexed`),
  KEY `sha1` (`sha1`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=164 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file`
--

LOCK TABLES `sys_file` WRITE;
/*!40000 ALTER TABLE `sys_file` DISABLE KEYS */;
INSERT INTO `sys_file` VALUES (1,0,1550653951,0,0,0,'2',0,'/typo3/sysext/extensionmanager/Resources/Public/Images/OfficialBadge.svg','d22aa59153acac7bde2c812e19692ef3d67fe028','1cf85ef1d73acd511c8fa41549b4b86abf0f0e08','svg','image/svg+xml','OfficialBadge.svg','e60b9dbea1fc2711b7cf2445bd0a6f6b3391c9c6',8892,1549020173,1548151924),(3,0,1634548155,1634550227,0,1,'1',0,'/pizpalue/forms/GeneralContact.form.yaml','61f64e8241a78b9114819a793907eaeddb9f4268','41f59af009ee502633babd4749aebe179cf55b86','yaml','text/plain','GeneralContact.form.yaml','4537d405ab980baa8e4abe5928e2bbb50d4e38db',2868,1633601557,1633601557),(8,0,1634548156,1634550227,0,1,'2',0,'/pizpalue/icons/_ionicons_svg_ios-rocket.svg','f77d1f2409db4699d8c27abda1c5f119ffe70f3c','277966f15f79d765c6a0234ff74cc293f009c781','svg','image/svg+xml','_ionicons_svg_ios-rocket.svg','9278465a5d1228419dd75cb3480ab6d48b043c1c',936,1633601557,1633601557),(9,0,1634548155,1634550227,0,1,'2',0,'/pizpalue/icons/_ionicons_svg_ios-eye.svg','c50906192cb4247ac65d2b8b3475e95330e5a8bc','277966f15f79d765c6a0234ff74cc293f009c781','svg','image/svg+xml','_ionicons_svg_ios-eye.svg','8f1ca511989f851e82c3163f00920752cf3be789',657,1633601557,1633601557),(10,0,1634548155,1634550227,0,1,'2',0,'/pizpalue/icons/_ionicons_svg_ios-apps.svg','dc3d0797e4c71698fce2d3564c922792972c2608','277966f15f79d765c6a0234ff74cc293f009c781','svg','image/svg+xml','_ionicons_svg_ios-apps.svg','3800ad201042956c4bdabf407f9411285da9d17d',744,1633601557,1633601557),(107,0,1550654024,0,0,0,'2',0,'/typo3conf/ext/pizpalue/Resources/Public/Images/logo.svg','f58aecbf54576a74b25ac2b41de7ea67ab111985','dd94046bf22bb2ceaab9445e61808b94503ecba0','svg','image/svg+xml','logo.svg','f06d376c263f2fd9b38b3fd2bfacd746204689ff',6175,1550653973,1550653973),(108,0,1550654024,0,0,0,'2',0,'/typo3conf/ext/pizpalue/Resources/Public/Images/logo_inv.svg','6f173dfaa393763e1afe9baeac4ec8fcd222f105','dd94046bf22bb2ceaab9445e61808b94503ecba0','svg','image/svg+xml','logo_inv.svg','af6376bfe3872bccb5fcfe80ded9bfd118ab7898',6131,1550653973,1550653973),(109,0,1550654025,0,0,0,'2',0,'/typo3conf/ext/bootstrap_package/Resources/Public/Images/Icons/Ionicons/cube.svg','53c5eba1e15081cc075a5f9b45ec066307820c92','8c9fb93e56adfc16399e09008e98524eaf0381d6','svg','image/svg+xml','cube.svg','4a28e17279d0fafea57a5eb8525cd4ead9078ea7',1101,1550653974,1550653974),(110,0,1550654025,0,0,0,'2',0,'/typo3conf/ext/bootstrap_package/Resources/Public/Images/Icons/Ionicons/android-add.svg','0cff5113a5c7a9dd54b825a7f7880ddca3c6ef49','8c9fb93e56adfc16399e09008e98524eaf0381d6','svg','image/svg+xml','android-add.svg','6eccc0775aca6022c9712bb6d476c07da0adcc9c',170,1550653974,1550653974),(111,0,1550654025,0,0,0,'2',0,'/typo3conf/ext/bootstrap_package/Resources/Public/Images/Icons/Ionicons/ios-settings-strong.svg','a205e4ada228a2ff5bab99a9e0d7d2faf0a1b440','8c9fb93e56adfc16399e09008e98524eaf0381d6','svg','image/svg+xml','ios-settings-strong.svg','29d20cda98a2ec04cc2edcdcbfa2b04958da35e3',543,1550653974,1550653974),(112,0,1551332875,0,0,0,'1',0,'/typo3conf/ext/bootstrap_package/Resources/Private/Forms/Contact.form.yaml','2a55626b114d39e0df900fed7de4bce280b525e8','cb325869a98c4a4b1426fc4e5bff6efce9ef3234','yaml','text/plain','Contact.form.yaml','81cc5aae0a367bdf5cb3481b993f58c44f34730b',4738,1550653974,1550653974),(114,0,1551379380,0,0,0,'2',0,'/typo3conf/ext/bootstrap_package/Resources/Public/Images/BootstrapPackage.svg','53b7aaf32363271515e80e6c7b25293292185218','27aadec2782a38a84423e8476091a41d1dbdbc06','svg','image/svg+xml','BootstrapPackage.svg','432a35f0e0b0c1ec08dd5ad94b5903d93090403a',5508,1550653974,1550653974),(115,0,1551379380,0,0,0,'2',0,'/typo3conf/ext/bootstrap_package/Resources/Public/Images/BootstrapPackageInverted.svg','5b24af7f7f2c99d8a6188015bc8298396b952ab7','27aadec2782a38a84423e8476091a41d1dbdbc06','svg','image/svg+xml','BootstrapPackageInverted.svg','4725d40dd7fcd037fb7b12918b91d2c40c1acc3f',5444,1550653974,1550653974),(131,0,1634548156,1634550227,0,1,'2',0,'/pizpalue/icons/_ionicons_svg_md-git-branch.svg','b62ca3d53480a7a6ea032323c5851a29875ae98d','277966f15f79d765c6a0234ff74cc293f009c781','svg','image/svg+xml','_ionicons_svg_md-git-branch.svg','b109b283597f824c64cb891643a448b36c4e6ce2',794,1633601557,1633601557),(132,0,1634548156,1634550227,0,1,'2',0,'/pizpalue/icons/_ionicons_svg_md-star-outline.svg','10544694c3dbd32cbb9c3fcea0a1307e519706e5','277966f15f79d765c6a0234ff74cc293f009c781','svg','image/svg+xml','_ionicons_svg_md-star-outline.svg','a469e5acbfe65576d1b3f54e7ffb7d83ac418bd4',551,1633601557,1633601557),(133,0,1634548156,1634550227,0,1,'2',0,'/pizpalue/icons/_ionicons_svg_md-stopwatch.svg','0fcb72914c87e32a5992b9c51d29225472a0f33c','277966f15f79d765c6a0234ff74cc293f009c781','svg','image/svg+xml','_ionicons_svg_md-stopwatch.svg','813ea27e4160d1d3187dac6f860e6b3b5ca9e71a',677,1633601557,1633601557),(134,0,1634548155,1634550227,0,1,'2',0,'/pizpalue/icons/_ionicons_svg_ios-keypad.svg','ecd36110ce07a3b1c83db49ab9ce4b38e7d13711','277966f15f79d765c6a0234ff74cc293f009c781','svg','image/svg+xml','_ionicons_svg_ios-keypad.svg','664a7731f6cb9457bc3e6d53cad1e3e2118335c4',1008,1633601557,1633601557),(141,0,1602651319,0,0,0,'2',0,'/typo3conf/ext/pizpalue/Extensions/news/Resources/Public/Images/knewsticker3.png','6143bc1b719814d092f423dfdf158e8eeb4bf6ad','3879b2cd4eea90d01e841aa6cc3435be3ecd8ce8','png','image/png','knewsticker3.png','853d5c2b0563a9ba79db9c3f191c7a234cadd64d',34964,1600502409,1600502409),(146,0,1613469525,0,0,0,'2',0,'/typo3conf/ext/pizpalue/Resources/Public/Images/backend-login-logo.png','889b5399229a788fa2ffc347045e08aafb3091ea','dd94046bf22bb2ceaab9445e61808b94503ecba0','png','image/png','backend-login-logo.png','96e541d48dc5adfe67df76e65887e8df34323040',35948,1605897902,1605897902),(149,0,1623078230,1634550227,0,1,'1',0,'/.htaccess','3450b1e7f2decdc58edd085ce04b19bc7f5d6fac','42099b4af021e53fd8fd4e056c2568d7c2e3ffa8','htaccess','text/plain','.htaccess','c0a8c528b8fade00660181fa87f5960cd42fe398',1645,1615095235,1615095235),(153,0,1634112199,1634550227,0,1,'2',0,'/grevman/Images/Flower.jpg','90f9f93d6d46bf8406ab9243e845de5750505141','3ca9be218693b7053c940d70813c5e10c1ddb3fb','jpg','image/jpeg','Flower.jpg','5c821b2dac07c0eb54768afe489d4d1cf26e619b',91442,1634112184,1634112184),(154,0,1634112991,1634550227,0,1,'5',0,'/grevman/Documents/Snowman.pdf','23a0d622e3ba327b5a40c56def6fb160dce67ec9','4be2cffa9cd60eb90312c6b28f550dc4c84c4589','pdf','application/pdf','Snowman.pdf','ce9a3382919a1146befd2fddfb732909173ae76d',235686,1634112973,1634112837),(156,0,1634548155,1634550227,0,1,'1',0,'/_temp_/index.html','1cd5eec12b9b11599c0b4c6b2d43342c4fb53a7b','0258f8a5f703dd44c350fbfcddeecb1634d46ad4','html','text/html','index.html','86f257eae12059ed5daf12ce6e5508f5f893012a',116,1633601541,1633601541),(157,0,1634548156,1634550227,0,1,'2',0,'/pizpalue/icons/_ionicons_svg_ios-star-outline.svg','bedef99f67a4e2dae525e72bad35e56a283d3ddb','277966f15f79d765c6a0234ff74cc293f009c781','svg','image/svg+xml','_ionicons_svg_ios-star-outline.svg','458f41c127c89c3c6e5c455e0da87c29f76f4b17',890,1633601557,1633601557),(158,0,1634549575,1634550227,0,1,'0',0,'/user_upload/index.html','c25533f303185517ca3e1e24b215d53aa74076d2','19669f1e02c2f16705ec7587044c66443be70725','html','inode/x-empty','index.html','da39a3ee5e6b4b0d3255bfef95601890afd80709',0,1633601541,1633601541),(159,0,1634549575,1634550227,0,1,'1',0,'/user_upload/_temp_/importexport/index.html','68614dc2826769e93d8a8ead62af30ac99aaa83a','0795cf796b4fc959be0ec00b183c0f47609dd9a5','html','text/html','index.html','86f257eae12059ed5daf12ce6e5508f5f893012a',116,1633601541,1633601541),(160,0,1634549575,1634550227,0,1,'0',0,'/user_upload/_temp_/index.html','a3ef597b554ed2a28c720b3e90e51edc9ec642b1','4e0743c93934dd9a02564d8e654d714bd2dc3d20','html','inode/x-empty','index.html','da39a3ee5e6b4b0d3255bfef95601890afd80709',0,1633601541,1633601541),(161,0,1634558479,0,0,1,'1',0,'/user_upload/_temp_/importexport/test.xml','32244c3c7d5af86813e362bb2d347db97281f442','0795cf796b4fc959be0ec00b183c0f47609dd9a5','xml','text/xml','test.xml','69c940339745525f7a36456222d0f98675b4ba4f',183421,1634558479,1634558479),(162,0,1635577310,0,0,1,'2',0,'/grevman/Images/Volleyball.jpg','fbbaa230c38da12a0ca4f8d142c26ec87dfa77d5','3ca9be218693b7053c940d70813c5e10c1ddb3fb','jpg','image/jpeg','Volleyball.jpg','5fdcf7fbfe5fb0601ba49b47eaa7beaa54abc8be',166195,1635576771,1635576429),(163,0,1635584163,0,0,1,'5',0,'/grevman/Documents/Volleyball.pdf','11990fbe7f71cfb835f34f3fb5e2427535c54ae2','4be2cffa9cd60eb90312c6b28f550dc4c84c4589','pdf','application/pdf','Volleyball.pdf','d4a210ab3866bb0e1fee56dbfecccaae7f8dca91',87666,1635576771,1635576661);
/*!40000 ALTER TABLE `sys_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_collection`
--

DROP TABLE IF EXISTS `sys_file_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_collection` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `type` varchar(30) NOT NULL DEFAULT 'static',
  `files` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `folder` text DEFAULT NULL,
  `recursive` smallint(6) NOT NULL DEFAULT 0,
  `category` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_collection`
--

LOCK TABLES `sys_file_collection` WRITE;
/*!40000 ALTER TABLE `sys_file_collection` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_collection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_metadata`
--

DROP TABLE IF EXISTS `sys_file_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_metadata` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `file` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `width` int(11) NOT NULL DEFAULT 0,
  `height` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `categories` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `file` (`file`),
  KEY `fal_filelist` (`l10n_parent`,`sys_language_uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_metadata`
--

LOCK TABLES `sys_file_metadata` WRITE;
/*!40000 ALTER TABLE `sys_file_metadata` DISABLE KEYS */;
INSERT INTO `sys_file_metadata` VALUES (1,0,1634550227,1634550227,1,0,0,NULL,0,'',0,0,0,0,0,0,0,149,NULL,0,0,NULL,NULL,0),(2,0,1634550227,1634550227,1,0,0,NULL,0,'',0,0,0,0,0,0,0,153,NULL,0,0,NULL,NULL,0),(3,0,1634550227,1634550227,1,0,0,NULL,0,'',0,0,0,0,0,0,0,154,NULL,0,0,NULL,NULL,0),(4,0,1634550227,1634550227,1,0,0,NULL,0,'',0,0,0,0,0,0,0,3,NULL,0,0,NULL,NULL,0),(5,0,1634550227,1634550227,1,0,0,NULL,0,'',0,0,0,0,0,0,0,9,NULL,0,0,NULL,NULL,0),(6,0,1634550227,1634550227,1,0,0,NULL,0,'',0,0,0,0,0,0,0,10,NULL,0,0,NULL,NULL,0),(7,0,1634550227,1634550227,1,0,0,NULL,0,'',0,0,0,0,0,0,0,134,NULL,0,0,NULL,NULL,0),(8,0,1634550227,1634550227,1,0,0,NULL,0,'',0,0,0,0,0,0,0,156,NULL,0,0,NULL,NULL,0),(9,0,1634550227,1634550227,1,0,0,NULL,0,'',0,0,0,0,0,0,0,8,NULL,0,0,NULL,NULL,0),(10,0,1634550227,1634550227,1,0,0,NULL,0,'',0,0,0,0,0,0,0,131,NULL,0,0,NULL,NULL,0),(11,0,1634550227,1634550227,1,0,0,NULL,0,'',0,0,0,0,0,0,0,132,NULL,0,0,NULL,NULL,0),(12,0,1634550227,1634550227,1,0,0,NULL,0,'',0,0,0,0,0,0,0,133,NULL,0,0,NULL,NULL,0),(13,0,1634550227,1634550227,1,0,0,NULL,0,'',0,0,0,0,0,0,0,157,NULL,0,0,NULL,NULL,0),(14,0,1634550227,1634550227,1,0,0,NULL,0,'',0,0,0,0,0,0,0,158,NULL,0,0,NULL,NULL,0),(15,0,1634550227,1634550227,1,0,0,NULL,0,'',0,0,0,0,0,0,0,159,NULL,0,0,NULL,NULL,0),(16,0,1634550227,1634550227,1,0,0,NULL,0,'',0,0,0,0,0,0,0,160,NULL,0,0,NULL,NULL,0),(17,0,1634558480,1634550933,1,0,0,NULL,0,'',0,0,0,0,0,0,0,161,NULL,0,0,NULL,NULL,0),(18,0,1635577310,1635577310,1,0,0,NULL,0,'',0,0,0,0,0,0,0,162,NULL,1280,935,NULL,NULL,0),(19,0,1635584163,1635584163,1,0,0,NULL,0,'',0,0,0,0,0,0,0,163,NULL,595,842,NULL,NULL,0);
/*!40000 ALTER TABLE `sys_file_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_processedfile`
--

DROP TABLE IF EXISTS `sys_file_processedfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_processedfile` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `original` int(11) NOT NULL DEFAULT 0,
  `identifier` varchar(512) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `configuration` blob DEFAULT NULL,
  `configurationsha1` varchar(40) NOT NULL DEFAULT '',
  `originalfilesha1` varchar(40) NOT NULL DEFAULT '',
  `task_type` varchar(200) NOT NULL DEFAULT '',
  `checksum` varchar(10) NOT NULL DEFAULT '',
  `width` int(11) DEFAULT 0,
  `height` int(11) DEFAULT 0,
  `processing_url` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `combined_1` (`original`,`task_type`(100),`configurationsha1`),
  KEY `identifier` (`storage`,`identifier`(180))
) ENGINE=InnoDB AUTO_INCREMENT=2127 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_processedfile`
--

LOCK TABLES `sys_file_processedfile` WRITE;
/*!40000 ALTER TABLE `sys_file_processedfile` DISABLE KEYS */;
INSERT INTO `sys_file_processedfile` VALUES (1,1550653969,1550653946,0,1,'',NULL,'a:7:{s:5:\"width\";i:64;s:6:\"height\";i:64;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','2b8ba9da9dae9da80f2f4e84e0d8b848075b00e6','e60b9dbea1fc2711b7cf2445bd0a6f6b3391c9c6','Image.CropScaleMask','dc56bdaaeb',64,64,NULL),(2,1587571998,1550654024,0,107,'',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','f06d376c263f2fd9b38b3fd2bfacd746204689ff','Image.CropScaleMask','4ef2460073',1669,600,NULL),(3,1587571999,1550654024,0,108,'',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','af6376bfe3872bccb5fcfe80ded9bfd118ab7898','Image.CropScaleMask','1bea6dc5fc',1669,600,NULL),(80,1585935674,1551379380,0,114,'',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','432a35f0e0b0c1ec08dd5ad94b5903d93090403a','Image.CropScaleMask','617787ccc0',244,68,NULL),(81,1585935674,1551379380,0,115,'',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','4725d40dd7fcd037fb7b12918b91d2c40c1acc3f','Image.CropScaleMask','f20bfd129e',244,68,NULL),(856,1587573085,1587572057,0,136,'',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','1194c6cf4260ec3bd6cf87c3d0e3d7b2fecfb4f2','Image.CropScaleMask','fec6586dd1',1779,600,NULL),(857,1587573085,1587572057,0,137,'',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','ef8c2a6c4f15c2e10c5573b67f2617dc01fa2e7e','Image.CropScaleMask','2d0e8c6134',1779,600,NULL),(1088,1602651319,1602651319,0,141,'',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','853d5c2b0563a9ba79db9c3f191c7a234cadd64d','Image.CropScaleMask','45d9c6d831',NULL,NULL,NULL),(1309,1613469525,1613469525,0,146,'/typo3temp/assets/_processed_/2/7/csm_backend-login-logo_63e3fc75e8.png','csm_backend-login-logo_63e3fc75e8.png','a:7:{s:5:\"width\";i:150;s:6:\"height\";i:41;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','d178e7acc997e39ab598e80ec3f5861ddd06745a','96e541d48dc5adfe67df76e65887e8df34323040','Image.CropScaleMask','63e3fc75e8',150,41,NULL),(1990,1623059699,1623059699,0,147,'',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','31a17c9dc68423a74f769bd6a285ed329abf457f','Image.CropScaleMask','b5ba4feeba',399,198,''),(1991,1623059699,1623059699,0,148,'',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','398ae2c7dc57151f036030af8cea1a05027bdb72','Image.CropScaleMask','5696c6a1aa',399,198,''),(2109,1634548526,1634548526,1,153,'/_processed_/3/7/csm_Flower_f260506965.jpg','csm_Flower_f260506965.jpg','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','5c821b2dac07c0eb54768afe489d4d1cf26e619b','Image.CropScaleMask','f260506965',68,45,NULL),(2110,1634548526,1634548526,1,154,'/_processed_/5/f/csm_Snowman_0c6848bdd0.png','csm_Snowman_0c6848bdd0.png','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','ce9a3382919a1146befd2fddfb732909173ae76d','Image.CropScaleMask','0c6848bdd0',32,45,NULL),(2111,1634741549,1634741549,1,153,'/_processed_/3/7/csm_Flower_2cf71df5e5.jpg','csm_Flower_2cf71df5e5.jpg','a:7:{s:5:\"width\";s:4:\"680c\";s:6:\"height\";i:400;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','2a81097ee34a057092f9ca96946557aa84100619','5c821b2dac07c0eb54768afe489d4d1cf26e619b','Image.CropScaleMask','2cf71df5e5',680,400,NULL),(2112,1635577310,1635577310,1,153,'/_processed_/3/7/preview_Flower_1a008a801b.jpg','preview_Flower_1a008a801b.jpg','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','5c821b2dac07c0eb54768afe489d4d1cf26e619b','Image.Preview','1a008a801b',64,43,NULL),(2113,1635577310,1635577310,1,162,'/_processed_/c/9/preview_Volleyball_da6b8727ed.jpg','preview_Volleyball_da6b8727ed.jpg','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','5fdcf7fbfe5fb0601ba49b47eaa7beaa54abc8be','Image.Preview','da6b8727ed',64,47,NULL),(2114,1635577313,1635577313,1,162,'/_processed_/c/9/csm_Volleyball_6d606be205.jpg','csm_Volleyball_6d606be205.jpg','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','5fdcf7fbfe5fb0601ba49b47eaa7beaa54abc8be','Image.CropScaleMask','6d606be205',62,45,NULL),(2115,1635577329,1635577329,1,162,'/_processed_/c/9/csm_Volleyball_c666a50581.jpg','csm_Volleyball_c666a50581.jpg','a:7:{s:5:\"width\";s:4:\"680c\";s:6:\"height\";i:400;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','2a81097ee34a057092f9ca96946557aa84100619','5fdcf7fbfe5fb0601ba49b47eaa7beaa54abc8be','Image.CropScaleMask','c666a50581',680,400,NULL),(2116,1635584164,1635584164,1,154,'/_processed_/5/f/preview_Snowman_70bf0e9e37.png','preview_Snowman_70bf0e9e37.png','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','ce9a3382919a1146befd2fddfb732909173ae76d','Image.Preview','70bf0e9e37',45,64,NULL),(2117,1635584164,1635584164,1,163,'/_processed_/0/e/preview_Volleyball_9ac86a8669.png','preview_Volleyball_9ac86a8669.png','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','d4a210ab3866bb0e1fee56dbfecccaae7f8dca91','Image.Preview','9ac86a8669',45,64,NULL),(2118,1635584170,1635584170,1,163,'/_processed_/0/e/csm_Volleyball_dac182d845.png','csm_Volleyball_dac182d845.png','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','d4a210ab3866bb0e1fee56dbfecccaae7f8dca91','Image.CropScaleMask','dac182d845',32,45,NULL),(2119,1639215700,1639215700,1,10,'',NULL,'a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','3800ad201042956c4bdabf407f9411285da9d17d','Image.Preview','0bf7e4a86b',64,64,''),(2120,1639215700,1639215700,1,9,'',NULL,'a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','8f1ca511989f851e82c3163f00920752cf3be789','Image.Preview','e4901614ce',64,64,''),(2121,1639215700,1639215700,1,134,'',NULL,'a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','664a7731f6cb9457bc3e6d53cad1e3e2118335c4','Image.Preview','87fe78a006',64,64,''),(2122,1639215700,1639215700,1,8,'',NULL,'a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','9278465a5d1228419dd75cb3480ab6d48b043c1c','Image.Preview','95394434f7',64,64,''),(2123,1639215700,1639215700,1,157,'',NULL,'a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','458f41c127c89c3c6e5c455e0da87c29f76f4b17','Image.Preview','3af1ecbe86',64,64,''),(2124,1639215700,1639215700,1,131,'',NULL,'a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','b109b283597f824c64cb891643a448b36c4e6ce2','Image.Preview','0565ef2d15',64,64,''),(2125,1639215700,1639215700,1,132,'',NULL,'a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','a469e5acbfe65576d1b3f54e7ffb7d83ac418bd4','Image.Preview','4f1b0bd19e',64,64,''),(2126,1639215700,1639215700,1,133,'',NULL,'a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','813ea27e4160d1d3187dac6f860e6b3b5ca9e71a','Image.Preview','f1247ab275',64,64,'');
/*!40000 ALTER TABLE `sys_file_processedfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_reference`
--

DROP TABLE IF EXISTS `sys_file_reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_reference` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  `table_local` varchar(64) NOT NULL DEFAULT '',
  `title` tinytext DEFAULT NULL,
  `description` text DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `link` varchar(1024) NOT NULL DEFAULT '',
  `crop` varchar(4000) NOT NULL DEFAULT '',
  `autoplay` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `tablenames_fieldname` (`tablenames`(32),`fieldname`(12)),
  KEY `deleted` (`deleted`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`),
  KEY `combined_1` (`l10n_parent`,`t3ver_oid`,`t3ver_wsid`,`t3ver_state`,`deleted`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=559 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_reference`
--

LOCK TABLES `sys_file_reference` WRITE;
/*!40000 ALTER TABLE `sys_file_reference` DISABLE KEYS */;
INSERT INTO `sys_file_reference` VALUES (502,224,1645092224,1639122494,1,0,0,0,0,NULL,'a:5:{s:5:\"title\";N;s:11:\"description\";N;s:9:\"uid_local\";N;s:6:\"hidden\";N;s:16:\"sys_language_uid\";N;}',0,0,0,0,0,0,0,162,1,'tx_grevman_domain_model_event','images',1,'sys_file',NULL,NULL,NULL,'','',0),(546,224,1645092224,1639123320,1,0,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,163,1,'tx_grevman_domain_model_event','files',1,'sys_file',NULL,NULL,NULL,'','',0),(547,224,1639127281,1639127038,1,1,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,162,45,'tx_grevman_domain_model_event','images',1,'sys_file',NULL,NULL,NULL,'','',0),(548,224,1639127281,1639127038,1,1,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,163,45,'tx_grevman_domain_model_event','files',1,'sys_file',NULL,NULL,NULL,'','',0),(549,224,1642609041,1642609041,0,0,0,0,0,NULL,'',0,0,0,0,0,0,0,162,46,'tx_grevman_domain_model_event','images',1,'sys_file',NULL,NULL,NULL,'','',0),(550,224,1642609041,1642609041,0,0,0,0,0,NULL,'',0,0,0,0,0,0,0,163,46,'tx_grevman_domain_model_event','files',1,'sys_file',NULL,NULL,NULL,'','',0),(551,224,1642609089,1642609089,0,0,0,0,0,NULL,'',0,0,0,0,0,0,0,162,47,'tx_grevman_domain_model_event','images',1,'sys_file',NULL,NULL,NULL,'','',0),(552,224,1642609089,1642609089,0,0,0,0,0,NULL,'',0,0,0,0,0,0,0,163,47,'tx_grevman_domain_model_event','files',1,'sys_file',NULL,NULL,NULL,'','',0),(553,224,1642609452,1642609452,0,0,0,0,0,NULL,'',0,0,0,0,0,0,0,162,48,'tx_grevman_domain_model_event','images',1,'sys_file',NULL,NULL,NULL,'','',0),(554,224,1642609452,1642609452,0,0,0,0,0,NULL,'',0,0,0,0,0,0,0,163,48,'tx_grevman_domain_model_event','files',1,'sys_file',NULL,NULL,NULL,'','',0),(555,224,1642609504,1642609504,0,0,0,0,0,NULL,'',0,0,0,0,0,0,0,162,49,'tx_grevman_domain_model_event','images',1,'sys_file',NULL,NULL,NULL,'','',0),(556,224,1642609504,1642609504,0,0,0,0,0,NULL,'',0,0,0,0,0,0,0,163,49,'tx_grevman_domain_model_event','files',1,'sys_file',NULL,NULL,NULL,'','',0),(557,224,1645095814,1644999360,0,0,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,162,50,'tx_grevman_domain_model_event','images',1,'sys_file',NULL,NULL,NULL,'','',0),(558,224,1645095814,1644999360,0,0,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,163,50,'tx_grevman_domain_model_event','files',1,'sys_file',NULL,NULL,NULL,'','',0);
/*!40000 ALTER TABLE `sys_file_reference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_storage`
--

DROP TABLE IF EXISTS `sys_file_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_storage` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `driver` tinytext DEFAULT NULL,
  `configuration` text DEFAULT NULL,
  `is_default` smallint(6) NOT NULL DEFAULT 0,
  `is_browsable` smallint(6) NOT NULL DEFAULT 0,
  `is_public` smallint(6) NOT NULL DEFAULT 0,
  `is_writable` smallint(6) NOT NULL DEFAULT 0,
  `is_online` smallint(6) NOT NULL DEFAULT 1,
  `auto_extract_metadata` smallint(6) NOT NULL DEFAULT 1,
  `processingfolder` tinytext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_storage`
--

LOCK TABLES `sys_file_storage` WRITE;
/*!40000 ALTER TABLE `sys_file_storage` DISABLE KEYS */;
INSERT INTO `sys_file_storage` VALUES (1,0,1634548746,1550653946,0,0,'This is the local fileadmin/ directory. This storage mount has been created automatically by TYPO3.','fileadmin/ (auto-created)','Local','<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"basePath\">\n                    <value index=\"vDEF\">fileadmin/</value>\n                </field>\n                <field index=\"pathType\">\n                    <value index=\"vDEF\">relative</value>\n                </field>\n                <field index=\"caseSensitive\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"baseUri\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',1,1,1,1,1,1,NULL);
/*!40000 ALTER TABLE `sys_file_storage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_filemounts`
--

DROP TABLE IF EXISTS `sys_filemounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_filemounts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `path` varchar(255) NOT NULL DEFAULT '',
  `base` int(10) unsigned NOT NULL DEFAULT 0,
  `read_only` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_filemounts`
--

LOCK TABLES `sys_filemounts` WRITE;
/*!40000 ALTER TABLE `sys_filemounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_filemounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_history`
--

DROP TABLE IF EXISTS `sys_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_history` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `actiontype` smallint(6) NOT NULL DEFAULT 0,
  `usertype` varchar(2) NOT NULL DEFAULT 'BE',
  `userid` int(10) unsigned DEFAULT NULL,
  `originaluserid` int(10) unsigned DEFAULT NULL,
  `recuid` int(11) NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `history_data` mediumtext DEFAULT NULL,
  `workspace` int(11) DEFAULT 0,
  `correlation_id` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `recordident_1` (`tablename`(100),`recuid`),
  KEY `recordident_2` (`tablename`(100),`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=492 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_history`
--

LOCK TABLES `sys_history` WRITE;
/*!40000 ALTER TABLE `sys_history` DISABLE KEYS */;
INSERT INTO `sys_history` VALUES (1,1639122726,4,'BE',1,0,86,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:70e14a4f69bbb077a4ba6deb845b78db'),(2,1639122726,4,'BE',1,0,87,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:c9c890101c0f7a027ed0b11b2372de2e'),(3,1639122726,4,'BE',1,0,88,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:7fde984554855a73f56cc0a561852bc3'),(4,1639122726,4,'BE',1,0,89,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:d099bfeb4c00f4624cc4a7d46ce1a456'),(5,1639122726,4,'BE',1,0,90,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:c50876bc9b2ad9276e0bd8c7e0f5f007'),(6,1639122726,4,'BE',1,0,91,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:f25de1c5e9eba0b1f2a6cdb991ea5eaa'),(7,1639122726,4,'BE',1,0,92,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:f187ad336d9b3e1d903583542c614e31'),(8,1639122726,4,'BE',1,0,93,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:16b4f9452130cfc3acb6966828a69d82'),(9,1639122726,4,'BE',1,0,94,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:d832d73af09fceab890da62ef9f730bf'),(10,1639122726,4,'BE',1,0,95,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:3ba39ae75bcaabfd2c97932e41cbb41c'),(11,1639122726,4,'BE',1,0,96,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:a7e2d535691a1191ddaf82b4e3784fe0'),(12,1639122726,4,'BE',1,0,97,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:b0aea09e368ec73fb6131b8faa430fea'),(13,1639122726,4,'BE',1,0,98,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:0909fc1e347197c76fc95cf67826f472'),(14,1639122726,4,'BE',1,0,99,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:721bad31a317f15c1c1631357c981df8'),(15,1639122726,4,'BE',1,0,100,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:a498cf0e5be7a77bf453814bc2199deb'),(16,1639122726,4,'BE',1,0,101,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:f3326fb6909f56c0f30a2a035a582626'),(17,1639122726,4,'BE',1,0,102,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:7b5f865c6fb4258a2787097e522ff258'),(18,1639122726,4,'BE',1,0,103,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:6db4534c5ec1ca197c38d7d1c3bed5ed'),(19,1639122726,4,'BE',1,0,104,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:9a43b7aa78701abd0eca4ef071f2ef79'),(20,1639122726,4,'BE',1,0,105,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:7533a677d530630e8e75d56e679dbc1b'),(21,1639122726,4,'BE',1,0,106,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:9afdecafa0ced03d63d77c73ff60270f'),(22,1639122726,4,'BE',1,0,107,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:6b10bb72942909b202ecf6d0ba86b641'),(23,1639122726,4,'BE',1,0,108,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:b25aa00e826ba12303b8a47d1b3e1e32'),(24,1639122726,4,'BE',1,0,109,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:e8f048312ec759241caa49ad5936eddb'),(25,1639122726,4,'BE',1,0,110,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:fff1fde80faa11dae6e8b7008fad1fa3'),(26,1639122726,4,'BE',1,0,111,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:af9ce2d535770f058e8cd8e73ae3d7b9'),(27,1639122726,4,'BE',1,0,112,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:863dc748c8acb0ac95d5504e0f313495'),(28,1639122726,4,'BE',1,0,113,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:84005170138fa7bc5fa3cd74f9e44538'),(29,1639122726,4,'BE',1,0,114,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:cd7996f5dcc9b796b4226191675967b9'),(30,1639122726,4,'BE',1,0,115,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:ae96fdf560d9b1689e3ded4e1823893d'),(31,1639122726,4,'BE',1,0,116,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:c683ce7abdedeb39f7c8a3c2b9099257'),(32,1639122726,4,'BE',1,0,117,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:7fa29eef579b8e9e73ee96f6382cf9d4'),(33,1639122726,4,'BE',1,0,118,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:d81736e4e72827022ad463578af92563'),(34,1639122726,4,'BE',1,0,119,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:2d4f4fcb30f62b59cab62fecb4b0980b'),(35,1639122726,4,'BE',1,0,120,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:344a74a458681f0ec10ec9b271d1033c'),(36,1639122726,4,'BE',1,0,121,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:e56ee4decd6a282e00554d2f82b1e9e9'),(37,1639122726,4,'BE',1,0,122,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:c0f3d5ab0f292e0bc9f98b369dfaeb61'),(38,1639122726,4,'BE',1,0,123,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:8aa922b2059358af5c7cd8c2e4b8bd48'),(39,1639122726,4,'BE',1,0,124,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:44b6e387ec7235d0da01f97016961020'),(40,1639122726,4,'BE',1,0,125,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:c33a3a06a6db4b51be235463c41baad3'),(41,1639122726,4,'BE',1,0,126,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:20ce5fdd412dc99ea17b3471787d37ea'),(42,1639122726,4,'BE',1,0,127,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:0a2098b50cbc3c365df4c48cd4af5ef8'),(43,1639122726,4,'BE',1,0,128,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:911be01f8da993d9d068afb084cfefb8'),(44,1639122726,4,'BE',1,0,129,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:a9a7bc7c25d1d19bc9931f1dcebbeb6c'),(45,1639122726,4,'BE',1,0,130,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:3c42454f428ddde7a041e76a0c097157'),(46,1639122726,4,'BE',1,0,131,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:d1c638a4da91ff420c5f6a63562e9c98'),(47,1639122726,4,'BE',1,0,132,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:3db544ca8da98eb0b39ff73bfc31e26a'),(48,1639122726,4,'BE',1,0,133,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:863217aa4629185999c6d6d00c681277'),(49,1639122726,4,'BE',1,0,134,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:50f9df83425d7b79ac76c1690a3a9f98'),(50,1639122726,4,'BE',1,0,135,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:0a76e418f31281a8704630b844ecc5d8'),(51,1639122726,4,'BE',1,0,136,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:07124a2e9ea029fb7be1b075e6d711fb'),(52,1639122726,4,'BE',1,0,137,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:cd26f0c2bce00c7d7fa49ef6a541f70b'),(53,1639122726,4,'BE',1,0,138,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:08777bcb4a339bd5a4b47d626fd1e512'),(54,1639122726,4,'BE',1,0,139,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:2bcf93c8ee3d5a36f3a8595f493a797c'),(55,1639122726,4,'BE',1,0,140,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:4eff5ad4902798a3c4428fc5032d1f3b'),(56,1639122726,4,'BE',1,0,141,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:2360be85de6332c2f49c4d25fc269ef7'),(57,1639122726,4,'BE',1,0,142,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:d2a43d58d3a2d3f3c00330446f786521'),(58,1639122726,4,'BE',1,0,143,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:c5f8dbf51ab3c9c8468b5f18f0a14573'),(59,1639122726,4,'BE',1,0,144,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:697cbf3374306548ecf409ae50cca9da'),(60,1639122726,4,'BE',1,0,145,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:426466905c3649ef5d63893eed4aa801'),(61,1639122726,4,'BE',1,0,146,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:62ee3790c516fd74268cf16a2ace0aa3'),(62,1639122726,4,'BE',1,0,147,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:96104468df10b2c123d718e626d4453a'),(63,1639122726,4,'BE',1,0,148,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:bd328582422542e9e00ca899ff16b5ca'),(64,1639122726,4,'BE',1,0,149,'tx_grevman_domain_model_registration',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:8a26448c553f86bb676573dd0dcabef5'),(65,1639122726,4,'BE',1,0,72,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:31c5385bb322ab15eb29b1e4b2649e3c'),(66,1639122726,4,'BE',1,0,73,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:1c9fc1df18bdbd01eb68639c94369892'),(67,1639122726,4,'BE',1,0,74,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:c3b4e5c461ee62baf71431fc7c56cf7f'),(68,1639122726,4,'BE',1,0,75,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:42bb82bcc20a09a7e0afddc9ca6f11a8'),(69,1639122726,4,'BE',1,0,76,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:0ccb59b16258f28755cee02b7486ce15'),(70,1639122726,4,'BE',1,0,77,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:d8cf5254c5c1fbca0377740d9ab8f6f5'),(71,1639122726,4,'BE',1,0,78,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:a2b4097880935b30ff03d5c777eea700'),(72,1639122726,4,'BE',1,0,79,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:1c9398f561a86d42dbe260347b254340'),(73,1639122726,4,'BE',1,0,80,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:e11933ad07e82d6c9cda9f99c37819bb'),(74,1639122726,4,'BE',1,0,81,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:63b0a0a99ae1a8f9c4e27387b87d6cb8'),(75,1639122726,4,'BE',1,0,82,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:aa96a2c931c4ea48970d0d60d7c5491e'),(76,1639122726,4,'BE',1,0,83,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:4ef393a2772a5b169f62b89e76c984c1'),(77,1639122726,4,'BE',1,0,84,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:cf1a4d58a5936a368acec3005c67fbdb'),(78,1639122726,4,'BE',1,0,85,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:84e552348134133a136875e50af96f9b'),(79,1639122726,4,'BE',1,0,86,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:e2a76592404d8da6786ca69b97ff86a6'),(80,1639122726,4,'BE',1,0,87,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:55d90d9ce3b03d45161098f464a63f91'),(81,1639122726,4,'BE',1,0,88,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:d88403f78b26b80afcc78c05a26aa2fd'),(82,1639122726,4,'BE',1,0,89,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:1300d66896bb811cdcab95a10d565c2a'),(83,1639122726,4,'BE',1,0,90,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:efed917d2e6ef7c4a1931b2ea1c00be8'),(84,1639122726,4,'BE',1,0,91,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:0bb3cec291b3d35d209e25765365535c'),(85,1639122726,4,'BE',1,0,92,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:c3e4ae54517b1f30c0c2da05a0489f8b'),(86,1639122726,4,'BE',1,0,93,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:698eebe5caa8f26d638385e6eb6a1b05'),(87,1639122726,4,'BE',1,0,94,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:762346ef8f60a7ccf761bcb3fc21c850'),(88,1639122726,4,'BE',1,0,95,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:e9e635cb287794fa94dd8e8e3ab6269a'),(89,1639122726,4,'BE',1,0,96,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:45db3949fc6c42a2f0f8f293940c9623'),(90,1639122726,4,'BE',1,0,97,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:e770860127a79c692b0316e6a651255f'),(91,1639122726,4,'BE',1,0,98,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:3ed1a8c25dfce29fd5e6aa59f02266a8'),(92,1639122726,4,'BE',1,0,99,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:e8ad4c08b680fea5ab74b659c73e10cb'),(93,1639122726,4,'BE',1,0,100,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:9e85c4e1ea01ba7f522c15dab6dd0ec0'),(94,1639122726,4,'BE',1,0,101,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:ab64f2af914cac75b4fb1b07336d0770'),(95,1639122726,4,'BE',1,0,102,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:793d668f94d9017d788c702ae5bfbce6'),(96,1639122726,4,'BE',1,0,103,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:00452b43e490600a7f2d8cccd5596b33'),(97,1639122726,4,'BE',1,0,104,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:e6f5335e36f5c8f27fa40ac2d52af017'),(98,1639122726,4,'BE',1,0,105,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:b4ac726f1a757a2b32de300f86045502'),(99,1639122726,4,'BE',1,0,106,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:a06d23301242e13a0295dd357e8a64a5'),(100,1639122726,4,'BE',1,0,107,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:7871deac58a7baf9184aa72483173542'),(101,1639122726,4,'BE',1,0,108,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:2559f5570ecb26fb850af3f26d859352'),(102,1639122726,4,'BE',1,0,109,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:b01cbbda8f435eae0eda22f5ed581fb3'),(103,1639122726,4,'BE',1,0,110,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:065a98da460587b6e87f6b7088c1b0eb'),(104,1639122726,4,'BE',1,0,111,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:9761229d8d3e6b32233c2c5a0ea99f2a'),(105,1639122726,4,'BE',1,0,112,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:aef3bbb7a88d854cb3a8f31ec9356c6a'),(106,1639122726,4,'BE',1,0,113,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:d9851b09d229354453dcdaf305f097e9'),(107,1639122726,4,'BE',1,0,114,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:81f49e78343ac4d1aa89d53da0fb0f85'),(108,1639122726,4,'BE',1,0,115,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:333b0515cb5ae80beb039d1d6fdcdea6'),(109,1639122726,4,'BE',1,0,116,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:bd9abbe6816c9aad1dd4546f686f3f73'),(110,1639122726,4,'BE',1,0,117,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:f1f03e65bdb900f96b0fbe5f58c69be9'),(111,1639122726,4,'BE',1,0,118,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:5dca0aa17c534edd72ccddedb1655490'),(112,1639122726,4,'BE',1,0,119,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:997eb183c566baf62f61c7214d77640b'),(113,1639122726,4,'BE',1,0,120,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:6061205992172f51c2f19da168db86eb'),(114,1639122726,4,'BE',1,0,121,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:265ac4f3b0f8cbc220d940e708331a01'),(115,1639122726,4,'BE',1,0,122,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:17d6fa2e2a086e4835fc598e2a46bf8b'),(116,1639122726,4,'BE',1,0,123,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:e5c6280ad28301fd3d568d9aed915ef5'),(117,1639122726,4,'BE',1,0,124,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:79244756c4921e27d0ebc4cacd849b79'),(118,1639122726,4,'BE',1,0,125,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:d1e8b653d9a395cc3c23707dc2a51e41'),(119,1639122726,4,'BE',1,0,126,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:49250c968a33fab9847c9458002ba1ff'),(120,1639122726,4,'BE',1,0,127,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:4363c7bc78797ed13a8ace714590273b'),(121,1639122726,4,'BE',1,0,128,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:612271e5a8c703fbdc936ca96d9e5493'),(122,1639122726,4,'BE',1,0,129,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:2311db6e6a59468318d91b7033d4c1fc'),(123,1639122726,4,'BE',1,0,130,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:4d222ae939836c8f69ab4a69407d0a76'),(124,1639122726,4,'BE',1,0,131,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:a09c03780204692f6d693745ea53a0c0'),(125,1639122726,4,'BE',1,0,132,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:5a73b2caf8fb25818c7a2e750f3a098b'),(126,1639122726,4,'BE',1,0,133,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:31502c2c6a82de6c598ab7e3b4bf9297'),(127,1639122726,4,'BE',1,0,134,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:acab7f1a1106e02709e982f9244ef767'),(128,1639122726,4,'BE',1,0,135,'tx_grevman_domain_model_note',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:d73d1fd97588930403e4e5b83c06f105'),(129,1639122726,4,'BE',1,0,511,'sys_file_reference',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:3136a9765504489ac35174efdfa9e74f'),(130,1639122726,4,'BE',1,0,512,'sys_file_reference',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:f713cbca03be8f6f4b8f5eed20dec11a'),(131,1639122726,4,'BE',1,0,513,'sys_file_reference',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:93fe8084082ae9d9308e7ed53dd83536'),(132,1639122726,4,'BE',1,0,514,'sys_file_reference',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:9e289842bb0d4c91f73d5835c139b8d4'),(133,1639122726,4,'BE',1,0,515,'sys_file_reference',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:e2b61ac3a4934020a03240d5514f86e8'),(134,1639122726,4,'BE',1,0,516,'sys_file_reference',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:4aacab83c0d1594d1143aad3a431f917'),(135,1639122726,4,'BE',1,0,517,'sys_file_reference',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:1380f0d396094d41f2cf356887df1a62'),(136,1639122726,4,'BE',1,0,518,'sys_file_reference',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:0e0e1ea68a6ed5746e5d48bba74a60d9'),(137,1639122726,4,'BE',1,0,519,'sys_file_reference',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:fa49a107e5fa92181204693cb8170eb7'),(138,1639122726,4,'BE',1,0,520,'sys_file_reference',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:ee4be2d0a4ec4507e4993f0fc27299df'),(139,1639122726,4,'BE',1,0,521,'sys_file_reference',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:070897ddeb4051d7638434fdcae84eed'),(140,1639122726,4,'BE',1,0,522,'sys_file_reference',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:ba8c13bec5be157c46e3ea0b5144c6c1'),(141,1639122726,4,'BE',1,0,523,'sys_file_reference',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:28eecab5721f54a3c81b063d33be9d4a'),(142,1639122726,4,'BE',1,0,524,'sys_file_reference',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:4946b44fc110e16b95300af9e90e720a'),(143,1639122726,4,'BE',1,0,525,'sys_file_reference',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:2d7930af7a1d29d3a71fd4b843850780'),(144,1639122726,4,'BE',1,0,526,'sys_file_reference',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:0fe9a7df024c532592c0a3ac94c8c4c9'),(145,1639122726,4,'BE',1,0,527,'sys_file_reference',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:1af996db9e80de211693b5180c57844c'),(146,1639122726,4,'BE',1,0,528,'sys_file_reference',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:d0ceddc63424364ff4ca6b667fd3b436'),(147,1639122726,4,'BE',1,0,529,'sys_file_reference',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:7317353a8ae1d2eb4fce882e8ae17b24'),(148,1639122726,4,'BE',1,0,530,'sys_file_reference',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:5315ea495c0585e87b86d89e40599b99'),(149,1639122726,4,'BE',1,0,531,'sys_file_reference',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:58ef51052fba195e42ab6475be53ede1'),(150,1639122726,4,'BE',1,0,532,'sys_file_reference',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:75efc810d8c1b147e0866fa487138a04'),(151,1639122726,4,'BE',1,0,533,'sys_file_reference',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:ee01c92b21dd98edb71755e575fbf0b6'),(152,1639122726,4,'BE',1,0,534,'sys_file_reference',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:6e4a7e6daf783a60a7120b5d4193d639'),(153,1639122726,4,'BE',1,0,535,'sys_file_reference',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:92d41f93a0c0a416360fdee0d15c6dcf'),(154,1639122726,4,'BE',1,0,536,'sys_file_reference',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:45d2613125797d3a3356ae5610126587'),(155,1639122726,4,'BE',1,0,537,'sys_file_reference',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:07f07c73aa5568311909acc4aaf3acc4'),(156,1639122726,4,'BE',1,0,538,'sys_file_reference',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:00e0064cf91580505a6d18ff011a96e8'),(157,1639122726,4,'BE',1,0,539,'sys_file_reference',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:d1fd0fc1978c8410394fabfff2ef532d'),(158,1639122726,4,'BE',1,0,540,'sys_file_reference',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:419b32308bb4868531a1cb5d9cbd75f9'),(159,1639122726,4,'BE',1,0,541,'sys_file_reference',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:edf567ab00b22fb6c49c5156a8a303aa'),(160,1639122726,4,'BE',1,0,542,'sys_file_reference',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:e7ef8376a2c890b5e6ad7b5c92a9124a'),(161,1639122726,4,'BE',1,0,42,'tx_grevman_domain_model_event',NULL,0,'0400$bcbba400bb4228ba798aa7570beceac4:482962f4119d4a34e83adc5b625e35a7'),(162,1639122797,4,'BE',1,0,511,'sys_file_reference',NULL,0,'0400$113ae85ac9b6fe3e61609600b1df7c42:3136a9765504489ac35174efdfa9e74f'),(163,1639122797,4,'BE',1,0,512,'sys_file_reference',NULL,0,'0400$113ae85ac9b6fe3e61609600b1df7c42:f713cbca03be8f6f4b8f5eed20dec11a'),(164,1639122797,4,'BE',1,0,513,'sys_file_reference',NULL,0,'0400$113ae85ac9b6fe3e61609600b1df7c42:93fe8084082ae9d9308e7ed53dd83536'),(165,1639122797,4,'BE',1,0,514,'sys_file_reference',NULL,0,'0400$113ae85ac9b6fe3e61609600b1df7c42:9e289842bb0d4c91f73d5835c139b8d4'),(166,1639122797,4,'BE',1,0,515,'sys_file_reference',NULL,0,'0400$113ae85ac9b6fe3e61609600b1df7c42:e2b61ac3a4934020a03240d5514f86e8'),(167,1639122797,4,'BE',1,0,516,'sys_file_reference',NULL,0,'0400$113ae85ac9b6fe3e61609600b1df7c42:4aacab83c0d1594d1143aad3a431f917'),(168,1639122797,4,'BE',1,0,517,'sys_file_reference',NULL,0,'0400$113ae85ac9b6fe3e61609600b1df7c42:1380f0d396094d41f2cf356887df1a62'),(169,1639122797,4,'BE',1,0,518,'sys_file_reference',NULL,0,'0400$113ae85ac9b6fe3e61609600b1df7c42:0e0e1ea68a6ed5746e5d48bba74a60d9'),(170,1639122797,4,'BE',1,0,519,'sys_file_reference',NULL,0,'0400$113ae85ac9b6fe3e61609600b1df7c42:fa49a107e5fa92181204693cb8170eb7'),(171,1639122797,4,'BE',1,0,520,'sys_file_reference',NULL,0,'0400$113ae85ac9b6fe3e61609600b1df7c42:ee4be2d0a4ec4507e4993f0fc27299df'),(172,1639122797,4,'BE',1,0,521,'sys_file_reference',NULL,0,'0400$113ae85ac9b6fe3e61609600b1df7c42:070897ddeb4051d7638434fdcae84eed'),(173,1639122797,4,'BE',1,0,522,'sys_file_reference',NULL,0,'0400$113ae85ac9b6fe3e61609600b1df7c42:ba8c13bec5be157c46e3ea0b5144c6c1'),(174,1639122797,4,'BE',1,0,523,'sys_file_reference',NULL,0,'0400$113ae85ac9b6fe3e61609600b1df7c42:28eecab5721f54a3c81b063d33be9d4a'),(175,1639122797,4,'BE',1,0,524,'sys_file_reference',NULL,0,'0400$113ae85ac9b6fe3e61609600b1df7c42:4946b44fc110e16b95300af9e90e720a'),(176,1639122797,4,'BE',1,0,525,'sys_file_reference',NULL,0,'0400$113ae85ac9b6fe3e61609600b1df7c42:2d7930af7a1d29d3a71fd4b843850780'),(177,1639122797,4,'BE',1,0,526,'sys_file_reference',NULL,0,'0400$113ae85ac9b6fe3e61609600b1df7c42:0fe9a7df024c532592c0a3ac94c8c4c9'),(178,1639122797,4,'BE',1,0,527,'sys_file_reference',NULL,0,'0400$113ae85ac9b6fe3e61609600b1df7c42:1af996db9e80de211693b5180c57844c'),(179,1639122797,4,'BE',1,0,528,'sys_file_reference',NULL,0,'0400$113ae85ac9b6fe3e61609600b1df7c42:d0ceddc63424364ff4ca6b667fd3b436'),(180,1639122797,4,'BE',1,0,529,'sys_file_reference',NULL,0,'0400$113ae85ac9b6fe3e61609600b1df7c42:7317353a8ae1d2eb4fce882e8ae17b24'),(181,1639122797,4,'BE',1,0,530,'sys_file_reference',NULL,0,'0400$113ae85ac9b6fe3e61609600b1df7c42:5315ea495c0585e87b86d89e40599b99'),(182,1639122797,4,'BE',1,0,531,'sys_file_reference',NULL,0,'0400$113ae85ac9b6fe3e61609600b1df7c42:58ef51052fba195e42ab6475be53ede1'),(183,1639122797,4,'BE',1,0,532,'sys_file_reference',NULL,0,'0400$113ae85ac9b6fe3e61609600b1df7c42:75efc810d8c1b147e0866fa487138a04'),(184,1639122797,4,'BE',1,0,533,'sys_file_reference',NULL,0,'0400$113ae85ac9b6fe3e61609600b1df7c42:ee01c92b21dd98edb71755e575fbf0b6'),(185,1639122797,4,'BE',1,0,534,'sys_file_reference',NULL,0,'0400$113ae85ac9b6fe3e61609600b1df7c42:6e4a7e6daf783a60a7120b5d4193d639'),(186,1639122797,4,'BE',1,0,535,'sys_file_reference',NULL,0,'0400$113ae85ac9b6fe3e61609600b1df7c42:92d41f93a0c0a416360fdee0d15c6dcf'),(187,1639122802,4,'BE',1,0,536,'sys_file_reference',NULL,0,'0400$ca1ff1289c70c4f507e6bca0199e5f49:45d2613125797d3a3356ae5610126587'),(188,1639122802,4,'BE',1,0,537,'sys_file_reference',NULL,0,'0400$ca1ff1289c70c4f507e6bca0199e5f49:07f07c73aa5568311909acc4aaf3acc4'),(189,1639122802,4,'BE',1,0,538,'sys_file_reference',NULL,0,'0400$ca1ff1289c70c4f507e6bca0199e5f49:00e0064cf91580505a6d18ff011a96e8'),(190,1639122802,4,'BE',1,0,539,'sys_file_reference',NULL,0,'0400$ca1ff1289c70c4f507e6bca0199e5f49:d1fd0fc1978c8410394fabfff2ef532d'),(191,1639122802,4,'BE',1,0,540,'sys_file_reference',NULL,0,'0400$ca1ff1289c70c4f507e6bca0199e5f49:419b32308bb4868531a1cb5d9cbd75f9'),(192,1639122802,4,'BE',1,0,541,'sys_file_reference',NULL,0,'0400$ca1ff1289c70c4f507e6bca0199e5f49:edf567ab00b22fb6c49c5156a8a303aa'),(193,1639122802,4,'BE',1,0,542,'sys_file_reference',NULL,0,'0400$ca1ff1289c70c4f507e6bca0199e5f49:e7ef8376a2c890b5e6ad7b5c92a9124a'),(194,1639122802,4,'BE',1,0,42,'tx_grevman_domain_model_event',NULL,0,'0400$ca1ff1289c70c4f507e6bca0199e5f49:482962f4119d4a34e83adc5b625e35a7'),(195,1639122802,4,'BE',1,0,72,'tx_grevman_domain_model_note',NULL,0,'0400$ca1ff1289c70c4f507e6bca0199e5f49:31c5385bb322ab15eb29b1e4b2649e3c'),(196,1639122802,4,'BE',1,0,73,'tx_grevman_domain_model_note',NULL,0,'0400$ca1ff1289c70c4f507e6bca0199e5f49:1c9fc1df18bdbd01eb68639c94369892'),(197,1639122802,4,'BE',1,0,74,'tx_grevman_domain_model_note',NULL,0,'0400$ca1ff1289c70c4f507e6bca0199e5f49:c3b4e5c461ee62baf71431fc7c56cf7f'),(198,1639122802,4,'BE',1,0,75,'tx_grevman_domain_model_note',NULL,0,'0400$ca1ff1289c70c4f507e6bca0199e5f49:42bb82bcc20a09a7e0afddc9ca6f11a8'),(199,1639122802,4,'BE',1,0,76,'tx_grevman_domain_model_note',NULL,0,'0400$ca1ff1289c70c4f507e6bca0199e5f49:0ccb59b16258f28755cee02b7486ce15'),(200,1639122802,4,'BE',1,0,77,'tx_grevman_domain_model_note',NULL,0,'0400$ca1ff1289c70c4f507e6bca0199e5f49:d8cf5254c5c1fbca0377740d9ab8f6f5'),(201,1639122802,4,'BE',1,0,78,'tx_grevman_domain_model_note',NULL,0,'0400$ca1ff1289c70c4f507e6bca0199e5f49:a2b4097880935b30ff03d5c777eea700'),(202,1639122802,4,'BE',1,0,79,'tx_grevman_domain_model_note',NULL,0,'0400$ca1ff1289c70c4f507e6bca0199e5f49:1c9398f561a86d42dbe260347b254340'),(203,1639122802,4,'BE',1,0,80,'tx_grevman_domain_model_note',NULL,0,'0400$ca1ff1289c70c4f507e6bca0199e5f49:e11933ad07e82d6c9cda9f99c37819bb'),(204,1639122802,4,'BE',1,0,81,'tx_grevman_domain_model_note',NULL,0,'0400$ca1ff1289c70c4f507e6bca0199e5f49:63b0a0a99ae1a8f9c4e27387b87d6cb8'),(205,1639122802,4,'BE',1,0,82,'tx_grevman_domain_model_note',NULL,0,'0400$ca1ff1289c70c4f507e6bca0199e5f49:aa96a2c931c4ea48970d0d60d7c5491e'),(206,1639122802,4,'BE',1,0,83,'tx_grevman_domain_model_note',NULL,0,'0400$ca1ff1289c70c4f507e6bca0199e5f49:4ef393a2772a5b169f62b89e76c984c1'),(207,1639122802,4,'BE',1,0,84,'tx_grevman_domain_model_note',NULL,0,'0400$ca1ff1289c70c4f507e6bca0199e5f49:cf1a4d58a5936a368acec3005c67fbdb'),(208,1639122802,4,'BE',1,0,85,'tx_grevman_domain_model_note',NULL,0,'0400$ca1ff1289c70c4f507e6bca0199e5f49:84e552348134133a136875e50af96f9b'),(209,1639122802,4,'BE',1,0,86,'tx_grevman_domain_model_note',NULL,0,'0400$ca1ff1289c70c4f507e6bca0199e5f49:e2a76592404d8da6786ca69b97ff86a6'),(210,1639122802,4,'BE',1,0,87,'tx_grevman_domain_model_note',NULL,0,'0400$ca1ff1289c70c4f507e6bca0199e5f49:55d90d9ce3b03d45161098f464a63f91'),(211,1639122802,4,'BE',1,0,88,'tx_grevman_domain_model_note',NULL,0,'0400$ca1ff1289c70c4f507e6bca0199e5f49:d88403f78b26b80afcc78c05a26aa2fd'),(212,1639122806,4,'BE',1,0,89,'tx_grevman_domain_model_note',NULL,0,'0400$072a354da0d32a05bb4a4e963a446816:1300d66896bb811cdcab95a10d565c2a'),(213,1639122806,4,'BE',1,0,90,'tx_grevman_domain_model_note',NULL,0,'0400$072a354da0d32a05bb4a4e963a446816:efed917d2e6ef7c4a1931b2ea1c00be8'),(214,1639122806,4,'BE',1,0,91,'tx_grevman_domain_model_note',NULL,0,'0400$072a354da0d32a05bb4a4e963a446816:0bb3cec291b3d35d209e25765365535c'),(215,1639122806,4,'BE',1,0,92,'tx_grevman_domain_model_note',NULL,0,'0400$072a354da0d32a05bb4a4e963a446816:c3e4ae54517b1f30c0c2da05a0489f8b'),(216,1639122806,4,'BE',1,0,93,'tx_grevman_domain_model_note',NULL,0,'0400$072a354da0d32a05bb4a4e963a446816:698eebe5caa8f26d638385e6eb6a1b05'),(217,1639122806,4,'BE',1,0,94,'tx_grevman_domain_model_note',NULL,0,'0400$072a354da0d32a05bb4a4e963a446816:762346ef8f60a7ccf761bcb3fc21c850'),(218,1639122806,4,'BE',1,0,95,'tx_grevman_domain_model_note',NULL,0,'0400$072a354da0d32a05bb4a4e963a446816:e9e635cb287794fa94dd8e8e3ab6269a'),(219,1639122806,4,'BE',1,0,96,'tx_grevman_domain_model_note',NULL,0,'0400$072a354da0d32a05bb4a4e963a446816:45db3949fc6c42a2f0f8f293940c9623'),(220,1639122806,4,'BE',1,0,97,'tx_grevman_domain_model_note',NULL,0,'0400$072a354da0d32a05bb4a4e963a446816:e770860127a79c692b0316e6a651255f'),(221,1639122806,4,'BE',1,0,98,'tx_grevman_domain_model_note',NULL,0,'0400$072a354da0d32a05bb4a4e963a446816:3ed1a8c25dfce29fd5e6aa59f02266a8'),(222,1639122806,4,'BE',1,0,99,'tx_grevman_domain_model_note',NULL,0,'0400$072a354da0d32a05bb4a4e963a446816:e8ad4c08b680fea5ab74b659c73e10cb'),(223,1639122806,4,'BE',1,0,100,'tx_grevman_domain_model_note',NULL,0,'0400$072a354da0d32a05bb4a4e963a446816:9e85c4e1ea01ba7f522c15dab6dd0ec0'),(224,1639122806,4,'BE',1,0,101,'tx_grevman_domain_model_note',NULL,0,'0400$072a354da0d32a05bb4a4e963a446816:ab64f2af914cac75b4fb1b07336d0770'),(225,1639122806,4,'BE',1,0,102,'tx_grevman_domain_model_note',NULL,0,'0400$072a354da0d32a05bb4a4e963a446816:793d668f94d9017d788c702ae5bfbce6'),(226,1639122806,4,'BE',1,0,103,'tx_grevman_domain_model_note',NULL,0,'0400$072a354da0d32a05bb4a4e963a446816:00452b43e490600a7f2d8cccd5596b33'),(227,1639122806,4,'BE',1,0,104,'tx_grevman_domain_model_note',NULL,0,'0400$072a354da0d32a05bb4a4e963a446816:e6f5335e36f5c8f27fa40ac2d52af017'),(228,1639122806,4,'BE',1,0,105,'tx_grevman_domain_model_note',NULL,0,'0400$072a354da0d32a05bb4a4e963a446816:b4ac726f1a757a2b32de300f86045502'),(229,1639122806,4,'BE',1,0,106,'tx_grevman_domain_model_note',NULL,0,'0400$072a354da0d32a05bb4a4e963a446816:a06d23301242e13a0295dd357e8a64a5'),(230,1639122806,4,'BE',1,0,107,'tx_grevman_domain_model_note',NULL,0,'0400$072a354da0d32a05bb4a4e963a446816:7871deac58a7baf9184aa72483173542'),(231,1639122806,4,'BE',1,0,108,'tx_grevman_domain_model_note',NULL,0,'0400$072a354da0d32a05bb4a4e963a446816:2559f5570ecb26fb850af3f26d859352'),(232,1639122806,4,'BE',1,0,109,'tx_grevman_domain_model_note',NULL,0,'0400$072a354da0d32a05bb4a4e963a446816:b01cbbda8f435eae0eda22f5ed581fb3'),(233,1639122806,4,'BE',1,0,110,'tx_grevman_domain_model_note',NULL,0,'0400$072a354da0d32a05bb4a4e963a446816:065a98da460587b6e87f6b7088c1b0eb'),(234,1639122806,4,'BE',1,0,111,'tx_grevman_domain_model_note',NULL,0,'0400$072a354da0d32a05bb4a4e963a446816:9761229d8d3e6b32233c2c5a0ea99f2a'),(235,1639122806,4,'BE',1,0,112,'tx_grevman_domain_model_note',NULL,0,'0400$072a354da0d32a05bb4a4e963a446816:aef3bbb7a88d854cb3a8f31ec9356c6a'),(236,1639122806,4,'BE',1,0,113,'tx_grevman_domain_model_note',NULL,0,'0400$072a354da0d32a05bb4a4e963a446816:d9851b09d229354453dcdaf305f097e9'),(237,1639122810,4,'BE',1,0,114,'tx_grevman_domain_model_note',NULL,0,'0400$144d44a2a7a14e7067ba7ddf431ff16a:81f49e78343ac4d1aa89d53da0fb0f85'),(238,1639122810,4,'BE',1,0,115,'tx_grevman_domain_model_note',NULL,0,'0400$144d44a2a7a14e7067ba7ddf431ff16a:333b0515cb5ae80beb039d1d6fdcdea6'),(239,1639122810,4,'BE',1,0,116,'tx_grevman_domain_model_note',NULL,0,'0400$144d44a2a7a14e7067ba7ddf431ff16a:bd9abbe6816c9aad1dd4546f686f3f73'),(240,1639122810,4,'BE',1,0,117,'tx_grevman_domain_model_note',NULL,0,'0400$144d44a2a7a14e7067ba7ddf431ff16a:f1f03e65bdb900f96b0fbe5f58c69be9'),(241,1639122810,4,'BE',1,0,118,'tx_grevman_domain_model_note',NULL,0,'0400$144d44a2a7a14e7067ba7ddf431ff16a:5dca0aa17c534edd72ccddedb1655490'),(242,1639122810,4,'BE',1,0,119,'tx_grevman_domain_model_note',NULL,0,'0400$144d44a2a7a14e7067ba7ddf431ff16a:997eb183c566baf62f61c7214d77640b'),(243,1639122810,4,'BE',1,0,120,'tx_grevman_domain_model_note',NULL,0,'0400$144d44a2a7a14e7067ba7ddf431ff16a:6061205992172f51c2f19da168db86eb'),(244,1639122810,4,'BE',1,0,121,'tx_grevman_domain_model_note',NULL,0,'0400$144d44a2a7a14e7067ba7ddf431ff16a:265ac4f3b0f8cbc220d940e708331a01'),(245,1639122810,4,'BE',1,0,122,'tx_grevman_domain_model_note',NULL,0,'0400$144d44a2a7a14e7067ba7ddf431ff16a:17d6fa2e2a086e4835fc598e2a46bf8b'),(246,1639122810,4,'BE',1,0,123,'tx_grevman_domain_model_note',NULL,0,'0400$144d44a2a7a14e7067ba7ddf431ff16a:e5c6280ad28301fd3d568d9aed915ef5'),(247,1639122810,4,'BE',1,0,124,'tx_grevman_domain_model_note',NULL,0,'0400$144d44a2a7a14e7067ba7ddf431ff16a:79244756c4921e27d0ebc4cacd849b79'),(248,1639122810,4,'BE',1,0,125,'tx_grevman_domain_model_note',NULL,0,'0400$144d44a2a7a14e7067ba7ddf431ff16a:d1e8b653d9a395cc3c23707dc2a51e41'),(249,1639122810,4,'BE',1,0,126,'tx_grevman_domain_model_note',NULL,0,'0400$144d44a2a7a14e7067ba7ddf431ff16a:49250c968a33fab9847c9458002ba1ff'),(250,1639122810,4,'BE',1,0,127,'tx_grevman_domain_model_note',NULL,0,'0400$144d44a2a7a14e7067ba7ddf431ff16a:4363c7bc78797ed13a8ace714590273b'),(251,1639122810,4,'BE',1,0,128,'tx_grevman_domain_model_note',NULL,0,'0400$144d44a2a7a14e7067ba7ddf431ff16a:612271e5a8c703fbdc936ca96d9e5493'),(252,1639122810,4,'BE',1,0,129,'tx_grevman_domain_model_note',NULL,0,'0400$144d44a2a7a14e7067ba7ddf431ff16a:2311db6e6a59468318d91b7033d4c1fc'),(253,1639122810,4,'BE',1,0,130,'tx_grevman_domain_model_note',NULL,0,'0400$144d44a2a7a14e7067ba7ddf431ff16a:4d222ae939836c8f69ab4a69407d0a76'),(254,1639122810,4,'BE',1,0,131,'tx_grevman_domain_model_note',NULL,0,'0400$144d44a2a7a14e7067ba7ddf431ff16a:a09c03780204692f6d693745ea53a0c0'),(255,1639122810,4,'BE',1,0,132,'tx_grevman_domain_model_note',NULL,0,'0400$144d44a2a7a14e7067ba7ddf431ff16a:5a73b2caf8fb25818c7a2e750f3a098b'),(256,1639122810,4,'BE',1,0,133,'tx_grevman_domain_model_note',NULL,0,'0400$144d44a2a7a14e7067ba7ddf431ff16a:31502c2c6a82de6c598ab7e3b4bf9297'),(257,1639122810,4,'BE',1,0,134,'tx_grevman_domain_model_note',NULL,0,'0400$144d44a2a7a14e7067ba7ddf431ff16a:acab7f1a1106e02709e982f9244ef767'),(258,1639122810,4,'BE',1,0,135,'tx_grevman_domain_model_note',NULL,0,'0400$144d44a2a7a14e7067ba7ddf431ff16a:d73d1fd97588930403e4e5b83c06f105'),(259,1639122810,4,'BE',1,0,86,'tx_grevman_domain_model_registration',NULL,0,'0400$144d44a2a7a14e7067ba7ddf431ff16a:70e14a4f69bbb077a4ba6deb845b78db'),(260,1639122810,4,'BE',1,0,87,'tx_grevman_domain_model_registration',NULL,0,'0400$144d44a2a7a14e7067ba7ddf431ff16a:c9c890101c0f7a027ed0b11b2372de2e'),(261,1639122810,4,'BE',1,0,88,'tx_grevman_domain_model_registration',NULL,0,'0400$144d44a2a7a14e7067ba7ddf431ff16a:7fde984554855a73f56cc0a561852bc3'),(262,1639122816,4,'BE',1,0,89,'tx_grevman_domain_model_registration',NULL,0,'0400$7daebcf50ce59e009887c5943e70ddf2:d099bfeb4c00f4624cc4a7d46ce1a456'),(263,1639122816,4,'BE',1,0,90,'tx_grevman_domain_model_registration',NULL,0,'0400$7daebcf50ce59e009887c5943e70ddf2:c50876bc9b2ad9276e0bd8c7e0f5f007'),(264,1639122816,4,'BE',1,0,91,'tx_grevman_domain_model_registration',NULL,0,'0400$7daebcf50ce59e009887c5943e70ddf2:f25de1c5e9eba0b1f2a6cdb991ea5eaa'),(265,1639122816,4,'BE',1,0,92,'tx_grevman_domain_model_registration',NULL,0,'0400$7daebcf50ce59e009887c5943e70ddf2:f187ad336d9b3e1d903583542c614e31'),(266,1639122816,4,'BE',1,0,93,'tx_grevman_domain_model_registration',NULL,0,'0400$7daebcf50ce59e009887c5943e70ddf2:16b4f9452130cfc3acb6966828a69d82'),(267,1639122816,4,'BE',1,0,94,'tx_grevman_domain_model_registration',NULL,0,'0400$7daebcf50ce59e009887c5943e70ddf2:d832d73af09fceab890da62ef9f730bf'),(268,1639122816,4,'BE',1,0,95,'tx_grevman_domain_model_registration',NULL,0,'0400$7daebcf50ce59e009887c5943e70ddf2:3ba39ae75bcaabfd2c97932e41cbb41c'),(269,1639122816,4,'BE',1,0,96,'tx_grevman_domain_model_registration',NULL,0,'0400$7daebcf50ce59e009887c5943e70ddf2:a7e2d535691a1191ddaf82b4e3784fe0'),(270,1639122816,4,'BE',1,0,97,'tx_grevman_domain_model_registration',NULL,0,'0400$7daebcf50ce59e009887c5943e70ddf2:b0aea09e368ec73fb6131b8faa430fea'),(271,1639122816,4,'BE',1,0,98,'tx_grevman_domain_model_registration',NULL,0,'0400$7daebcf50ce59e009887c5943e70ddf2:0909fc1e347197c76fc95cf67826f472'),(272,1639122816,4,'BE',1,0,99,'tx_grevman_domain_model_registration',NULL,0,'0400$7daebcf50ce59e009887c5943e70ddf2:721bad31a317f15c1c1631357c981df8'),(273,1639122816,4,'BE',1,0,100,'tx_grevman_domain_model_registration',NULL,0,'0400$7daebcf50ce59e009887c5943e70ddf2:a498cf0e5be7a77bf453814bc2199deb'),(274,1639122816,4,'BE',1,0,101,'tx_grevman_domain_model_registration',NULL,0,'0400$7daebcf50ce59e009887c5943e70ddf2:f3326fb6909f56c0f30a2a035a582626'),(275,1639122816,4,'BE',1,0,102,'tx_grevman_domain_model_registration',NULL,0,'0400$7daebcf50ce59e009887c5943e70ddf2:7b5f865c6fb4258a2787097e522ff258'),(276,1639122816,4,'BE',1,0,103,'tx_grevman_domain_model_registration',NULL,0,'0400$7daebcf50ce59e009887c5943e70ddf2:6db4534c5ec1ca197c38d7d1c3bed5ed'),(277,1639122816,4,'BE',1,0,104,'tx_grevman_domain_model_registration',NULL,0,'0400$7daebcf50ce59e009887c5943e70ddf2:9a43b7aa78701abd0eca4ef071f2ef79'),(278,1639122816,4,'BE',1,0,105,'tx_grevman_domain_model_registration',NULL,0,'0400$7daebcf50ce59e009887c5943e70ddf2:7533a677d530630e8e75d56e679dbc1b'),(279,1639122816,4,'BE',1,0,106,'tx_grevman_domain_model_registration',NULL,0,'0400$7daebcf50ce59e009887c5943e70ddf2:9afdecafa0ced03d63d77c73ff60270f'),(280,1639122816,4,'BE',1,0,107,'tx_grevman_domain_model_registration',NULL,0,'0400$7daebcf50ce59e009887c5943e70ddf2:6b10bb72942909b202ecf6d0ba86b641'),(281,1639122816,4,'BE',1,0,108,'tx_grevman_domain_model_registration',NULL,0,'0400$7daebcf50ce59e009887c5943e70ddf2:b25aa00e826ba12303b8a47d1b3e1e32'),(282,1639122816,4,'BE',1,0,109,'tx_grevman_domain_model_registration',NULL,0,'0400$7daebcf50ce59e009887c5943e70ddf2:e8f048312ec759241caa49ad5936eddb'),(283,1639122816,4,'BE',1,0,110,'tx_grevman_domain_model_registration',NULL,0,'0400$7daebcf50ce59e009887c5943e70ddf2:fff1fde80faa11dae6e8b7008fad1fa3'),(284,1639122816,4,'BE',1,0,111,'tx_grevman_domain_model_registration',NULL,0,'0400$7daebcf50ce59e009887c5943e70ddf2:af9ce2d535770f058e8cd8e73ae3d7b9'),(285,1639122816,4,'BE',1,0,112,'tx_grevman_domain_model_registration',NULL,0,'0400$7daebcf50ce59e009887c5943e70ddf2:863dc748c8acb0ac95d5504e0f313495'),(286,1639122816,4,'BE',1,0,113,'tx_grevman_domain_model_registration',NULL,0,'0400$7daebcf50ce59e009887c5943e70ddf2:84005170138fa7bc5fa3cd74f9e44538'),(287,1639122821,4,'BE',1,0,114,'tx_grevman_domain_model_registration',NULL,0,'0400$ff6198bfe3a8c7e048b81c0d67c427cd:cd7996f5dcc9b796b4226191675967b9'),(288,1639122821,4,'BE',1,0,115,'tx_grevman_domain_model_registration',NULL,0,'0400$ff6198bfe3a8c7e048b81c0d67c427cd:ae96fdf560d9b1689e3ded4e1823893d'),(289,1639122821,4,'BE',1,0,116,'tx_grevman_domain_model_registration',NULL,0,'0400$ff6198bfe3a8c7e048b81c0d67c427cd:c683ce7abdedeb39f7c8a3c2b9099257'),(290,1639122821,4,'BE',1,0,117,'tx_grevman_domain_model_registration',NULL,0,'0400$ff6198bfe3a8c7e048b81c0d67c427cd:7fa29eef579b8e9e73ee96f6382cf9d4'),(291,1639122821,4,'BE',1,0,118,'tx_grevman_domain_model_registration',NULL,0,'0400$ff6198bfe3a8c7e048b81c0d67c427cd:d81736e4e72827022ad463578af92563'),(292,1639122821,4,'BE',1,0,119,'tx_grevman_domain_model_registration',NULL,0,'0400$ff6198bfe3a8c7e048b81c0d67c427cd:2d4f4fcb30f62b59cab62fecb4b0980b'),(293,1639122821,4,'BE',1,0,120,'tx_grevman_domain_model_registration',NULL,0,'0400$ff6198bfe3a8c7e048b81c0d67c427cd:344a74a458681f0ec10ec9b271d1033c'),(294,1639122821,4,'BE',1,0,121,'tx_grevman_domain_model_registration',NULL,0,'0400$ff6198bfe3a8c7e048b81c0d67c427cd:e56ee4decd6a282e00554d2f82b1e9e9'),(295,1639122821,4,'BE',1,0,122,'tx_grevman_domain_model_registration',NULL,0,'0400$ff6198bfe3a8c7e048b81c0d67c427cd:c0f3d5ab0f292e0bc9f98b369dfaeb61'),(296,1639122821,4,'BE',1,0,123,'tx_grevman_domain_model_registration',NULL,0,'0400$ff6198bfe3a8c7e048b81c0d67c427cd:8aa922b2059358af5c7cd8c2e4b8bd48'),(297,1639122821,4,'BE',1,0,124,'tx_grevman_domain_model_registration',NULL,0,'0400$ff6198bfe3a8c7e048b81c0d67c427cd:44b6e387ec7235d0da01f97016961020'),(298,1639122821,4,'BE',1,0,125,'tx_grevman_domain_model_registration',NULL,0,'0400$ff6198bfe3a8c7e048b81c0d67c427cd:c33a3a06a6db4b51be235463c41baad3'),(299,1639122821,4,'BE',1,0,126,'tx_grevman_domain_model_registration',NULL,0,'0400$ff6198bfe3a8c7e048b81c0d67c427cd:20ce5fdd412dc99ea17b3471787d37ea'),(300,1639122821,4,'BE',1,0,127,'tx_grevman_domain_model_registration',NULL,0,'0400$ff6198bfe3a8c7e048b81c0d67c427cd:0a2098b50cbc3c365df4c48cd4af5ef8'),(301,1639122821,4,'BE',1,0,128,'tx_grevman_domain_model_registration',NULL,0,'0400$ff6198bfe3a8c7e048b81c0d67c427cd:911be01f8da993d9d068afb084cfefb8'),(302,1639122821,4,'BE',1,0,129,'tx_grevman_domain_model_registration',NULL,0,'0400$ff6198bfe3a8c7e048b81c0d67c427cd:a9a7bc7c25d1d19bc9931f1dcebbeb6c'),(303,1639122821,4,'BE',1,0,130,'tx_grevman_domain_model_registration',NULL,0,'0400$ff6198bfe3a8c7e048b81c0d67c427cd:3c42454f428ddde7a041e76a0c097157'),(304,1639122821,4,'BE',1,0,131,'tx_grevman_domain_model_registration',NULL,0,'0400$ff6198bfe3a8c7e048b81c0d67c427cd:d1c638a4da91ff420c5f6a63562e9c98'),(305,1639122821,4,'BE',1,0,132,'tx_grevman_domain_model_registration',NULL,0,'0400$ff6198bfe3a8c7e048b81c0d67c427cd:3db544ca8da98eb0b39ff73bfc31e26a'),(306,1639122821,4,'BE',1,0,133,'tx_grevman_domain_model_registration',NULL,0,'0400$ff6198bfe3a8c7e048b81c0d67c427cd:863217aa4629185999c6d6d00c681277'),(307,1639122821,4,'BE',1,0,134,'tx_grevman_domain_model_registration',NULL,0,'0400$ff6198bfe3a8c7e048b81c0d67c427cd:50f9df83425d7b79ac76c1690a3a9f98'),(308,1639122821,4,'BE',1,0,135,'tx_grevman_domain_model_registration',NULL,0,'0400$ff6198bfe3a8c7e048b81c0d67c427cd:0a76e418f31281a8704630b844ecc5d8'),(309,1639122821,4,'BE',1,0,136,'tx_grevman_domain_model_registration',NULL,0,'0400$ff6198bfe3a8c7e048b81c0d67c427cd:07124a2e9ea029fb7be1b075e6d711fb'),(310,1639122821,4,'BE',1,0,137,'tx_grevman_domain_model_registration',NULL,0,'0400$ff6198bfe3a8c7e048b81c0d67c427cd:cd26f0c2bce00c7d7fa49ef6a541f70b'),(311,1639122821,4,'BE',1,0,138,'tx_grevman_domain_model_registration',NULL,0,'0400$ff6198bfe3a8c7e048b81c0d67c427cd:08777bcb4a339bd5a4b47d626fd1e512'),(312,1639122824,4,'BE',1,0,139,'tx_grevman_domain_model_registration',NULL,0,'0400$52d5c7784cc951a2bb2471dba7ebf203:2bcf93c8ee3d5a36f3a8595f493a797c'),(313,1639122824,4,'BE',1,0,140,'tx_grevman_domain_model_registration',NULL,0,'0400$52d5c7784cc951a2bb2471dba7ebf203:4eff5ad4902798a3c4428fc5032d1f3b'),(314,1639122824,4,'BE',1,0,141,'tx_grevman_domain_model_registration',NULL,0,'0400$52d5c7784cc951a2bb2471dba7ebf203:2360be85de6332c2f49c4d25fc269ef7'),(315,1639122824,4,'BE',1,0,142,'tx_grevman_domain_model_registration',NULL,0,'0400$52d5c7784cc951a2bb2471dba7ebf203:d2a43d58d3a2d3f3c00330446f786521'),(316,1639122824,4,'BE',1,0,143,'tx_grevman_domain_model_registration',NULL,0,'0400$52d5c7784cc951a2bb2471dba7ebf203:c5f8dbf51ab3c9c8468b5f18f0a14573'),(317,1639122824,4,'BE',1,0,144,'tx_grevman_domain_model_registration',NULL,0,'0400$52d5c7784cc951a2bb2471dba7ebf203:697cbf3374306548ecf409ae50cca9da'),(318,1639122824,4,'BE',1,0,145,'tx_grevman_domain_model_registration',NULL,0,'0400$52d5c7784cc951a2bb2471dba7ebf203:426466905c3649ef5d63893eed4aa801'),(319,1639122824,4,'BE',1,0,146,'tx_grevman_domain_model_registration',NULL,0,'0400$52d5c7784cc951a2bb2471dba7ebf203:62ee3790c516fd74268cf16a2ace0aa3'),(320,1639122824,4,'BE',1,0,147,'tx_grevman_domain_model_registration',NULL,0,'0400$52d5c7784cc951a2bb2471dba7ebf203:96104468df10b2c123d718e626d4453a'),(321,1639122824,4,'BE',1,0,148,'tx_grevman_domain_model_registration',NULL,0,'0400$52d5c7784cc951a2bb2471dba7ebf203:bd328582422542e9e00ca899ff16b5ca'),(322,1639122824,4,'BE',1,0,149,'tx_grevman_domain_model_registration',NULL,0,'0400$52d5c7784cc951a2bb2471dba7ebf203:8a26448c553f86bb676573dd0dcabef5'),(323,1639123058,2,'BE',1,0,1,'tx_grevman_domain_model_event','{\"oldRecord\":{\"price\":50,\"images\":2,\"files\":2,\"registrations\":8,\"notes\":8},\"newRecord\":{\"price\":\"50.00\",\"images\":1,\"files\":1,\"registrations\":64,\"notes\":64}}',0,'0400$3850930d025f150b4399b01a96f82325:e870294c0a9f57aed3f703c79f29898e'),(324,1639123058,2,'BE',1,0,502,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"a:1:{s:6:\\\"hidden\\\";N;}\"},\"newRecord\":{\"l10n_diffsource\":\"a:5:{s:5:\\\"title\\\";N;s:11:\\\"description\\\";N;s:9:\\\"uid_local\\\";N;s:6:\\\"hidden\\\";N;s:16:\\\"sys_language_uid\\\";N;}\"}}',0,'0400$3850930d025f150b4399b01a96f82325:b866e952b6f6672e0d4d29ebdfc606d5'),(325,1639123058,4,'BE',1,0,501,'sys_file_reference',NULL,0,'0400$3850930d025f150b4399b01a96f82325:92ba0ad53e019df3b917251242a7b4f2'),(326,1639123058,4,'BE',1,0,500,'sys_file_reference',NULL,0,'0400$3850930d025f150b4399b01a96f82325:35e6924ebbc07d6e6951fb5b786139d8'),(327,1639123058,4,'BE',1,0,499,'sys_file_reference',NULL,0,'0400$3850930d025f150b4399b01a96f82325:1568daabf2d2af61d70d2be67e16b78a'),(328,1639123058,4,'BE',1,0,498,'sys_file_reference',NULL,0,'0400$3850930d025f150b4399b01a96f82325:f2c70307d28659d2b435ff2013c761db'),(329,1639123058,4,'BE',1,0,490,'sys_file_reference',NULL,0,'0400$3850930d025f150b4399b01a96f82325:9ad7371712e37b81ec035e42140300d0'),(330,1639123058,4,'BE',1,0,497,'sys_file_reference',NULL,0,'0400$3850930d025f150b4399b01a96f82325:9ab695369eac447a7c5dff4440fb0e41'),(331,1639123058,4,'BE',1,0,489,'sys_file_reference',NULL,0,'0400$3850930d025f150b4399b01a96f82325:52fd3a8d060fb21cb2a5cdcc5f3c3b46'),(332,1639123058,4,'BE',1,0,488,'sys_file_reference',NULL,0,'0400$3850930d025f150b4399b01a96f82325:57f327b5f7f9e0293ae8d897d93b3104'),(333,1639123058,4,'BE',1,0,481,'sys_file_reference',NULL,0,'0400$3850930d025f150b4399b01a96f82325:0b9672520ae4057c95f9d1c1c03b8007'),(334,1639123058,4,'BE',1,0,496,'sys_file_reference',NULL,0,'0400$3850930d025f150b4399b01a96f82325:a4c7266b818145f3fe891f44ed772517'),(335,1639123058,4,'BE',1,0,484,'sys_file_reference',NULL,0,'0400$3850930d025f150b4399b01a96f82325:48cee5f85c13648264ca2dbda7d5bc25'),(336,1639123058,4,'BE',1,0,483,'sys_file_reference',NULL,0,'0400$3850930d025f150b4399b01a96f82325:3c9145ea1888f3df66dd678e23b1637b'),(337,1639123058,4,'BE',1,0,487,'sys_file_reference',NULL,0,'0400$3850930d025f150b4399b01a96f82325:7d42d5e289928913e4ee61c9c134c977'),(338,1639123058,4,'BE',1,0,495,'sys_file_reference',NULL,0,'0400$3850930d025f150b4399b01a96f82325:b1cf99ea72cc1bf7e07560c0ef88c06c'),(339,1639123058,4,'BE',1,0,474,'sys_file_reference',NULL,0,'0400$3850930d025f150b4399b01a96f82325:03abcd8527a89e6785bff4b87ad730b3'),(340,1639123058,4,'BE',1,0,510,'sys_file_reference',NULL,0,'0400$3850930d025f150b4399b01a96f82325:4f87b5d9d17d4c129a07f884a51e2b64'),(341,1639123058,4,'BE',1,0,509,'sys_file_reference',NULL,0,'0400$3850930d025f150b4399b01a96f82325:bc23b03f2edd982e74dfbaeb97f7efbe'),(342,1639123058,4,'BE',1,0,508,'sys_file_reference',NULL,0,'0400$3850930d025f150b4399b01a96f82325:46c2498e9e629cf83a2ff105a23fc1fc'),(343,1639123058,4,'BE',1,0,507,'sys_file_reference',NULL,0,'0400$3850930d025f150b4399b01a96f82325:3a50680566ac4c4916942167e5ce24aa'),(344,1639123058,4,'BE',1,0,506,'sys_file_reference',NULL,0,'0400$3850930d025f150b4399b01a96f82325:37e403b9ae78f13889313b0cdfe97ddc'),(345,1639123058,4,'BE',1,0,494,'sys_file_reference',NULL,0,'0400$3850930d025f150b4399b01a96f82325:e976d780f6b6507031782f229fc9d9f8'),(346,1639123058,4,'BE',1,0,505,'sys_file_reference',NULL,0,'0400$3850930d025f150b4399b01a96f82325:397096fca47223b0853338a88ce6ee46'),(347,1639123058,4,'BE',1,0,493,'sys_file_reference',NULL,0,'0400$3850930d025f150b4399b01a96f82325:163bc45126fddd624074275009088c57'),(348,1639123058,4,'BE',1,0,492,'sys_file_reference',NULL,0,'0400$3850930d025f150b4399b01a96f82325:ea2827cce3259378a59c6c3500838b12'),(349,1639123058,4,'BE',1,0,482,'sys_file_reference',NULL,0,'0400$3850930d025f150b4399b01a96f82325:20c5e4e09d13dd0dc10e6a7eb49f9f69'),(350,1639123058,4,'BE',1,0,504,'sys_file_reference',NULL,0,'0400$3850930d025f150b4399b01a96f82325:d9a89fd9203dab0365fec651735145dd'),(351,1639123058,4,'BE',1,0,486,'sys_file_reference',NULL,0,'0400$3850930d025f150b4399b01a96f82325:05a5faf5b1552b7389879a0b61bd7f10'),(352,1639123058,4,'BE',1,0,485,'sys_file_reference',NULL,0,'0400$3850930d025f150b4399b01a96f82325:4056753849e69f15f37c7fee44b44f47'),(353,1639123058,4,'BE',1,0,491,'sys_file_reference',NULL,0,'0400$3850930d025f150b4399b01a96f82325:156abdf02b8e654805c311c544cd0820'),(354,1639123058,4,'BE',1,0,503,'sys_file_reference',NULL,0,'0400$3850930d025f150b4399b01a96f82325:45d87fdc8930dc2539378911f2c69176'),(355,1639123278,1,'BE',1,0,543,'sys_file_reference','{\"uid\":543,\"pid\":224,\"tstamp\":1639123278,\"crdate\":1639123278,\"cruser_id\":1,\"deleted\":0,\"hidden\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"a:5:{s:5:\\\"title\\\";N;s:11:\\\"description\\\";N;s:9:\\\"uid_local\\\";N;s:6:\\\"hidden\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"t3ver_count\":0,\"t3ver_tstamp\":0,\"t3ver_move_id\":0,\"uid_local\":162,\"uid_foreign\":1,\"tablenames\":\"tx_grevman_domain_model_event\",\"fieldname\":\"images\",\"sorting_foreign\":1,\"table_local\":\"sys_file\",\"title\":null,\"description\":null,\"alternative\":null,\"link\":\"\",\"crop\":\"\",\"autoplay\":0}',0,'0400$b95cdd44b992e10f2d1cefc1a2319641:3efd725176401ce927673fb008de6720'),(356,1639123278,1,'BE',1,0,544,'sys_file_reference','{\"uid\":544,\"pid\":224,\"tstamp\":1639123278,\"crdate\":1639123278,\"cruser_id\":1,\"deleted\":0,\"hidden\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"a:5:{s:5:\\\"title\\\";N;s:11:\\\"description\\\";N;s:9:\\\"uid_local\\\";N;s:6:\\\"hidden\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"t3ver_count\":0,\"t3ver_tstamp\":0,\"t3ver_move_id\":0,\"uid_local\":163,\"uid_foreign\":1,\"tablenames\":\"tx_grevman_domain_model_event\",\"fieldname\":\"files\",\"sorting_foreign\":1,\"table_local\":\"sys_file\",\"title\":null,\"description\":null,\"alternative\":null,\"link\":\"\",\"crop\":\"\",\"autoplay\":0}',0,'0400$b95cdd44b992e10f2d1cefc1a2319641:d816ccc70d91c42404379842a6d93335'),(357,1639123306,2,'BE',1,0,1,'tx_grevman_domain_model_event','{\"oldRecord\":{\"price\":50,\"registrations\":64,\"notes\":64},\"newRecord\":{\"price\":\"50.00\",\"registrations\":0,\"notes\":0}}',0,'0400$b196c8788ee02541c8d3183a21754e22:e870294c0a9f57aed3f703c79f29898e'),(358,1639123306,4,'BE',1,0,543,'sys_file_reference',NULL,0,'0400$b196c8788ee02541c8d3183a21754e22:3efd725176401ce927673fb008de6720'),(359,1639123306,4,'BE',1,0,544,'sys_file_reference',NULL,0,'0400$b196c8788ee02541c8d3183a21754e22:d816ccc70d91c42404379842a6d93335'),(360,1639123320,1,'BE',1,0,545,'sys_file_reference','{\"uid\":545,\"pid\":224,\"tstamp\":1639123320,\"crdate\":1639123320,\"cruser_id\":1,\"deleted\":0,\"hidden\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"a:5:{s:5:\\\"title\\\";N;s:11:\\\"description\\\";N;s:9:\\\"uid_local\\\";N;s:6:\\\"hidden\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"t3ver_count\":0,\"t3ver_tstamp\":0,\"t3ver_move_id\":0,\"uid_local\":162,\"uid_foreign\":1,\"tablenames\":\"tx_grevman_domain_model_event\",\"fieldname\":\"images\",\"sorting_foreign\":1,\"table_local\":\"sys_file\",\"title\":null,\"description\":null,\"alternative\":null,\"link\":\"\",\"crop\":\"\",\"autoplay\":0}',0,'0400$b17d323da2fb6449966a117b0139174b:bdfed87ce09a63a4abb230039b590b49'),(361,1639123320,1,'BE',1,0,546,'sys_file_reference','{\"uid\":546,\"pid\":224,\"tstamp\":1639123320,\"crdate\":1639123320,\"cruser_id\":1,\"deleted\":0,\"hidden\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"a:5:{s:5:\\\"title\\\";N;s:11:\\\"description\\\";N;s:9:\\\"uid_local\\\";N;s:6:\\\"hidden\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"t3ver_count\":0,\"t3ver_tstamp\":0,\"t3ver_move_id\":0,\"uid_local\":163,\"uid_foreign\":1,\"tablenames\":\"tx_grevman_domain_model_event\",\"fieldname\":\"files\",\"sorting_foreign\":1,\"table_local\":\"sys_file\",\"title\":null,\"description\":null,\"alternative\":null,\"link\":\"\",\"crop\":\"\",\"autoplay\":0}',0,'0400$b17d323da2fb6449966a117b0139174b:c926e8eeea76d5aa1c6f1888fdc9e131'),(362,1639123346,2,'BE',1,0,1,'tx_grevman_domain_model_event','{\"oldRecord\":{\"price\":50},\"newRecord\":{\"price\":\"50.00\"}}',0,'0400$2663b08a93593f838de037bb9e126b31:e870294c0a9f57aed3f703c79f29898e'),(363,1639123346,2,'BE',1,0,546,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"a:5:{s:5:\\\"title\\\";N;s:11:\\\"description\\\";N;s:9:\\\"uid_local\\\";N;s:6:\\\"hidden\\\";N;s:16:\\\"sys_language_uid\\\";N;}\"},\"newRecord\":{\"l10n_diffsource\":\"a:1:{s:6:\\\"hidden\\\";N;}\"}}',0,'0400$2663b08a93593f838de037bb9e126b31:c926e8eeea76d5aa1c6f1888fdc9e131'),(364,1639123346,4,'BE',1,0,545,'sys_file_reference',NULL,0,'0400$2663b08a93593f838de037bb9e126b31:bdfed87ce09a63a4abb230039b590b49'),(365,1639123346,4,'BE',1,0,478,'sys_file_reference',NULL,0,'0400$2663b08a93593f838de037bb9e126b31:661684bb51261ac8472aca2c3198bed9'),(366,1639123354,4,'BE',1,0,474,'sys_file_reference',NULL,0,'0400$b7eeefeb239394bb8067445062be9035:03abcd8527a89e6785bff4b87ad730b3'),(367,1639123354,4,'BE',1,0,478,'sys_file_reference',NULL,0,'0400$b7eeefeb239394bb8067445062be9035:661684bb51261ac8472aca2c3198bed9'),(368,1639123354,4,'BE',1,0,481,'sys_file_reference',NULL,0,'0400$b7eeefeb239394bb8067445062be9035:0b9672520ae4057c95f9d1c1c03b8007'),(369,1639123354,4,'BE',1,0,482,'sys_file_reference',NULL,0,'0400$b7eeefeb239394bb8067445062be9035:20c5e4e09d13dd0dc10e6a7eb49f9f69'),(370,1639123354,4,'BE',1,0,483,'sys_file_reference',NULL,0,'0400$b7eeefeb239394bb8067445062be9035:3c9145ea1888f3df66dd678e23b1637b'),(371,1639123354,4,'BE',1,0,484,'sys_file_reference',NULL,0,'0400$b7eeefeb239394bb8067445062be9035:48cee5f85c13648264ca2dbda7d5bc25'),(372,1639123354,4,'BE',1,0,485,'sys_file_reference',NULL,0,'0400$b7eeefeb239394bb8067445062be9035:4056753849e69f15f37c7fee44b44f47'),(373,1639123354,4,'BE',1,0,486,'sys_file_reference',NULL,0,'0400$b7eeefeb239394bb8067445062be9035:05a5faf5b1552b7389879a0b61bd7f10'),(374,1639123354,4,'BE',1,0,487,'sys_file_reference',NULL,0,'0400$b7eeefeb239394bb8067445062be9035:7d42d5e289928913e4ee61c9c134c977'),(375,1639123354,4,'BE',1,0,488,'sys_file_reference',NULL,0,'0400$b7eeefeb239394bb8067445062be9035:57f327b5f7f9e0293ae8d897d93b3104'),(376,1639123354,4,'BE',1,0,489,'sys_file_reference',NULL,0,'0400$b7eeefeb239394bb8067445062be9035:52fd3a8d060fb21cb2a5cdcc5f3c3b46'),(377,1639123354,4,'BE',1,0,490,'sys_file_reference',NULL,0,'0400$b7eeefeb239394bb8067445062be9035:9ad7371712e37b81ec035e42140300d0'),(378,1639123354,4,'BE',1,0,491,'sys_file_reference',NULL,0,'0400$b7eeefeb239394bb8067445062be9035:156abdf02b8e654805c311c544cd0820'),(379,1639123354,4,'BE',1,0,492,'sys_file_reference',NULL,0,'0400$b7eeefeb239394bb8067445062be9035:ea2827cce3259378a59c6c3500838b12'),(380,1639123354,4,'BE',1,0,493,'sys_file_reference',NULL,0,'0400$b7eeefeb239394bb8067445062be9035:163bc45126fddd624074275009088c57'),(381,1639123354,4,'BE',1,0,494,'sys_file_reference',NULL,0,'0400$b7eeefeb239394bb8067445062be9035:e976d780f6b6507031782f229fc9d9f8'),(382,1639123354,4,'BE',1,0,495,'sys_file_reference',NULL,0,'0400$b7eeefeb239394bb8067445062be9035:b1cf99ea72cc1bf7e07560c0ef88c06c'),(383,1639123354,4,'BE',1,0,496,'sys_file_reference',NULL,0,'0400$b7eeefeb239394bb8067445062be9035:a4c7266b818145f3fe891f44ed772517'),(384,1639123354,4,'BE',1,0,497,'sys_file_reference',NULL,0,'0400$b7eeefeb239394bb8067445062be9035:9ab695369eac447a7c5dff4440fb0e41'),(385,1639123354,4,'BE',1,0,498,'sys_file_reference',NULL,0,'0400$b7eeefeb239394bb8067445062be9035:f2c70307d28659d2b435ff2013c761db'),(386,1639123354,4,'BE',1,0,499,'sys_file_reference',NULL,0,'0400$b7eeefeb239394bb8067445062be9035:1568daabf2d2af61d70d2be67e16b78a'),(387,1639123354,4,'BE',1,0,500,'sys_file_reference',NULL,0,'0400$b7eeefeb239394bb8067445062be9035:35e6924ebbc07d6e6951fb5b786139d8'),(388,1639123354,4,'BE',1,0,501,'sys_file_reference',NULL,0,'0400$b7eeefeb239394bb8067445062be9035:92ba0ad53e019df3b917251242a7b4f2'),(389,1639123354,4,'BE',1,0,503,'sys_file_reference',NULL,0,'0400$b7eeefeb239394bb8067445062be9035:45d87fdc8930dc2539378911f2c69176'),(390,1639123354,4,'BE',1,0,504,'sys_file_reference',NULL,0,'0400$b7eeefeb239394bb8067445062be9035:d9a89fd9203dab0365fec651735145dd'),(391,1639123358,4,'BE',1,0,505,'sys_file_reference',NULL,0,'0400$779002db639875876c2123df3dcba0cb:397096fca47223b0853338a88ce6ee46'),(392,1639123358,4,'BE',1,0,506,'sys_file_reference',NULL,0,'0400$779002db639875876c2123df3dcba0cb:37e403b9ae78f13889313b0cdfe97ddc'),(393,1639123358,4,'BE',1,0,507,'sys_file_reference',NULL,0,'0400$779002db639875876c2123df3dcba0cb:3a50680566ac4c4916942167e5ce24aa'),(394,1639123358,4,'BE',1,0,508,'sys_file_reference',NULL,0,'0400$779002db639875876c2123df3dcba0cb:46c2498e9e629cf83a2ff105a23fc1fc'),(395,1639123358,4,'BE',1,0,509,'sys_file_reference',NULL,0,'0400$779002db639875876c2123df3dcba0cb:bc23b03f2edd982e74dfbaeb97f7efbe'),(396,1639123358,4,'BE',1,0,510,'sys_file_reference',NULL,0,'0400$779002db639875876c2123df3dcba0cb:4f87b5d9d17d4c129a07f884a51e2b64'),(397,1639123358,4,'BE',1,0,543,'sys_file_reference',NULL,0,'0400$779002db639875876c2123df3dcba0cb:3efd725176401ce927673fb008de6720'),(398,1639123358,4,'BE',1,0,544,'sys_file_reference',NULL,0,'0400$779002db639875876c2123df3dcba0cb:d816ccc70d91c42404379842a6d93335'),(399,1639123358,4,'BE',1,0,545,'sys_file_reference',NULL,0,'0400$779002db639875876c2123df3dcba0cb:bdfed87ce09a63a4abb230039b590b49'),(400,1639123416,2,'BE',1,0,1,'tx_grevman_domain_model_event','{\"oldRecord\":{\"startdate\":1639498080,\"price\":50},\"newRecord\":{\"startdate\":1638979680,\"price\":\"50.00\"}}',0,'0400$5c6ce2b8a1374e76f3b55adb93d94cc5:e870294c0a9f57aed3f703c79f29898e'),(401,1639123635,2,'BE',1,0,27,'sys_template','{\"oldRecord\":{\"constants\":\"plugin.tx_grevman_events.settings.event.list.displayDays = 6\\r\\nplugin.tx_grevman_events.settings.general.timeZone = Europe\\/Zurich\"},\"newRecord\":{\"constants\":\"plugin.tx_grevman_events.settings.event.list.startDatePastDays = 6\\r\\nplugin.tx_grevman_events.settings.event.list.displayDays = 6\\r\\nplugin.tx_grevman_events.settings.general.timeZone = Europe\\/Zurich\"}}',0,'0400$5af34833660e67a69ad9b7d2d4fbd4fa:e52734fec54f252c6513ef9ec40e979f'),(402,1639124295,2,'BE',1,0,27,'sys_template','{\"oldRecord\":{\"constants\":\"plugin.tx_grevman_events.settings.event.list.startDatePastDays = 6\\r\\nplugin.tx_grevman_events.settings.event.list.displayDays = 6\\r\\nplugin.tx_grevman_events.settings.general.timeZone = Europe\\/Zurich\"},\"newRecord\":{\"constants\":\"plugin.tx_grevman_events.settings.event.list.displayDays = 360\\r\\nplugin.tx_grevman_events.settings.general.timeZone = Europe\\/Zurich\"}}',0,'0400$9a454386a6b1d799942eec9eb79dd1a1:e52734fec54f252c6513ef9ec40e979f'),(403,1639124362,2,'BE',1,0,1,'tx_grevman_domain_model_event','{\"oldRecord\":{\"price\":50},\"newRecord\":{\"price\":\"50.00\"}}',0,'0400$856628151fdfa8ddd87fa57079d8ff6c:e870294c0a9f57aed3f703c79f29898e'),(404,1639124367,2,'BE',1,0,1,'tx_grevman_domain_model_event','{\"oldRecord\":{\"price\":50},\"newRecord\":{\"price\":\"50.00\"}}',0,'0400$c9f1f7ff6814c7436130c7f9dac84b3a:e870294c0a9f57aed3f703c79f29898e'),(405,1639126013,1,'BE',1,0,43,'tx_grevman_domain_model_event','{\"uid\":43,\"pid\":224,\"tstamp\":1639126013,\"crdate\":1639126013,\"cruser_id\":1,\"deleted\":0,\"hidden\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"a:3:{s:5:\\\"title\\\";N;s:9:\\\"startdate\\\";N;s:7:\\\"enddate\\\";N;}\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"t3ver_count\":0,\"t3ver_tstamp\":0,\"t3ver_move_id\":0,\"title\":\"Event 2\",\"member_groups\":1,\"registrations\":0,\"notes\":0,\"guests\":0,\"slug\":\"event2\",\"startdate\":1639990800,\"enddate\":1640084400,\"teaser\":\"<p>This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser.<\\/p>\",\"description\":\"<p>This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description.<\\/p>\\r\\n<p>This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description.<\\/p>\",\"price\":0,\"link\":\"t3:\\/\\/page?uid=1\",\"program\":\"<p>This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program.<\\/p>\",\"location\":\"Suneb\\u00fchel\",\"images\":0,\"files\":0,\"parent\":0,\"enable_recurrence\":0,\"recurrence_enddate\":0,\"recurrence_rule\":\"\",\"recurrence_dates\":\"\",\"recurrence_exception_dates\":\"\",\"recurrence_set\":\"\"}',0,'0400$bf7da21d6c05da2c97473a18d1ea64b2:909cbfac386ada873e86623938753f3a'),(406,1639126059,4,'BE',1,0,43,'tx_grevman_domain_model_event',NULL,0,'0400$198b8125acf3e8c4bb4886a79b895a90:909cbfac386ada873e86623938753f3a'),(407,1639126476,2,'BE',1,0,1,'tx_grevman_domain_model_event','{\"oldRecord\":{\"price\":50},\"newRecord\":{\"price\":\"50.00\"}}',0,'0400$833404f4c8068c98592adc08757b117e:e870294c0a9f57aed3f703c79f29898e'),(408,1639126630,2,'BE',1,0,1,'tx_grevman_domain_model_event','{\"oldRecord\":{\"price\":50},\"newRecord\":{\"price\":\"50.00\"}}',0,'0400$a1efdbec7bb3e362c8cac1df5d7fe3eb:e870294c0a9f57aed3f703c79f29898e'),(409,1639126763,2,'BE',1,0,1,'tx_grevman_domain_model_event','{\"oldRecord\":{\"price\":50},\"newRecord\":{\"price\":\"50.00\"}}',0,'0400$40e71eb2734be27a638607245fbb84c4:e870294c0a9f57aed3f703c79f29898e'),(410,1639126817,1,'BE',1,0,44,'tx_grevman_domain_model_event','{\"uid\":44,\"pid\":224,\"tstamp\":1639126817,\"crdate\":1639126817,\"cruser_id\":1,\"deleted\":0,\"hidden\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"a:3:{s:5:\\\"title\\\";N;s:9:\\\"startdate\\\";N;s:7:\\\"enddate\\\";N;}\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"t3ver_count\":0,\"t3ver_tstamp\":0,\"t3ver_move_id\":0,\"title\":\"Event 2\",\"member_groups\":1,\"registrations\":0,\"notes\":0,\"guests\":0,\"slug\":\"event2\",\"startdate\":1639990800,\"enddate\":1640084400,\"teaser\":\"<p>This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser.<\\/p>\",\"description\":\"<p>This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description.<\\/p>\\r\\n<p>This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description.<\\/p>\",\"price\":0,\"link\":\"t3:\\/\\/page?uid=1\",\"program\":\"<p>This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program.<\\/p>\",\"location\":\"Suneb\\u00fchel\",\"images\":0,\"files\":0,\"parent\":0,\"enable_recurrence\":0,\"recurrence_enddate\":0,\"recurrence_rule\":\"\",\"recurrence_dates\":\"\",\"recurrence_exception_dates\":\"\",\"recurrence_set\":\"\"}',0,'0400$5ae33b8aac415594f558d56675cb2136:0743504b450579a23351669276063c1c'),(411,1639126835,4,'BE',1,0,44,'tx_grevman_domain_model_event',NULL,0,'0400$2fee6b4e60a7a4a3a7cb33a47e48a45c:0743504b450579a23351669276063c1c'),(412,1639127038,1,'BE',1,0,547,'sys_file_reference','{\"uid\":547,\"pid\":224,\"tstamp\":1639127038,\"crdate\":1639127038,\"cruser_id\":1,\"deleted\":0,\"hidden\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"a:5:{s:5:\\\"title\\\";N;s:11:\\\"description\\\";N;s:9:\\\"uid_local\\\";N;s:6:\\\"hidden\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"t3ver_count\":0,\"t3ver_tstamp\":0,\"t3ver_move_id\":0,\"uid_local\":162,\"uid_foreign\":1,\"tablenames\":\"tx_grevman_domain_model_event\",\"fieldname\":\"images\",\"sorting_foreign\":1,\"table_local\":\"sys_file\",\"title\":null,\"description\":null,\"alternative\":null,\"link\":\"\",\"crop\":\"\",\"autoplay\":0}',0,'0400$01188d492f7272b35083385aa7480a1d:72d4419df8b7bf7ce772fdab800e0eb4'),(413,1639127038,1,'BE',1,0,548,'sys_file_reference','{\"uid\":548,\"pid\":224,\"tstamp\":1639127038,\"crdate\":1639127038,\"cruser_id\":1,\"deleted\":0,\"hidden\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"a:1:{s:6:\\\"hidden\\\";N;}\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"t3ver_count\":0,\"t3ver_tstamp\":0,\"t3ver_move_id\":0,\"uid_local\":163,\"uid_foreign\":1,\"tablenames\":\"tx_grevman_domain_model_event\",\"fieldname\":\"files\",\"sorting_foreign\":1,\"table_local\":\"sys_file\",\"title\":null,\"description\":null,\"alternative\":null,\"link\":\"\",\"crop\":\"\",\"autoplay\":0}',0,'0400$01188d492f7272b35083385aa7480a1d:fb477eb589a76863e4fcda0bec919473'),(414,1639127038,1,'BE',1,0,45,'tx_grevman_domain_model_event','{\"uid\":45,\"pid\":224,\"tstamp\":1639127038,\"crdate\":1639127038,\"cruser_id\":1,\"deleted\":0,\"hidden\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"a:24:{s:5:\\\"title\\\";N;s:4:\\\"slug\\\";N;s:9:\\\"startdate\\\";N;s:7:\\\"enddate\\\";N;s:6:\\\"teaser\\\";N;s:11:\\\"description\\\";N;s:7:\\\"program\\\";N;s:4:\\\"link\\\";N;s:8:\\\"location\\\";N;s:5:\\\"price\\\";N;s:6:\\\"images\\\";N;s:5:\\\"files\\\";N;s:13:\\\"member_groups\\\";N;s:13:\\\"registrations\\\";N;s:5:\\\"notes\\\";N;s:6:\\\"guests\\\";N;s:17:\\\"enable_recurrence\\\";N;s:18:\\\"recurrence_enddate\\\";N;s:15:\\\"recurrence_rule\\\";N;s:16:\\\"recurrence_dates\\\";N;s:26:\\\"recurrence_exception_dates\\\";N;s:14:\\\"recurrence_set\\\";N;s:16:\\\"sys_language_uid\\\";N;s:6:\\\"hidden\\\";N;}\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"t3ver_count\":0,\"t3ver_tstamp\":0,\"t3ver_move_id\":0,\"title\":\"Event 1\",\"member_groups\":1,\"registrations\":0,\"notes\":0,\"guests\":1,\"slug\":\"event1\",\"startdate\":1638979680,\"enddate\":0,\"teaser\":\"<p>This event defines a recurrence to obtain eventst in the summer and in the winter hence thwy are exposed to daylight saving time changes. This event defines a recurrence to obtain eventst in the summer and in the winter hence thwy are exposed to daylight saving time changes.<\\/p>\",\"description\":\"<p>Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here.<\\/p>\\r\\n<p>Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here.<\\/p>\",\"price\":50,\"link\":\"https:\\/\\/www.diemtigtal.ch\\/\",\"program\":\"<p>Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here<\\/p>\",\"location\":\"Altes Schulhaus, Sportwil\",\"images\":0,\"files\":0,\"parent\":0,\"enable_recurrence\":1,\"recurrence_enddate\":0,\"recurrence_rule\":\"FREQ=MONTHLY;INTERVAL=3\",\"recurrence_dates\":\"01.07.22\",\"recurrence_exception_dates\":\"06.07.22\",\"recurrence_set\":\"\"}',0,'0400$64fe119930f98984621c2faa296866b6:6bcd8cecb34cc6ae17929bf010fd560f'),(415,1639127064,2,'BE',1,0,45,'tx_grevman_domain_model_event','{\"oldRecord\":{\"title\":\"Event 1\",\"price\":50},\"newRecord\":{\"title\":\"Event 1 copy\",\"price\":\"50.00\"}}',0,'0400$00d52c199a191b1aecd17f75909eb1ac:6bcd8cecb34cc6ae17929bf010fd560f'),(416,1639127064,2,'BE',1,0,547,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"a:5:{s:5:\\\"title\\\";N;s:11:\\\"description\\\";N;s:9:\\\"uid_local\\\";N;s:6:\\\"hidden\\\";N;s:16:\\\"sys_language_uid\\\";N;}\"},\"newRecord\":{\"l10n_diffsource\":\"a:1:{s:6:\\\"hidden\\\";N;}\"}}',0,'0400$00d52c199a191b1aecd17f75909eb1ac:72d4419df8b7bf7ce772fdab800e0eb4'),(417,1639127090,2,'BE',1,0,45,'tx_grevman_domain_model_event','{\"oldRecord\":{\"startdate\":1638979680,\"price\":50},\"newRecord\":{\"startdate\":1639411680,\"price\":\"50.00\"}}',0,'0400$df3e0ff8e3ed85d0cc52c08d2ed90255:6bcd8cecb34cc6ae17929bf010fd560f'),(418,1639127281,4,'BE',1,0,150,'tx_grevman_domain_model_registration',NULL,0,'0400$d21eebe07965c473aedefa9ee8513e30:b221ab9654436925e1f589011f009477'),(419,1639127281,4,'BE',1,0,547,'sys_file_reference',NULL,0,'0400$d21eebe07965c473aedefa9ee8513e30:72d4419df8b7bf7ce772fdab800e0eb4'),(420,1639127281,4,'BE',1,0,548,'sys_file_reference',NULL,0,'0400$d21eebe07965c473aedefa9ee8513e30:fb477eb589a76863e4fcda0bec919473'),(421,1639127281,4,'BE',1,0,45,'tx_grevman_domain_model_event',NULL,0,'0400$d21eebe07965c473aedefa9ee8513e30:6bcd8cecb34cc6ae17929bf010fd560f'),(422,1639127335,2,'BE',1,0,2,'tx_grevman_domain_model_event','{\"oldRecord\":{\"hidden\":0,\"l10n_diffsource\":\"a:3:{s:5:\\\"title\\\";N;s:9:\\\"startdate\\\";N;s:7:\\\"enddate\\\";N;}\"},\"newRecord\":{\"hidden\":\"1\",\"l10n_diffsource\":\"a:1:{s:6:\\\"hidden\\\";N;}\"}}',0,'0400$889f3486cc4a37c5aa8c0b1683513f2f:7fb680fe12d0e298327b0b962ad1bc20'),(423,1639141074,1,'BE',1,0,234,'pages','{\"uid\":234,\"pid\":223,\"tstamp\":1639141074,\"crdate\":1639141074,\"cruser_id\":1,\"deleted\":0,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"fe_group\":\"0\",\"sorting\":32,\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"t3ver_count\":0,\"t3ver_tstamp\":0,\"t3ver_move_id\":0,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"title\":\"Messenger\",\"slug\":\"\\/grevman\\/messenger\",\"doktype\":1,\"TSconfig\":null,\"is_siteroot\":0,\"php_tree_stop\":0,\"url\":\"\",\"shortcut\":0,\"shortcut_mode\":0,\"subtitle\":\"\",\"layout\":0,\"target\":\"\",\"media\":0,\"lastUpdated\":0,\"keywords\":null,\"cache_timeout\":0,\"cache_tags\":\"\",\"newUntil\":0,\"description\":null,\"no_search\":0,\"SYS_LASTCHANGED\":0,\"abstract\":null,\"module\":\"\",\"extendToSubpages\":0,\"author\":\"\",\"author_email\":\"\",\"nav_title\":\"\",\"nav_hide\":0,\"content_from_pid\":0,\"mount_pid\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"fe_login_mode\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":null,\"legacy_overlay_uid\":0,\"tx_impexp_origuid\":0,\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"og_title\":\"\",\"og_description\":null,\"og_image\":0,\"twitter_title\":\"\",\"twitter_description\":null,\"twitter_image\":0,\"canonical_link\":\"\",\"categories\":0,\"nav_icon\":0,\"thumbnail\":0,\"twitter_card\":\"summary\",\"sitemap_priority\":\"0.5\",\"sitemap_changefreq\":\"\",\"nav_icon_set\":\"\",\"nav_icon_identifier\":\"\"}',0,'0400$d06f0426a42536882d541b34e7f0369e:e72c60104ad6861ae6ab5f66507582e7'),(424,1639141078,2,'BE',1,0,234,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"a:1:{s:6:\\\"hidden\\\";N;}\"}}',0,'0400$803c8cb2d5ca7875fb9c3ec37dc32ad6:e72c60104ad6861ae6ab5f66507582e7'),(425,1639141248,1,'BE',1,0,1034,'tt_content','{\"uid\":1034,\"rowDescription\":\"\",\"pid\":234,\"tstamp\":1639141248,\"crdate\":1639141248,\"cruser_id\":1,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":256,\"editlock\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l18n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"t3ver_count\":0,\"t3ver_tstamp\":0,\"t3ver_move_id\":0,\"CType\":\"list\",\"header\":\"\",\"header_position\":\"\",\"bodytext\":null,\"bullets_type\":0,\"uploads_description\":0,\"uploads_type\":0,\"assets\":0,\"image\":0,\"imagewidth\":0,\"imageorient\":0,\"imagecols\":1,\"imageborder\":0,\"media\":0,\"layout\":\"0\",\"frame_class\":\"default\",\"cols\":0,\"space_before_class\":\"\",\"space_after_class\":\"\",\"records\":null,\"pages\":\"\",\"colPos\":0,\"subheader\":\"\",\"header_link\":\"\",\"image_zoom\":0,\"header_layout\":\"0\",\"list_type\":\"grevman_messenger\",\"sectionIndex\":1,\"linkToTop\":0,\"file_collections\":null,\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"date\":0,\"recursive\":0,\"imageheight\":0,\"pi_flexform\":null,\"accessibility_title\":\"\",\"accessibility_bypass\":0,\"accessibility_bypass_text\":\"\",\"selected_categories\":null,\"category_field\":\"\",\"table_class\":\"\",\"table_caption\":null,\"table_delimiter\":124,\"table_enclosure\":0,\"table_header_position\":0,\"table_tfoot\":0,\"tx_impexp_origuid\":0,\"categories\":0,\"teaser\":null,\"readmore_label\":\"\",\"quote_source\":\"\",\"quote_link\":\"\",\"panel_class\":\"default\",\"file_folder\":null,\"icon\":\"\",\"icon_set\":\"\",\"icon_file\":0,\"icon_position\":\"\",\"icon_size\":\"default\",\"icon_type\":\"default\",\"icon_color\":\"#FFFFFF\",\"icon_background\":\"#333333\",\"external_media_source\":\"\",\"external_media_ratio\":\"\",\"tx_bootstrappackage_card_group_item\":0,\"tx_bootstrappackage_carousel_item\":0,\"tx_bootstrappackage_accordion_item\":0,\"tx_bootstrappackage_icon_group_item\":0,\"tx_bootstrappackage_tab_item\":0,\"tx_bootstrappackage_timeline_item\":0,\"background_color_class\":\"none\",\"background_image\":0,\"background_image_options\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"behaviour\\\">\\n                    <value index=\\\"vDEF\\\">cover<\\/value>\\n                <\\/field>\\n                <field index=\\\"parallax\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"fade\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"filter\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"tx_pizpalue_classes\":\"\",\"tx_pizpalue_style\":\"\",\"tx_pizpalue_attributes\":\"\",\"tx_pizpalue_animation\":\"0\",\"tx_pizpalue_image_variants\":\"variants\",\"tx_pizpalue_image_scaling\":\"xxl: 1.0,\\nxl: 1.0,\\nlg: 1.0,\\nmd: 1.0,\\nsm: 1.0,\\nxs: 1.0\",\"tx_pizpalue_layout_breakpoint\":\"\",\"aspect_ratio\":\"1.3333333333333\",\"items_per_page\":10,\"tx_pizpalue_background_image_variants\":\"pageVariants\",\"tx_container_parent\":0,\"tx_pizpalue_header_class\":\"none\",\"tx_pizpalue_subheader_class\":\"none\",\"tx_pizpalue_image_aspect_ratio\":\"xxl: 0,\\nxl: 0,\\nlg: 0,\\nmd: 0,\\nsm: 0,\\nxs: 0\",\"frame_layout\":\"default\",\"frame_options\":\"\"}',0,'0400$1c3dc4ed9ed0d53f323b56ab55e4b920:d3b03e9c0afad0e9a4dec8125e8fb0af'),(426,1639141369,2,'BE',1,0,1034,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"\"},\"newRecord\":{\"l18n_diffsource\":\"a:40:{s:5:\\\"CType\\\";N;s:6:\\\"colPos\\\";N;s:19:\\\"tx_container_parent\\\";N;s:6:\\\"header\\\";N;s:13:\\\"header_layout\\\";N;s:24:\\\"tx_pizpalue_header_class\\\";N;s:15:\\\"header_position\\\";N;s:4:\\\"date\\\";N;s:11:\\\"header_link\\\";N;s:9:\\\"subheader\\\";N;s:27:\\\"tx_pizpalue_subheader_class\\\";N;s:9:\\\"list_type\\\";N;s:26:\\\"tx_pizpalue_image_variants\\\";N;s:5:\\\"pages\\\";N;s:9:\\\"recursive\\\";N;s:6:\\\"layout\\\";N;s:29:\\\"tx_pizpalue_layout_breakpoint\\\";N;s:18:\\\"space_before_class\\\";N;s:17:\\\"space_after_class\\\";N;s:11:\\\"frame_class\\\";N;s:12:\\\"frame_layout\\\";N;s:13:\\\"frame_options\\\";N;s:22:\\\"background_color_class\\\";N;s:16:\\\"background_image\\\";N;s:24:\\\"background_image_options\\\";N;s:37:\\\"tx_pizpalue_background_image_variants\\\";N;s:21:\\\"tx_pizpalue_animation\\\";N;s:19:\\\"tx_pizpalue_classes\\\";N;s:17:\\\"tx_pizpalue_style\\\";N;s:22:\\\"tx_pizpalue_attributes\\\";N;s:12:\\\"sectionIndex\\\";N;s:9:\\\"linkToTop\\\";N;s:16:\\\"sys_language_uid\\\";N;s:6:\\\"hidden\\\";N;s:9:\\\"starttime\\\";N;s:7:\\\"endtime\\\";N;s:8:\\\"fe_group\\\";N;s:8:\\\"editlock\\\";N;s:10:\\\"categories\\\";N;s:14:\\\"rowDescription\\\";N;}\"}}',0,'0400$13d7cd2fbefc237897464791e1b59831:d3b03e9c0afad0e9a4dec8125e8fb0af'),(427,1639215659,2,'BE',1,0,3,'sys_template','{\"oldRecord\":{\"constants\":\"pizpalue.agency.siteMode = 1\"},\"newRecord\":{\"constants\":\"pizpalue.agency.siteMode = 1\\npage.theme.contact.button.pageUid = 0\"}}',0,'0400$639d6a50e652c57a1a50d57a6d77ddd0:b88ca63c030b2d23227de0950118f07a'),(428,1643738714,2,'BE',1,0,1,'tx_grevman_domain_model_event','{\"oldRecord\":{\"hidden\":0,\"l10n_diffsource\":\"a:24:{s:5:\\\"title\\\";N;s:4:\\\"slug\\\";N;s:9:\\\"startdate\\\";N;s:7:\\\"enddate\\\";N;s:6:\\\"teaser\\\";N;s:11:\\\"description\\\";N;s:7:\\\"program\\\";N;s:4:\\\"link\\\";N;s:8:\\\"location\\\";N;s:5:\\\"price\\\";N;s:6:\\\"images\\\";N;s:5:\\\"files\\\";N;s:13:\\\"member_groups\\\";N;s:13:\\\"registrations\\\";N;s:5:\\\"notes\\\";N;s:6:\\\"guests\\\";N;s:17:\\\"enable_recurrence\\\";N;s:18:\\\"recurrence_enddate\\\";N;s:15:\\\"recurrence_rule\\\";N;s:16:\\\"recurrence_dates\\\";N;s:26:\\\"recurrence_exception_dates\\\";N;s:14:\\\"recurrence_set\\\";N;s:16:\\\"sys_language_uid\\\";N;s:6:\\\"hidden\\\";N;}\"},\"newRecord\":{\"hidden\":\"1\",\"l10n_diffsource\":\"a:1:{s:6:\\\"hidden\\\";N;}\"}}',0,'0400$4ef34efb8d234daa546eefcb868a773c:e870294c0a9f57aed3f703c79f29898e'),(429,1643738721,2,'BE',1,0,1,'tx_grevman_domain_model_event','{\"oldRecord\":{\"hidden\":1},\"newRecord\":{\"hidden\":\"0\"}}',0,'0400$a47f2b807a2472694024acab638f987c:e870294c0a9f57aed3f703c79f29898e'),(430,1643738741,2,'BE',1,0,1,'tx_grevman_domain_model_event','{\"oldRecord\":{\"hidden\":0},\"newRecord\":{\"hidden\":\"1\"}}',0,'0400$e8d6f88a1eabacba45fa9beacc11d990:e870294c0a9f57aed3f703c79f29898e'),(431,1643738742,2,'BE',1,0,1,'tx_grevman_domain_model_event','{\"oldRecord\":{\"hidden\":1},\"newRecord\":{\"hidden\":\"0\"}}',0,'0400$9f9fd19b44be6089069a9c49fed239ac:e870294c0a9f57aed3f703c79f29898e'),(432,1643738744,2,'BE',1,0,1,'tx_grevman_domain_model_event','{\"oldRecord\":{\"hidden\":0},\"newRecord\":{\"hidden\":\"1\"}}',0,'0400$25473fc02615d0c13f925cc534818eae:e870294c0a9f57aed3f703c79f29898e'),(433,1643738745,2,'BE',1,0,1,'tx_grevman_domain_model_event','{\"oldRecord\":{\"hidden\":1},\"newRecord\":{\"hidden\":\"0\"}}',0,'0400$c105a313a05c46a7c87e33e4931d2367:e870294c0a9f57aed3f703c79f29898e'),(434,1643740481,2,'BE',1,0,154,'tx_grevman_domain_model_registration','{\"oldRecord\":{\"state\":9,\"l10n_diffsource\":\"\"},\"newRecord\":{\"state\":\"0\",\"l10n_diffsource\":\"a:4:{s:16:\\\"sys_language_uid\\\";N;s:6:\\\"hidden\\\";N;s:5:\\\"state\\\";N;s:6:\\\"member\\\";N;}\"}}',0,'0400$a317de88d0784c2191c1aed5acd3b419:551af6a5a292ab11936c85c78ec8db92'),(435,1643740494,2,'BE',1,0,154,'tx_grevman_domain_model_registration','{\"oldRecord\":{\"state\":0},\"newRecord\":{\"state\":\"9\"}}',0,'0400$73dc31cc0e30555508a215cfd61f0e07:551af6a5a292ab11936c85c78ec8db92'),(436,1643779022,2,'BE',1,0,1,'tx_grevman_domain_model_event','{\"oldRecord\":{\"hidden\":0},\"newRecord\":{\"hidden\":\"1\"}}',0,'0400$3e485febcc6b8ba10d3f2187eb5cc66c:e870294c0a9f57aed3f703c79f29898e'),(437,1643779024,2,'BE',1,0,1,'tx_grevman_domain_model_event','{\"oldRecord\":{\"hidden\":1},\"newRecord\":{\"hidden\":\"0\"}}',0,'0400$53ed1232b3f8452f8349b8dc9e274e9e:e870294c0a9f57aed3f703c79f29898e'),(438,1644919553,2,'BE',1,0,1,'tx_grevman_domain_model_event','{\"oldRecord\":{\"price\":50,\"recurrence_rule\":\"FREQ=MONTHLY;INTERVAL=3\",\"l10n_diffsource\":\"a:1:{s:6:\\\"hidden\\\";N;}\"},\"newRecord\":{\"price\":\"50.00\",\"recurrence_rule\":\"FREQ=WEEKLY\",\"l10n_diffsource\":\"a:24:{s:5:\\\"title\\\";N;s:4:\\\"slug\\\";N;s:9:\\\"startdate\\\";N;s:7:\\\"enddate\\\";N;s:6:\\\"teaser\\\";N;s:11:\\\"description\\\";N;s:7:\\\"program\\\";N;s:4:\\\"link\\\";N;s:8:\\\"location\\\";N;s:5:\\\"price\\\";N;s:6:\\\"images\\\";N;s:5:\\\"files\\\";N;s:13:\\\"member_groups\\\";N;s:13:\\\"registrations\\\";N;s:5:\\\"notes\\\";N;s:6:\\\"guests\\\";N;s:17:\\\"enable_recurrence\\\";N;s:18:\\\"recurrence_enddate\\\";N;s:15:\\\"recurrence_rule\\\";N;s:16:\\\"recurrence_dates\\\";N;s:26:\\\"recurrence_exception_dates\\\";N;s:14:\\\"recurrence_set\\\";N;s:16:\\\"sys_language_uid\\\";N;s:6:\\\"hidden\\\";N;}\"}}',0,'0400$e3145f76ae44d3c065299d197c358b94:e870294c0a9f57aed3f703c79f29898e'),(439,1644919572,2,'BE',1,0,1,'tx_grevman_domain_model_event','{\"oldRecord\":{\"price\":50,\"recurrence_dates\":\"01.07.22\",\"recurrence_exception_dates\":\"06.07.22\"},\"newRecord\":{\"price\":\"50.00\",\"recurrence_dates\":\"\",\"recurrence_exception_dates\":\"\"}}',0,'0400$48b7113a20a3f9ef107af0cdb2db1f39:e870294c0a9f57aed3f703c79f29898e'),(440,1644934108,3,'BE',1,0,227,'pages','{\"oldPageId\":223,\"newPageId\":1,\"oldData\":{\"header\":\"Login\",\"pid\":223,\"event_pid\":227,\"t3ver_state\":0,\"_ORIG_pid\":null},\"newData\":{\"tstamp\":1644934108,\"pid\":1,\"sorting\":2464}}',0,'0400$2255d201ffe35b8e055575bf701d0639:a1d387fb4c6b432d6ed2f9655153cfc5'),(441,1644934113,3,'BE',1,0,223,'pages','{\"oldPageId\":1,\"newPageId\":1,\"oldData\":{\"header\":\"Grevman\",\"pid\":1,\"event_pid\":223,\"t3ver_state\":0,\"_ORIG_pid\":null},\"newData\":{\"tstamp\":1644934113,\"pid\":1,\"sorting\":1232}}',0,'0400$dc199f8dda859f2742ffa97728840d58:6033cdb935dba6ebfc9bb3a182593af4'),(442,1644934149,3,'BE',1,0,234,'pages','{\"oldPageId\":223,\"newPageId\":1,\"oldData\":{\"header\":\"Messenger\",\"pid\":223,\"event_pid\":234,\"t3ver_state\":0,\"_ORIG_pid\":null},\"newData\":{\"tstamp\":1644934149,\"pid\":1,\"sorting\":1848}}',0,'0400$84667dd88bb19169fce02f88f71ebdc3:e72c60104ad6861ae6ab5f66507582e7'),(443,1644935079,2,'BE',1,0,234,'pages','{\"oldRecord\":{\"slug\":\"\\/grevman\\/messenger\",\"fe_group\":\"0\",\"l10n_diffsource\":\"a:1:{s:6:\\\"hidden\\\";N;}\"},\"newRecord\":{\"slug\":\"\\/messenger\",\"fe_group\":\"\",\"l10n_diffsource\":\"a:53:{s:7:\\\"doktype\\\";N;s:5:\\\"title\\\";N;s:4:\\\"slug\\\";N;s:9:\\\"nav_title\\\";N;s:8:\\\"subtitle\\\";N;s:12:\\\"nav_icon_set\\\";N;s:8:\\\"nav_icon\\\";N;s:9:\\\"seo_title\\\";N;s:11:\\\"description\\\";N;s:8:\\\"no_index\\\";N;s:9:\\\"no_follow\\\";N;s:14:\\\"canonical_link\\\";N;s:18:\\\"sitemap_changefreq\\\";N;s:16:\\\"sitemap_priority\\\";N;s:8:\\\"og_title\\\";N;s:14:\\\"og_description\\\";N;s:8:\\\"og_image\\\";N;s:13:\\\"twitter_title\\\";N;s:19:\\\"twitter_description\\\";N;s:13:\\\"twitter_image\\\";N;s:12:\\\"twitter_card\\\";N;s:8:\\\"abstract\\\";N;s:8:\\\"keywords\\\";N;s:6:\\\"author\\\";N;s:12:\\\"author_email\\\";N;s:11:\\\"lastUpdated\\\";N;s:6:\\\"layout\\\";N;s:8:\\\"newUntil\\\";N;s:14:\\\"backend_layout\\\";N;s:25:\\\"backend_layout_next_level\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"content_from_pid\\\";N;s:6:\\\"target\\\";N;s:13:\\\"cache_timeout\\\";N;s:10:\\\"cache_tags\\\";N;s:11:\\\"is_siteroot\\\";N;s:9:\\\"no_search\\\";N;s:13:\\\"php_tree_stop\\\";N;s:6:\\\"module\\\";N;s:5:\\\"media\\\";N;s:17:\\\"tsconfig_includes\\\";N;s:8:\\\"TSconfig\\\";N;s:8:\\\"l18n_cfg\\\";N;s:6:\\\"hidden\\\";N;s:8:\\\"nav_hide\\\";N;s:9:\\\"starttime\\\";N;s:7:\\\"endtime\\\";N;s:16:\\\"extendToSubpages\\\";N;s:8:\\\"fe_group\\\";N;s:13:\\\"fe_login_mode\\\";N;s:8:\\\"editlock\\\";N;s:10:\\\"categories\\\";N;s:14:\\\"rowDescription\\\";N;}\"}}',0,'0400$4cfed17feb7ae9f9a4aeeae07828bf7b:e72c60104ad6861ae6ab5f66507582e7'),(444,1644935093,2,'BE',1,0,227,'pages','{\"oldRecord\":{\"slug\":\"\\/grevman\\/login\",\"fe_group\":\"0\",\"l10n_diffsource\":\"\"},\"newRecord\":{\"slug\":\"\\/login\",\"fe_group\":\"\",\"l10n_diffsource\":\"a:53:{s:7:\\\"doktype\\\";N;s:5:\\\"title\\\";N;s:4:\\\"slug\\\";N;s:9:\\\"nav_title\\\";N;s:8:\\\"subtitle\\\";N;s:12:\\\"nav_icon_set\\\";N;s:8:\\\"nav_icon\\\";N;s:9:\\\"seo_title\\\";N;s:11:\\\"description\\\";N;s:8:\\\"no_index\\\";N;s:9:\\\"no_follow\\\";N;s:14:\\\"canonical_link\\\";N;s:18:\\\"sitemap_changefreq\\\";N;s:16:\\\"sitemap_priority\\\";N;s:8:\\\"og_title\\\";N;s:14:\\\"og_description\\\";N;s:8:\\\"og_image\\\";N;s:13:\\\"twitter_title\\\";N;s:19:\\\"twitter_description\\\";N;s:13:\\\"twitter_image\\\";N;s:12:\\\"twitter_card\\\";N;s:8:\\\"abstract\\\";N;s:8:\\\"keywords\\\";N;s:6:\\\"author\\\";N;s:12:\\\"author_email\\\";N;s:11:\\\"lastUpdated\\\";N;s:6:\\\"layout\\\";N;s:8:\\\"newUntil\\\";N;s:14:\\\"backend_layout\\\";N;s:25:\\\"backend_layout_next_level\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"content_from_pid\\\";N;s:6:\\\"target\\\";N;s:13:\\\"cache_timeout\\\";N;s:10:\\\"cache_tags\\\";N;s:11:\\\"is_siteroot\\\";N;s:9:\\\"no_search\\\";N;s:13:\\\"php_tree_stop\\\";N;s:6:\\\"module\\\";N;s:5:\\\"media\\\";N;s:17:\\\"tsconfig_includes\\\";N;s:8:\\\"TSconfig\\\";N;s:8:\\\"l18n_cfg\\\";N;s:6:\\\"hidden\\\";N;s:8:\\\"nav_hide\\\";N;s:9:\\\"starttime\\\";N;s:7:\\\"endtime\\\";N;s:16:\\\"extendToSubpages\\\";N;s:8:\\\"fe_group\\\";N;s:13:\\\"fe_login_mode\\\";N;s:8:\\\"editlock\\\";N;s:10:\\\"categories\\\";N;s:14:\\\"rowDescription\\\";N;}\"}}',0,'0400$f71164d745daa8998e3a320bf4674228:a1d387fb4c6b432d6ed2f9655153cfc5'),(445,1645014558,2,'BE',1,0,14,'fe_users','{\"oldRecord\":{\"email\":\"trainer1@grevman.ch\"},\"newRecord\":{\"email\":\"leader1@grevman.ddev.site\"}}',0,'0400$b774ec266ddefbca6e69b3a099e43db7:80a0ca8bb65b232d594edc8b20e07a63'),(446,1645014558,2,'BE',1,0,15,'fe_users','{\"oldRecord\":{\"email\":\"\"},\"newRecord\":{\"email\":\"leader2@grevman.ddev.site\"}}',0,'0400$b774ec266ddefbca6e69b3a099e43db7:ebe39c8cbb0fa86faa04f461990bb081'),(447,1645016303,2,'BE',1,0,10,'fe_users','{\"oldRecord\":{\"email\":\"\"},\"newRecord\":{\"email\":\"participant1@grevman.ddev.site\"}}',0,'0400$5d597693f17ad0a73fcc8be18619b45a:17315ae0df8028dfed5d43922b91b0f3'),(448,1645016303,2,'BE',1,0,11,'fe_users','{\"oldRecord\":{\"email\":\"\"},\"newRecord\":{\"email\":\"participant2@grevman.ddev.site\"}}',0,'0400$5d597693f17ad0a73fcc8be18619b45a:05bdaab0cdbca812d11a47109a616745'),(449,1645016303,2,'BE',1,0,12,'fe_users','{\"oldRecord\":{\"email\":\"\"},\"newRecord\":{\"email\":\"participant3@grevman.ddev.site\"}}',0,'0400$5d597693f17ad0a73fcc8be18619b45a:47fc4e2407b3e247cf902e6542e326bf'),(450,1645016303,2,'BE',1,0,13,'fe_users','{\"oldRecord\":{\"email\":\"\"},\"newRecord\":{\"email\":\"participant4@grevman.ddev.site\"}}',0,'0400$5d597693f17ad0a73fcc8be18619b45a:b9e16b9ff4719c7269ff4aedf4678c1e'),(451,1645016303,2,'BE',1,0,16,'fe_users','{\"oldRecord\":{\"email\":\"\"},\"newRecord\":{\"email\":\"participant11@grevman.ddev.site\"}}',0,'0400$5d597693f17ad0a73fcc8be18619b45a:890ed3a27abc4daf0720627cd568465d'),(452,1645092224,2,'BE',1,0,1,'tx_grevman_domain_model_event','{\"oldRecord\":{\"price\":50},\"newRecord\":{\"price\":\"50.00\"}}',0,'0400$fd9e660d00c26ed340fdf66d166a6f39:e870294c0a9f57aed3f703c79f29898e'),(453,1645092238,2,'BE',1,0,557,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"a:1:{s:6:\\\"hidden\\\";N;}\"}}',0,'0400$98ecfe5575c39b30820c4362b4bc7d50:9cd47b35446257d7a87cf9451891308a'),(454,1645092238,2,'BE',1,0,558,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"a:1:{s:6:\\\"hidden\\\";N;}\"}}',0,'0400$98ecfe5575c39b30820c4362b4bc7d50:2a3bf4ae8547975352eec399cc9b9620'),(455,1645092238,2,'BE',1,0,142,'tx_grevman_domain_model_note','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"a:1:{s:6:\\\"hidden\\\";N;}\"}}',0,'0400$98ecfe5575c39b30820c4362b4bc7d50:c4a430c0efc8cc2a64113da5e54e8b1c'),(456,1645092238,2,'BE',1,0,139,'tx_grevman_domain_model_note','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"a:1:{s:6:\\\"hidden\\\";N;}\"}}',0,'0400$98ecfe5575c39b30820c4362b4bc7d50:c548d515fd480d98ddd6033dc835d59d'),(457,1645092238,2,'BE',1,0,138,'tx_grevman_domain_model_note','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"a:1:{s:6:\\\"hidden\\\";N;}\"}}',0,'0400$98ecfe5575c39b30820c4362b4bc7d50:790e527c4c80b5cccf4a0d193a429ee2'),(458,1645092238,2,'BE',1,0,137,'tx_grevman_domain_model_note','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"a:1:{s:6:\\\"hidden\\\";N;}\"}}',0,'0400$98ecfe5575c39b30820c4362b4bc7d50:a02545026eaacbd228cac5b9e04342bd'),(459,1645095212,2,'BE',1,0,50,'tx_grevman_domain_model_event','{\"oldRecord\":{\"price\":50,\"notes\":5,\"l10n_diffsource\":\"\"},\"newRecord\":{\"price\":\"50.00\",\"notes\":4,\"l10n_diffsource\":\"a:19:{s:5:\\\"title\\\";N;s:4:\\\"slug\\\";N;s:9:\\\"startdate\\\";N;s:7:\\\"enddate\\\";N;s:6:\\\"teaser\\\";N;s:11:\\\"description\\\";N;s:7:\\\"program\\\";N;s:4:\\\"link\\\";N;s:8:\\\"location\\\";N;s:5:\\\"price\\\";N;s:6:\\\"images\\\";N;s:5:\\\"files\\\";N;s:13:\\\"member_groups\\\";N;s:13:\\\"registrations\\\";N;s:5:\\\"notes\\\";N;s:6:\\\"guests\\\";N;s:17:\\\"enable_recurrence\\\";N;s:16:\\\"sys_language_uid\\\";N;s:6:\\\"hidden\\\";N;}\"}}',0,'0400$c723a0c8ba82167400fcab9a068ce8b4:aa0fa1adfcadcde4fe5c4a14f7bb8ddc'),(460,1645095212,2,'BE',1,0,157,'tx_grevman_domain_model_registration','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"a:1:{s:6:\\\"hidden\\\";N;}\"}}',0,'0400$c723a0c8ba82167400fcab9a068ce8b4:84733108dc2b18823fbcddb65a011ba8'),(461,1645095212,2,'BE',1,0,156,'tx_grevman_domain_model_registration','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"a:1:{s:6:\\\"hidden\\\";N;}\"}}',0,'0400$c723a0c8ba82167400fcab9a068ce8b4:87c48255988d33729fe8f9d650a43886'),(462,1645095814,2,'BE',1,0,50,'tx_grevman_domain_model_event','{\"oldRecord\":{\"price\":50,\"registrations\":\"2\"},\"newRecord\":{\"price\":\"50.00\",\"registrations\":\"156,157\"}}',0,'0400$ddd70c667f30676005b717c3d3be1d17:aa0fa1adfcadcde4fe5c4a14f7bb8ddc'),(463,1645096552,3,'BE',1,0,151,'tx_grevman_domain_model_registration','{\"oldPageId\":224,\"newPageId\":224,\"oldData\":{\"header\":\"participant1, Participant1, Last1, Event 1, 08.03.22 17:08\",\"pid\":224,\"event_pid\":224,\"t3ver_state\":0,\"_ORIG_pid\":null},\"newData\":{\"tstamp\":1645096552,\"pid\":224}}',0,'0400$5c1ceb199dd134085fe5c4841a591db4:3645b94f3ea9ad2731e79aa53d7e376d'),(464,1645096552,3,'BE',1,0,152,'tx_grevman_domain_model_registration','{\"oldPageId\":224,\"newPageId\":224,\"oldData\":{\"header\":\"participant1, Participant1, Last1, Event 1, 01.07.22 17:08\",\"pid\":224,\"event_pid\":224,\"t3ver_state\":0,\"_ORIG_pid\":null},\"newData\":{\"tstamp\":1645096552,\"pid\":224}}',0,'0400$5c1ceb199dd134085fe5c4841a591db4:96b6d3f8b503f5f695e84dd8743a92aa'),(465,1645096552,3,'BE',1,0,153,'tx_grevman_domain_model_registration','{\"oldPageId\":224,\"newPageId\":224,\"oldData\":{\"header\":\"participant1, Participant1, Last1, Event 1, 01.07.22 17:08\",\"pid\":224,\"event_pid\":224,\"t3ver_state\":0,\"_ORIG_pid\":null},\"newData\":{\"tstamp\":1645096552,\"pid\":224}}',0,'0400$5c1ceb199dd134085fe5c4841a591db4:481eca4a3e39894ce2d7a257de43fdeb'),(466,1645096552,3,'BE',1,0,154,'tx_grevman_domain_model_registration','{\"oldPageId\":224,\"newPageId\":224,\"oldData\":{\"header\":\"participant1, Participant1, Last1, Event 1, 08.06.22 17:08\",\"pid\":224,\"event_pid\":224,\"t3ver_state\":0,\"_ORIG_pid\":null},\"newData\":{\"tstamp\":1645096552,\"pid\":224}}',0,'0400$5c1ceb199dd134085fe5c4841a591db4:551af6a5a292ab11936c85c78ec8db92'),(467,1645096552,3,'BE',1,0,156,'tx_grevman_domain_model_registration','{\"oldPageId\":224,\"newPageId\":224,\"oldData\":{\"header\":\"participant1, Participant1, Last1, Event 1, 16.02.22 17:08\",\"pid\":224,\"event_pid\":224,\"t3ver_state\":0,\"_ORIG_pid\":null},\"newData\":{\"tstamp\":1645096552,\"pid\":224}}',0,'0400$5c1ceb199dd134085fe5c4841a591db4:87c48255988d33729fe8f9d650a43886'),(468,1645096552,3,'BE',1,0,136,'tx_grevman_domain_model_note','{\"oldPageId\":224,\"newPageId\":224,\"oldData\":{\"header\":\"participant1, Participant1, Last1, Event 1, 01.07.22 17:08, A test note...\",\"pid\":224,\"event_pid\":224,\"t3ver_state\":0,\"_ORIG_pid\":null},\"newData\":{\"tstamp\":1645096552,\"pid\":224}}',0,'0400$5c1ceb199dd134085fe5c4841a591db4:6075fa1f8240daaf2c73a09ba04c5562'),(469,1645096552,3,'BE',1,0,139,'tx_grevman_domain_model_note','{\"oldPageId\":224,\"newPageId\":224,\"oldData\":{\"header\":\"participant1, Participant1, Last1, Event 1, 16.02.22 17:08, Meine dritte Nachricht\",\"pid\":224,\"event_pid\":224,\"t3ver_state\":0,\"_ORIG_pid\":null},\"newData\":{\"tstamp\":1645096552,\"pid\":224}}',0,'0400$5c1ceb199dd134085fe5c4841a591db4:c548d515fd480d98ddd6033dc835d59d'),(470,1645096552,3,'BE',1,0,138,'tx_grevman_domain_model_note','{\"oldPageId\":224,\"newPageId\":224,\"oldData\":{\"header\":\"participant1, Participant1, Last1, Event 1, 16.02.22 17:08, Meine zweite Nachricht\",\"pid\":224,\"event_pid\":224,\"t3ver_state\":0,\"_ORIG_pid\":null},\"newData\":{\"tstamp\":1645096552,\"pid\":224}}',0,'0400$5c1ceb199dd134085fe5c4841a591db4:790e527c4c80b5cccf4a0d193a429ee2'),(471,1645096552,3,'BE',1,0,137,'tx_grevman_domain_model_note','{\"oldPageId\":224,\"newPageId\":224,\"oldData\":{\"header\":\"participant1, Participant1, Last1, Event 1, 16.02.22 17:08, Meine erste Nachricht\",\"pid\":224,\"event_pid\":224,\"t3ver_state\":0,\"_ORIG_pid\":null},\"newData\":{\"tstamp\":1645096552,\"pid\":224}}',0,'0400$5c1ceb199dd134085fe5c4841a591db4:a02545026eaacbd228cac5b9e04342bd'),(472,1645096552,3,'BE',1,0,10,'fe_users','{\"oldPageId\":225,\"newPageId\":224,\"oldData\":{\"header\":\"participant1, Participant1, Last1\",\"pid\":225,\"event_pid\":225,\"t3ver_state\":\"\",\"_ORIG_pid\":null},\"newData\":{\"tstamp\":1645096552,\"pid\":224}}',0,'0400$5c1ceb199dd134085fe5c4841a591db4:17315ae0df8028dfed5d43922b91b0f3'),(473,1645096569,3,'BE',1,0,156,'tx_grevman_domain_model_registration','{\"oldPageId\":224,\"newPageId\":225,\"oldData\":{\"header\":\"participant1, Participant1, Last1, Event 1, 16.02.22 17:08\",\"pid\":224,\"event_pid\":224,\"t3ver_state\":0,\"_ORIG_pid\":null},\"newData\":{\"tstamp\":1645096569,\"pid\":225}}',0,'0400$3670876f8532780b04e16d775e41b4fe:87c48255988d33729fe8f9d650a43886'),(474,1645096569,3,'BE',1,0,154,'tx_grevman_domain_model_registration','{\"oldPageId\":224,\"newPageId\":225,\"oldData\":{\"header\":\"participant1, Participant1, Last1, Event 1, 08.06.22 17:08\",\"pid\":224,\"event_pid\":224,\"t3ver_state\":0,\"_ORIG_pid\":null},\"newData\":{\"tstamp\":1645096569,\"pid\":225}}',0,'0400$3670876f8532780b04e16d775e41b4fe:551af6a5a292ab11936c85c78ec8db92'),(475,1645096569,3,'BE',1,0,153,'tx_grevman_domain_model_registration','{\"oldPageId\":224,\"newPageId\":225,\"oldData\":{\"header\":\"participant1, Participant1, Last1, Event 1, 01.07.22 17:08\",\"pid\":224,\"event_pid\":224,\"t3ver_state\":0,\"_ORIG_pid\":null},\"newData\":{\"tstamp\":1645096569,\"pid\":225}}',0,'0400$3670876f8532780b04e16d775e41b4fe:481eca4a3e39894ce2d7a257de43fdeb'),(476,1645096569,3,'BE',1,0,152,'tx_grevman_domain_model_registration','{\"oldPageId\":224,\"newPageId\":225,\"oldData\":{\"header\":\"participant1, Participant1, Last1, Event 1, 01.07.22 17:08\",\"pid\":224,\"event_pid\":224,\"t3ver_state\":0,\"_ORIG_pid\":null},\"newData\":{\"tstamp\":1645096569,\"pid\":225}}',0,'0400$3670876f8532780b04e16d775e41b4fe:96b6d3f8b503f5f695e84dd8743a92aa'),(477,1645096569,3,'BE',1,0,151,'tx_grevman_domain_model_registration','{\"oldPageId\":224,\"newPageId\":225,\"oldData\":{\"header\":\"participant1, Participant1, Last1, Event 1, 08.03.22 17:08\",\"pid\":224,\"event_pid\":224,\"t3ver_state\":0,\"_ORIG_pid\":null},\"newData\":{\"tstamp\":1645096569,\"pid\":225}}',0,'0400$3670876f8532780b04e16d775e41b4fe:3645b94f3ea9ad2731e79aa53d7e376d'),(478,1645096569,3,'BE',1,0,139,'tx_grevman_domain_model_note','{\"oldPageId\":224,\"newPageId\":225,\"oldData\":{\"header\":\"participant1, Participant1, Last1, Event 1, 16.02.22 17:08, Meine dritte Nachricht\",\"pid\":224,\"event_pid\":224,\"t3ver_state\":0,\"_ORIG_pid\":null},\"newData\":{\"tstamp\":1645096569,\"pid\":225}}',0,'0400$3670876f8532780b04e16d775e41b4fe:c548d515fd480d98ddd6033dc835d59d'),(479,1645096569,3,'BE',1,0,138,'tx_grevman_domain_model_note','{\"oldPageId\":224,\"newPageId\":225,\"oldData\":{\"header\":\"participant1, Participant1, Last1, Event 1, 16.02.22 17:08, Meine zweite Nachricht\",\"pid\":224,\"event_pid\":224,\"t3ver_state\":0,\"_ORIG_pid\":null},\"newData\":{\"tstamp\":1645096569,\"pid\":225}}',0,'0400$3670876f8532780b04e16d775e41b4fe:790e527c4c80b5cccf4a0d193a429ee2'),(480,1645096569,3,'BE',1,0,137,'tx_grevman_domain_model_note','{\"oldPageId\":224,\"newPageId\":225,\"oldData\":{\"header\":\"participant1, Participant1, Last1, Event 1, 16.02.22 17:08, Meine erste Nachricht\",\"pid\":224,\"event_pid\":224,\"t3ver_state\":0,\"_ORIG_pid\":null},\"newData\":{\"tstamp\":1645096569,\"pid\":225}}',0,'0400$3670876f8532780b04e16d775e41b4fe:a02545026eaacbd228cac5b9e04342bd'),(481,1645096569,3,'BE',1,0,136,'tx_grevman_domain_model_note','{\"oldPageId\":224,\"newPageId\":225,\"oldData\":{\"header\":\"participant1, Participant1, Last1, Event 1, 01.07.22 17:08, A test note...\",\"pid\":224,\"event_pid\":224,\"t3ver_state\":0,\"_ORIG_pid\":null},\"newData\":{\"tstamp\":1645096569,\"pid\":225}}',0,'0400$3670876f8532780b04e16d775e41b4fe:6075fa1f8240daaf2c73a09ba04c5562'),(482,1645096569,3,'BE',1,0,10,'fe_users','{\"oldPageId\":224,\"newPageId\":225,\"oldData\":{\"header\":\"participant1, Participant1, Last1\",\"pid\":224,\"event_pid\":224,\"t3ver_state\":\"\",\"_ORIG_pid\":null},\"newData\":{\"tstamp\":1645096569,\"pid\":225}}',0,'0400$3670876f8532780b04e16d775e41b4fe:17315ae0df8028dfed5d43922b91b0f3'),(483,1645097068,3,'BE',1,0,139,'tx_grevman_domain_model_note','{\"oldPageId\":225,\"newPageId\":224,\"oldData\":{\"header\":\"participant1, Participant1, Last1, Event 1, 16.02.22 17:08, Meine dritte Nachricht\",\"pid\":225,\"event_pid\":225,\"t3ver_state\":0,\"_ORIG_pid\":null},\"newData\":{\"tstamp\":1645097068,\"pid\":224}}',0,'0400$7117af6967ac234b298cce89cb83fc6f:c548d515fd480d98ddd6033dc835d59d'),(484,1645097068,3,'BE',1,0,138,'tx_grevman_domain_model_note','{\"oldPageId\":225,\"newPageId\":224,\"oldData\":{\"header\":\"participant1, Participant1, Last1, Event 1, 16.02.22 17:08, Meine zweite Nachricht\",\"pid\":225,\"event_pid\":225,\"t3ver_state\":0,\"_ORIG_pid\":null},\"newData\":{\"tstamp\":1645097068,\"pid\":224}}',0,'0400$7117af6967ac234b298cce89cb83fc6f:790e527c4c80b5cccf4a0d193a429ee2'),(485,1645097068,3,'BE',1,0,137,'tx_grevman_domain_model_note','{\"oldPageId\":225,\"newPageId\":224,\"oldData\":{\"header\":\"participant1, Participant1, Last1, Event 1, 16.02.22 17:08, Meine erste Nachricht\",\"pid\":225,\"event_pid\":225,\"t3ver_state\":0,\"_ORIG_pid\":null},\"newData\":{\"tstamp\":1645097068,\"pid\":224}}',0,'0400$7117af6967ac234b298cce89cb83fc6f:a02545026eaacbd228cac5b9e04342bd'),(486,1645097068,3,'BE',1,0,136,'tx_grevman_domain_model_note','{\"oldPageId\":225,\"newPageId\":224,\"oldData\":{\"header\":\"participant1, Participant1, Last1, Event 1, 01.07.22 17:08, A test note...\",\"pid\":225,\"event_pid\":225,\"t3ver_state\":0,\"_ORIG_pid\":null},\"newData\":{\"tstamp\":1645097068,\"pid\":224}}',0,'0400$7117af6967ac234b298cce89cb83fc6f:6075fa1f8240daaf2c73a09ba04c5562'),(487,1645097068,3,'BE',1,0,156,'tx_grevman_domain_model_registration','{\"oldPageId\":225,\"newPageId\":224,\"oldData\":{\"header\":\"participant1, Participant1, Last1, Event 1, 16.02.22 17:08\",\"pid\":225,\"event_pid\":225,\"t3ver_state\":0,\"_ORIG_pid\":null},\"newData\":{\"tstamp\":1645097068,\"pid\":224}}',0,'0400$7117af6967ac234b298cce89cb83fc6f:87c48255988d33729fe8f9d650a43886'),(488,1645097068,3,'BE',1,0,154,'tx_grevman_domain_model_registration','{\"oldPageId\":225,\"newPageId\":224,\"oldData\":{\"header\":\"participant1, Participant1, Last1, Event 1, 08.06.22 17:08\",\"pid\":225,\"event_pid\":225,\"t3ver_state\":0,\"_ORIG_pid\":null},\"newData\":{\"tstamp\":1645097068,\"pid\":224}}',0,'0400$7117af6967ac234b298cce89cb83fc6f:551af6a5a292ab11936c85c78ec8db92'),(489,1645097068,3,'BE',1,0,153,'tx_grevman_domain_model_registration','{\"oldPageId\":225,\"newPageId\":224,\"oldData\":{\"header\":\"participant1, Participant1, Last1, Event 1, 01.07.22 17:08\",\"pid\":225,\"event_pid\":225,\"t3ver_state\":0,\"_ORIG_pid\":null},\"newData\":{\"tstamp\":1645097068,\"pid\":224}}',0,'0400$7117af6967ac234b298cce89cb83fc6f:481eca4a3e39894ce2d7a257de43fdeb'),(490,1645097068,3,'BE',1,0,152,'tx_grevman_domain_model_registration','{\"oldPageId\":225,\"newPageId\":224,\"oldData\":{\"header\":\"participant1, Participant1, Last1, Event 1, 01.07.22 17:08\",\"pid\":225,\"event_pid\":225,\"t3ver_state\":0,\"_ORIG_pid\":null},\"newData\":{\"tstamp\":1645097068,\"pid\":224}}',0,'0400$7117af6967ac234b298cce89cb83fc6f:96b6d3f8b503f5f695e84dd8743a92aa'),(491,1645097068,3,'BE',1,0,151,'tx_grevman_domain_model_registration','{\"oldPageId\":225,\"newPageId\":224,\"oldData\":{\"header\":\"participant1, Participant1, Last1, Event 1, 08.03.22 17:08\",\"pid\":225,\"event_pid\":225,\"t3ver_state\":0,\"_ORIG_pid\":null},\"newData\":{\"tstamp\":1645097068,\"pid\":224}}',0,'0400$7117af6967ac234b298cce89cb83fc6f:3645b94f3ea9ad2731e79aa53d7e376d');
/*!40000 ALTER TABLE `sys_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_language`
--

DROP TABLE IF EXISTS `sys_language`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_language` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `title` varchar(80) NOT NULL DEFAULT '',
  `flag` varchar(20) NOT NULL DEFAULT '',
  `language_isocode` varchar(2) NOT NULL DEFAULT '',
  `nav_title` varchar(255) NOT NULL DEFAULT '',
  `locale` varchar(20) NOT NULL DEFAULT '',
  `hreflang` varchar(20) NOT NULL DEFAULT '',
  `direction` varchar(3) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_language`
--

LOCK TABLES `sys_language` WRITE;
/*!40000 ALTER TABLE `sys_language` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_language` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_lockedrecords`
--

DROP TABLE IF EXISTS `sys_lockedrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_lockedrecords` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `record_table` varchar(255) NOT NULL DEFAULT '',
  `record_uid` int(11) NOT NULL DEFAULT 0,
  `record_pid` int(11) NOT NULL DEFAULT 0,
  `username` varchar(50) NOT NULL DEFAULT '',
  `feuserid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=4864 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_lockedrecords`
--

LOCK TABLES `sys_lockedrecords` WRITE;
/*!40000 ALTER TABLE `sys_lockedrecords` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_lockedrecords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_news`
--

DROP TABLE IF EXISTS `sys_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_news` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `content` mediumtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_news`
--

LOCK TABLES `sys_news` WRITE;
/*!40000 ALTER TABLE `sys_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_note`
--

DROP TABLE IF EXISTS `sys_note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_note` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `subject` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `message` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `personal` smallint(5) unsigned NOT NULL DEFAULT 0,
  `category` smallint(5) unsigned NOT NULL DEFAULT 0,
  `position` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_note`
--

LOCK TABLES `sys_note` WRITE;
/*!40000 ALTER TABLE `sys_note` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_refindex`
--

DROP TABLE IF EXISTS `sys_refindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_refindex` (
  `hash` varchar(32) NOT NULL DEFAULT '',
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `recuid` int(11) NOT NULL DEFAULT 0,
  `field` varchar(64) NOT NULL DEFAULT '',
  `flexpointer` varchar(255) NOT NULL DEFAULT '',
  `softref_key` varchar(30) NOT NULL DEFAULT '',
  `softref_id` varchar(40) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `deleted` smallint(6) NOT NULL DEFAULT 0,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `ref_table` varchar(255) NOT NULL DEFAULT '',
  `ref_uid` int(11) NOT NULL DEFAULT 0,
  `ref_string` varchar(1024) NOT NULL DEFAULT '',
  PRIMARY KEY (`hash`),
  KEY `lookup_rec` (`tablename`(100),`recuid`),
  KEY `lookup_uid` (`ref_table`(100),`ref_uid`),
  KEY `lookup_string` (`ref_string`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_refindex`
--

LOCK TABLES `sys_refindex` WRITE;
/*!40000 ALTER TABLE `sys_refindex` DISABLE KEYS */;
INSERT INTO `sys_refindex` VALUES ('001b15036a42940e9fd40102c884ee9d','tx_grevman_domain_model_registration',132,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('011c65134b6569fbf2f21707e75ec574','tx_grevman_domain_model_note',50,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('0125fcd2ebb68f93555b311d55366434','tx_grevman_domain_model_registration',83,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('0128701c531bdd06f9c5492a074d45e5','tx_grevman_domain_model_registration',100,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('01cb009e7852c4f428d7e298591a76ae','tx_grevman_domain_model_note',4,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('0204000d4a4e2ef620d0b364d2e6f87c','tx_grevman_domain_model_group',2,'members','','','',3,0,0,'fe_users',15,''),('02a58977ad9eea43da3faaa840692b01','tx_grevman_domain_model_note',94,'member','','','',0,1,0,'fe_users',10,''),('02b3e29d2cc5bcc33976afd340b9d16b','sys_file_reference',508,'uid_local','','','',0,1,0,'sys_file',163,''),('02baffa60f3c7c2c6535013462b7a4bc','tx_grevman_domain_model_event',11,'member_groups','','','',0,1,0,'tx_grevman_domain_model_group',1,''),('0465c252273c4ffca5763556cfefe927','tx_grevman_domain_model_note',61,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('049ccf1e44d5c1402b210680c1363830','tx_grevman_domain_model_registration',111,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('04e0adcc93e873137b87611176c47cf6','tx_grevman_domain_model_group',2,'members','','','',0,0,0,'fe_users',11,''),('050a3682e63e72c8edeb59caef22a234','tx_grevman_domain_model_registration',71,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('05c1db4ddfeff1e28c828149c16e57f0','tx_grevman_domain_model_note',78,'member','','','',0,1,0,'fe_users',10,''),('067920d8309f66022d07db156461dd82','tx_grevman_domain_model_registration',90,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('06aa6a0f66ae86e27c518f50e97ed6f6','tx_grevman_domain_model_event',23,'parent','','','',0,1,0,'tx_grevman_domain_model_event',1,''),('06edb943115d7b8198753b7089d56053','tx_grevman_domain_model_note',87,'member','','','',0,1,0,'fe_users',10,''),('06f67c6a63986a7e8fe293bd11c7b550','tx_grevman_domain_model_event',15,'member_groups','','','',0,1,0,'tx_grevman_domain_model_group',1,''),('077dd79a46b386a49c65003d32243398','tx_grevman_domain_model_registration',140,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('07d9c30a88abca6a6f7d5e4e18c8244b','tx_grevman_domain_model_registration',104,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('08045c0794b2a105c1f605083fac8f00','fe_users',10,'notes','','','',1,0,0,'tx_grevman_domain_model_note',138,''),('080545fbd506dec6b97ee9925811991d','tx_grevman_domain_model_registration',117,'member','','','',0,1,0,'fe_users',12,''),('0875146fda3313c075333f56f147a8d5','tx_grevman_domain_model_registration',89,'member','','','',0,1,0,'fe_users',12,''),('0886c0380692d02823d591ba744f1ce9','tx_grevman_domain_model_note',31,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('08f36ae5a1ea0f2b3997840ad93821ba','tx_grevman_domain_model_note',113,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('093a9da2daa76d94b8cf8f56729a80c6','tx_grevman_domain_model_note',104,'member','','','',0,1,0,'fe_users',10,''),('0959c9e8bc6a639a68e751e22a7c1cc7','tx_grevman_domain_model_note',19,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('095efb966c771cefecac48e77ff78e54','tx_grevman_domain_model_note',93,'member','','','',0,1,0,'fe_users',10,''),('096650b3258a7c3a27ff2a809cf04bf7','tx_grevman_domain_model_event',27,'member_groups','','','',0,1,0,'tx_grevman_domain_model_group',1,''),('09972dbe1c393698ead9a7bae3667185','tx_grevman_domain_model_registration',62,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('099f32de05408ef16265c5151d3374ee','sys_file_metadata',13,'file','','','',0,0,0,'sys_file',157,''),('09d3768a2f17d5f42f1631211d2d5e85','tx_grevman_domain_model_registration',68,'member','','','',0,0,0,'fe_users',16,''),('0a889c1d3acfa4690160f67045782b17','tx_grevman_domain_model_event',50,'member_groups','','','',0,0,0,'tx_grevman_domain_model_group',1,''),('0a9f6f68cfccaa024aa82a276cd8e17c','tx_grevman_domain_model_registration',37,'member','','','',0,0,0,'fe_users',12,''),('0ac6ca4a49534ce6bf8be315f684a6f1','tx_grevman_domain_model_registration',69,'member','','','',0,0,0,'fe_users',12,''),('0bc87e1b9842fbd306e828ede388d08d','tx_grevman_domain_model_registration',63,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('0c0b80d42aed3a70b5f45df64f801fb8','tx_grevman_domain_model_registration',108,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('0c1b8eea4d81172b050236b4d7075bd4','tx_grevman_domain_model_registration',23,'event','','','',0,1,0,'tx_grevman_domain_model_event',39,''),('0c98728f56aef4145f42e91babb4a7d7','tx_grevman_domain_model_event',7,'parent','','','',0,1,0,'tx_grevman_domain_model_event',1,''),('0cc15bc3c775aea8dc9b8013111a835a','tx_grevman_domain_model_registration',45,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('0d2007f88e3f5cfb96a008e30689e6e5','tx_grevman_domain_model_note',95,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('0d71c1f47f9e2ef2ead96876f4302db8','sys_file_reference',522,'uid_local','','','',0,1,0,'sys_file',162,''),('0e2a8f684f7270b57baa8f39277a8725','tx_grevman_domain_model_registration',15,'member','','','',0,1,0,'fe_users',10,''),('0e442bcdfb452542027ca98ced6b3a3a','tx_grevman_domain_model_registration',55,'member','','','',0,0,0,'fe_users',11,''),('0e6314c4bb784d4724ac8545f0cf3769','sys_file_reference',540,'uid_local','','','',0,1,0,'sys_file',163,''),('0e6695d1e071c4b4b1287186ed97821b','tx_grevman_domain_model_note',115,'member','','','',0,1,0,'fe_users',10,''),('0f4689da842510666e5c180db7bff1d6','sys_file',160,'storage','','','',0,0,0,'sys_file_storage',1,''),('0fa937fbd8f0dd597ca1dea1ff78653f','sys_file_reference',509,'uid_local','','','',0,1,0,'sys_file',163,''),('0ffc4c5b41756f8b7ca8eb75ea3bca37','sys_file',162,'metadata','','','',0,0,0,'sys_file_metadata',18,''),('10a7bb014e60de546e797f7094044501','sys_file',159,'metadata','','','',0,0,0,'sys_file_metadata',15,''),('10c3a229b5c9893ae0e7bd24a08f5ad7','tx_grevman_domain_model_registration',41,'member','','','',0,0,0,'fe_users',12,''),('10eb4b99b031d0573f02c64a2ada8c66','tx_grevman_domain_model_registration',78,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('11077d9fb1abb1ca90e19a1b155ca2ce','tx_grevman_domain_model_note',115,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('11214214cc083a43812fa31cd673c361','tx_grevman_domain_model_registration',150,'member','','','',0,1,0,'fe_users',10,''),('1201bbdfee6e7438b0e70b0e6c0dd75c','tx_grevman_domain_model_note',119,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('121a6c808c942c6d7e1de50413832ab2','tx_grevman_domain_model_registration',46,'member','','','',0,0,0,'fe_users',10,''),('1332d46bd3c46d208a1017fd87c4be8d','tx_grevman_domain_model_registration',78,'member','','','',0,0,0,'fe_users',10,''),('1344d5b56266eb74ae8c242398c7697f','tx_grevman_domain_model_event',25,'parent','','','',0,1,0,'tx_grevman_domain_model_event',1,''),('146db6f5663b20075b559932c553dee4','tx_grevman_domain_model_registration',74,'member','','','',0,0,0,'fe_users',10,''),('14c7f79e061623745e12e0b8effa18cf','tx_grevman_domain_model_registration',140,'member','','','',0,1,0,'fe_users',16,''),('14d056e016563d5548157579fc03b079','sys_file_reference',503,'uid_local','','','',0,1,0,'sys_file',163,''),('15546fc4fc36a1232a6e2fbbe3f49ac3','tx_grevman_domain_model_registration',147,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('158a16bbb686bd789a37eb8af3548a71','tx_grevman_domain_model_registration',104,'member','','','',0,1,0,'fe_users',16,''),('15ba8dcdf0d014a96f31c41182d73f9b','tx_grevman_domain_model_note',58,'member','','','',0,0,0,'fe_users',10,''),('15d53eb9f444210147600d4b285b3ddc','sys_file_reference',521,'uid_local','','','',0,1,0,'sys_file',162,''),('16a308550f3bdbfac8e002e2cff0404a','tx_grevman_domain_model_registration',49,'member','','','',0,0,0,'fe_users',12,''),('16ac2ba4b044f2d38558832e8e4d9918','sys_file_metadata',11,'file','','','',0,0,0,'sys_file',132,''),('16c09a560a4456ca49fbcdfc36b48f90','tt_content',1015,'pi_flexform','sDEF/lDEF/settings.pages/vDEF/','','',0,0,0,'pages',223,''),('17bc398816c85285b769fe63d931f0ef','tx_grevman_domain_model_note',35,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('17eee0cf8876c48eaba1fa5a00238c37','tx_grevman_domain_model_note',107,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('18224243638d17705ba5114ebe4f7dab','tx_grevman_domain_model_group',2,'members','','','',2,0,0,'fe_users',13,''),('187db2635d8d7c2674ebadb5ba478b13','tx_grevman_domain_model_registration',26,'member','','','',0,0,0,'fe_users',10,''),('18e21a6b9c1ef4ffc10c2c8a195ace27','sys_file',154,'storage','','','',0,0,0,'sys_file_storage',1,''),('1922cc1ca3e5000deb2db99b7a283f6d','tx_grevman_domain_model_registration',120,'member','','','',0,1,0,'fe_users',16,''),('1933ebe29b7c5feb598b63b18f645b37','tx_grevman_domain_model_note',114,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('19408c67592e0ad60f378eb52e124fd7','tx_grevman_domain_model_note',42,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('197ba8e83fb3c95a6c7b627c33d074ff','sys_file_reference',541,'uid_local','','','',0,1,0,'sys_file',163,''),('199b26e2cdb5ebab86e24618567c840b','tx_grevman_domain_model_registration',22,'member','','','',0,1,0,'fe_users',14,''),('19bb0db44652421a92f973534ca7ee79','tx_grevman_domain_model_registration',40,'member','','','',0,0,0,'fe_users',16,''),('19d9febdd400fe423b3b1801a82d9117','tx_grevman_domain_model_registration',38,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('1af27c2ca6bb6fb45bfd146b8a09d747','tx_grevman_domain_model_group',1,'members','','','',2,0,0,'fe_users',14,''),('1b085a7c529367e1071a726381b82690','tx_grevman_domain_model_note',130,'member','','','',0,1,0,'fe_users',10,''),('1b456968088e22ed5c6f0e7775117693','tx_grevman_domain_model_registration',66,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('1b79f49f6374bb21b2ab5b8cdb4d9340','tx_grevman_domain_model_note',99,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('1b9bd6d95b24a7ba0518efc5d9f965cc','tx_grevman_domain_model_note',26,'member','','','',0,0,0,'fe_users',10,''),('1bd319065740c8bb7d905b08746c8e2b','tx_grevman_domain_model_event',21,'member_groups','','','',0,1,0,'tx_grevman_domain_model_group',1,''),('1bd900b40a75ef40144706e261d299e9','tx_grevman_domain_model_registration',83,'member','','','',0,0,0,'fe_users',11,''),('1c6b3ffd36f17c70f12a4768a19549cc','sys_file',8,'storage','','','',0,0,0,'sys_file_storage',1,''),('1c7a42ef2d816f1bd3af56f3a582f42f','tx_grevman_domain_model_note',9,'member','','','',0,1,0,'fe_users',10,''),('1ca4ccf367fc3924948d0c2c02c75298','tx_grevman_domain_model_registration',33,'member','','','',0,0,0,'fe_users',12,''),('1cf2cfd73196f65aa244d1f1040de22b','tx_grevman_domain_model_registration',18,'member','','','',0,1,0,'fe_users',14,''),('1cfdd23f9f4e6e479ebab83fe681c9c5','sys_file',8,'metadata','','','',0,0,0,'sys_file_metadata',9,''),('1d8643261836802c9fff9d93d47c1627','fe_users',14,'usergroup','','','',0,0,0,'fe_groups',4,''),('1dc3e8f2cb26a3b2a28b95fc08c77c17','tx_grevman_domain_model_note',138,'member','','','',0,0,0,'fe_users',10,''),('1e00765c807cce257c55dff93a196e98','tx_grevman_domain_model_event',50,'notes','','','',1,0,0,'tx_grevman_domain_model_note',138,''),('1eaf167f8c61637bae304cc625b2d64e','tx_grevman_domain_model_note',83,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('1ec5365d617d0b116ad066269e9b151c','tx_grevman_domain_model_registration',103,'member','','','',0,1,0,'fe_users',11,''),('1f031648575212295cf434899520fbdb','tx_grevman_domain_model_note',24,'member','','','',0,0,0,'fe_users',10,''),('1f9e7f0b3698270be560e760c5788878','tx_grevman_domain_model_registration',130,'member','','','',0,1,0,'fe_users',10,''),('1fa0f04293aacee015b78ae96f4d4540','tx_grevman_domain_model_event',28,'parent','','','',0,1,0,'tx_grevman_domain_model_event',1,''),('1fa1b1ba30b431dfeed5f637f4990905','tx_grevman_domain_model_event',4,'member_groups','','','',0,1,0,'tx_grevman_domain_model_group',1,''),('1fd4e754f36b9919f1031104ee315930','tx_grevman_domain_model_registration',99,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('200ab7ddf0c13eef29e45d704d0f1aa6','tx_grevman_domain_model_note',121,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('210fca3c9eec51ac59e4aa82e161aa3c','tx_grevman_domain_model_event',24,'parent','','','',0,1,0,'tx_grevman_domain_model_event',1,''),('225c8a05dbc80f10afeb40a89de35c4a','tx_grevman_domain_model_note',109,'member','','','',0,1,0,'fe_users',10,''),('226251e9aaa7e362e7c62bc5eb79e48c','tx_grevman_domain_model_registration',56,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('22cc06ad269b284f4099bd7a829b3acc','tx_grevman_domain_model_registration',3,'member','','','',0,0,0,'fe_users',11,''),('230b1cb004649909d118ec2b70c29451','tx_grevman_domain_model_registration',44,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('230d5c05e019cc32a9bce2c451544521','tx_grevman_domain_model_note',77,'member','','','',0,1,0,'fe_users',10,''),('23c862bf54a6efacb70e686ea4421410','tx_grevman_domain_model_note',137,'member','','','',0,0,0,'fe_users',10,''),('23cc24fb18fccd3e582a96d73c7d3227','tx_grevman_domain_model_event',29,'parent','','','',0,1,0,'tx_grevman_domain_model_event',1,''),('23f93dd842fec168ec4cfe04c5327b71','tx_grevman_domain_model_note',134,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('245baff71810d602f8379a5c74351f89','tx_grevman_domain_model_note',130,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('246431cb36f0f2c8d625c22de8e4bee8','tx_grevman_domain_model_registration',12,'member','','','',0,1,0,'fe_users',10,''),('246485091f23f8a038c98cae0644f34f','tx_grevman_domain_model_registration',19,'event','','','',0,1,0,'tx_grevman_domain_model_event',35,''),('2489ad7ca55c62ee62c87cae77a2d6e2','tx_grevman_domain_model_note',103,'member','','','',0,1,0,'fe_users',10,''),('24d7760be204299e445ad17baf12fb7f','sys_file_reference',486,'uid_local','','','',0,1,0,'sys_file',163,''),('253a0fab4f82af1199c2055c2db030b4','tx_grevman_domain_model_note',45,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('255b110f9b675df3da69b199f8e8b08f','tx_grevman_domain_model_registration',50,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('25aaa792bf5bcab26c9c79824e4da674','tx_grevman_domain_model_note',85,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('26074ea8cd97389428c8df87814be68a','sys_file_reference',547,'uid_local','','','',0,1,0,'sys_file',162,''),('279c8d1c3d77bce25982bab3cf25a28a','tx_grevman_domain_model_registration',141,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('27e4a0a8e2092b1fee64e960b6d0fda2','tx_grevman_domain_model_note',95,'member','','','',0,1,0,'fe_users',10,''),('282d5ea219f8a0c2e8e21d1ab16a380c','sys_file',149,'storage','','','',0,0,0,'sys_file_storage',1,''),('285965ab86e00aeff16dd86fd12c121e','tx_grevman_domain_model_registration',55,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('29424eaffe4e892fe4000115d2b4d5d5','sys_file',157,'storage','','','',0,0,0,'sys_file_storage',1,''),('299d690bf3eaa29d9b868e5ca54964bd','tx_grevman_domain_model_registration',66,'member','','','',0,0,0,'fe_users',10,''),('29f3f0d39372a758c9a6c6813a2a030b','tx_grevman_domain_model_event',6,'parent','','','',0,1,0,'tx_grevman_domain_model_event',1,''),('2a9f248233fb050239297f92ec071149','tx_grevman_domain_model_registration',6,'member','','','',0,0,0,'fe_users',16,''),('2ae0cbb38a848cb96e5bfbea6d7b1d45','tx_grevman_domain_model_note',9,'event','','','',0,1,0,'tx_grevman_domain_model_event',19,''),('2b1b85e0920475605a32dadaa3b9759c','tx_grevman_domain_model_note',108,'member','','','',0,1,0,'fe_users',10,''),('2b1bade48da344f6944dfb6949aa6cc1','tx_grevman_domain_model_note',22,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('2bbd13199f44b328c6282176b436c2e2','tx_grevman_domain_model_note',80,'member','','','',0,1,0,'fe_users',10,''),('2bfa0bb667f6eca7a6ca2165bab270d1','tx_grevman_domain_model_note',65,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('2c3a7647e492de59bde01af5b511b743','tx_grevman_domain_model_note',52,'member','','','',0,0,0,'fe_users',10,''),('2c8810c1893547edd17702ee2d7d7b0f','tx_grevman_domain_model_note',45,'member','','','',0,0,0,'fe_users',10,''),('2d3ad36998d212271bd19badf3dfb222','tx_grevman_domain_model_note',49,'member','','','',0,0,0,'fe_users',10,''),('2daac50e1691c79a18b8533a7b490cc5','tx_grevman_domain_model_event',33,'member_groups','','','',0,1,0,'tx_grevman_domain_model_group',1,''),('2e6db2ac27a9866e826f0237554fb7e5','tx_grevman_domain_model_registration',86,'member','','','',0,1,0,'fe_users',10,''),('2ea0b1b0809bbe4576fa83bb71766a97','sys_file_reference',489,'uid_local','','','',0,1,0,'sys_file',162,''),('2edb1282bac3af3074c8221950f2421e','sys_file_reference',513,'uid_local','','','',0,1,0,'sys_file',162,''),('2f12f06980c0c73ba4f639b6488064c1','tx_grevman_domain_model_registration',73,'member','','','',0,0,0,'fe_users',12,''),('2fa3269422c678ad6defd541c13dd3fd','tx_grevman_domain_model_registration',116,'member','','','',0,1,0,'fe_users',16,''),('2fd742e028fe0ca0d14d236f6bbec820','tx_grevman_domain_model_note',5,'event','','','',0,0,0,'tx_grevman_domain_model_event',2,''),('2feaffdcfce12325ce3b3f50545423df','tx_grevman_domain_model_registration',68,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('3044f5c11dcf06962bfa4069f32a31bc','tx_grevman_domain_model_event',24,'member_groups','','','',0,1,0,'tx_grevman_domain_model_group',1,''),('30b2a154bf898b50591f5862b1a31639','tx_grevman_domain_model_note',86,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('31e180c6c83cc72a29d1be9649315851','tx_grevman_domain_model_note',13,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('31e3562b9df460a9409a5629cf4cbf37','tx_grevman_domain_model_note',30,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('3208a6fa4a5a9516a65658c466c4232a','tx_grevman_domain_model_note',119,'member','','','',0,1,0,'fe_users',10,''),('3228270b9cbfa79e60e65a5d05a5799e','tx_grevman_domain_model_registration',51,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('328a0912e4411c77538fdc1e437a56c6','sys_file_reference',532,'uid_local','','','',0,1,0,'sys_file',163,''),('32faf732d05d77f0a29e72ef104ad04f','tx_grevman_domain_model_note',71,'member','','','',0,0,0,'fe_users',10,''),('33671a0f884be4d79e5b53012ffcfd46','tx_grevman_domain_model_event',29,'member_groups','','','',0,1,0,'tx_grevman_domain_model_group',1,''),('33a12b35b2dc3fea411f8ba1f9b21350','tx_grevman_domain_model_registration',93,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('3466e50826e9c042e4c01c1b98c455ba','tx_grevman_domain_model_event',12,'parent','','','',0,1,0,'tx_grevman_domain_model_event',1,''),('349a7b0c3d729128ddca08899b2715a4','tx_grevman_domain_model_note',66,'member','','','',0,0,0,'fe_users',10,''),('3506538efc4df517b7f00b29f670d715','tx_grevman_domain_model_registration',142,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('35dce60d1458da74243a0317563144dd','tx_grevman_domain_model_note',41,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('360662dc552e36d6b91c7a6a50256814','sys_file_reference',495,'uid_local','','','',0,1,0,'sys_file',162,''),('367c38dbbb34b0fdc224df6ff3347f4c','tx_grevman_domain_model_registration',1,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('36e7a782f7625b89ffe4f47d781a20ab','tx_grevman_domain_model_event',19,'parent','','','',0,1,0,'tx_grevman_domain_model_event',18,''),('371b5a98f78946b0ee16d0db88628b5e','tx_grevman_domain_model_note',118,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('3730136e46b90c89adc7369bfa1bae43','sys_file_metadata',15,'file','','','',0,0,0,'sys_file',159,''),('379ec8aebf1f230f5d9647521ce87f83','tx_grevman_domain_model_event',22,'parent','','','',0,1,0,'tx_grevman_domain_model_event',1,''),('37cfef152835132aa022478f8b03c76b','sys_file',154,'metadata','','','',0,0,0,'sys_file_metadata',3,''),('385a5d1b2ca6478ca2174502bf3d7971','tx_grevman_domain_model_registration',124,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('386e5d5ffe7441979e9824e3542abc89','tx_grevman_domain_model_event',30,'member_groups','','','',0,1,0,'tx_grevman_domain_model_group',1,''),('3ab20f32a58746360c3f8b0f37b210b1','tx_grevman_domain_model_note',14,'member','','','',0,0,0,'fe_users',10,''),('3b6a1333a27c48d919d7b39f36294cc0','tx_grevman_domain_model_registration',115,'member','','','',0,1,0,'fe_users',11,''),('3b7789e75e4362f45adfaae3c3eb1d90','tx_grevman_domain_model_note',84,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('3b7dc95effd1cb1fc77b24d8413bd26f','sys_file_reference',505,'uid_local','','','',0,1,0,'sys_file',163,''),('3bd1c02113b3214e45c815084c4c1320','tx_grevman_domain_model_registration',58,'member','','','',0,0,0,'fe_users',10,''),('3be5741d8178dd1ad9614f77523abb7a','tx_grevman_domain_model_event',44,'member_groups','','','',0,1,0,'tx_grevman_domain_model_group',2,''),('3c33bc50ab422e2586ac3c3eef4585c6','tx_grevman_domain_model_note',6,'event','','','',0,1,0,'tx_grevman_domain_model_event',14,''),('3c46a93d288ca75fa49e45277af1a1bf','tx_grevman_domain_model_event',50,'registrations','','','',0,0,0,'tx_grevman_domain_model_registration',156,''),('3c5d8140e28a6537ab7c211e48ab38be','tx_grevman_domain_model_registration',105,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('3cbd27a11581da47cef48a3b8ab66e9d','tx_grevman_domain_model_note',49,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('3d56730523bff47f432dcfa673bd4503','tx_grevman_domain_model_event',40,'parent','','','',0,1,0,'tx_grevman_domain_model_event',1,''),('3d61cbf052ea1e048ab45bde3950c35a','tx_grevman_domain_model_registration',22,'event','','','',0,1,0,'tx_grevman_domain_model_event',38,''),('3d628dae63c0395357402c5234002a51','fe_users',10,'notes','','','',0,0,0,'tx_grevman_domain_model_note',139,''),('3e39f0a30c6b0d81ba50d334e07cf45a','tx_grevman_domain_model_note',131,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('3e4c6a72e6f0d67b6022a4cdb1cb026d','tx_grevman_domain_model_note',128,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('3f0338b68898aa3dc4a359a00e001ae0','sys_file',153,'storage','','','',0,0,0,'sys_file_storage',1,''),('401043c37c8c84d8f309b21f7c6f286f','tx_grevman_domain_model_registration',85,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('401c3487538168a22d05ffbbebb2bc0f','tx_grevman_domain_model_registration',114,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('408ebbd8f47d6ad419e00356d17c7958','fe_users',10,'registrations','','','',4,0,0,'tx_grevman_domain_model_registration',151,''),('40932308dbb7cd31c0a59536975c82ef','tx_grevman_domain_model_registration',42,'member','','','',0,0,0,'fe_users',10,''),('40ba282703381f1430952f5cbed93fbe','tx_grevman_domain_model_registration',145,'member','','','',0,1,0,'fe_users',12,''),('41364a10fe26f2876b51d29e8cf9b26d','tx_grevman_domain_model_event',8,'parent','','','',0,1,0,'tx_grevman_domain_model_event',1,''),('4152ef26b7a4214c2a7df623acda0207','tx_grevman_domain_model_note',78,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('41690ac51b6f092d266b3762bef8b07f','tx_grevman_domain_model_note',111,'member','','','',0,1,0,'fe_users',10,''),('41751e981264f4001f1f9a2bd65af89c','tx_grevman_domain_model_registration',144,'member','','','',0,1,0,'fe_users',16,''),('41ae1c25c48638c06aee530ab3f0e41d','tx_grevman_domain_model_event',6,'member_groups','','','',0,1,0,'tx_grevman_domain_model_group',1,''),('41b2cfdc407f04ec2021ba94ab39cc6b','tx_grevman_domain_model_registration',43,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('41ce7942571430b7d7848b91d0c33f80','tx_grevman_domain_model_registration',72,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('42613a1cf1261df39466d71c9070a116','tx_grevman_domain_model_note',44,'member','','','',0,0,0,'fe_users',10,''),('427ff376feaaae4daca84da3f8e09aaf','tx_grevman_domain_model_note',91,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('42a9e1e92a24ca38806ed6d3ba006842','tx_grevman_domain_model_note',125,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('42eea5ee669f74037d5f998bf2677ff7','tx_grevman_domain_model_registration',26,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('4305faf6ac49b77d4cae0f17a45bb389','tx_grevman_domain_model_registration',88,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('4330231d24bab66f9cda5e06e7c72fdf','fe_users',10,'registrations','','','',3,0,0,'tx_grevman_domain_model_registration',152,''),('438a66d73e3fcaa18e25f70c9c571f98','tx_grevman_domain_model_registration',19,'member','','','',0,1,0,'fe_users',14,''),('44266e5450e85248a31e1a333f86ae26','tx_grevman_domain_model_registration',65,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('445ac6f42877f78ea8b2e6bee5944bf5','tx_grevman_domain_model_note',123,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('447cb1db5991d4a11d4a61cef63bb03b','tx_grevman_domain_model_event',27,'parent','','','',0,1,0,'tx_grevman_domain_model_event',1,''),('452a683f5346ab246f1e4d9fe12922d4','tx_grevman_domain_model_note',82,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('453719297137906abdfbe0c9f547a4f1','tx_grevman_domain_model_registration',128,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('454c84eec0a8bc4656f48da79a2df7fb','tx_grevman_domain_model_registration',62,'member','','','',0,0,0,'fe_users',10,''),('45d715250857b6faf8ea8f3b56f82470','tx_grevman_domain_model_registration',146,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('464c304c91bd6358ae6958e2903ecf05','tx_grevman_domain_model_registration',149,'member','','','',0,1,0,'fe_users',12,''),('46d3a37f7ebc008a2ab14dd72ae6de22','tx_grevman_domain_model_note',82,'member','','','',0,1,0,'fe_users',10,''),('477228fee1dbf84365b062eea7ebbe25','tx_grevman_domain_model_registration',63,'member','','','',0,0,0,'fe_users',11,''),('4789c808b14fc1987003ccd3b777c02b','tx_grevman_domain_model_registration',77,'member','','','',0,0,0,'fe_users',12,''),('485d02e8f4efc3d8fee6cb198adae7e1','tx_grevman_domain_model_registration',113,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('485fa0b1229c6b2e5d3a181d7d311931','tx_grevman_domain_model_registration',125,'member','','','',0,1,0,'fe_users',12,''),('4898e764296619111e02978e95d7d1e7','tx_grevman_domain_model_registration',94,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('48b0ae8acf4afb9dbf78414b31d2dc08','tx_grevman_domain_model_note',12,'member','','','',0,0,0,'fe_users',10,''),('48f5ee1a4d2cc4df7588857d8977d95c','tx_grevman_domain_model_registration',139,'member','','','',0,1,0,'fe_users',11,''),('4942e835821b982c52e9cd3e11dd1835','tx_grevman_domain_model_note',74,'member','','','',0,1,0,'fe_users',10,''),('49975edc3bb8a298a26234c7373f6564','tx_grevman_domain_model_registration',45,'member','','','',0,0,0,'fe_users',12,''),('49f5b261c10ec452775ef504d417cc18','tx_grevman_domain_model_registration',5,'member','','','',0,0,0,'fe_users',13,''),('4a1c9dae77a2ec18b7d0f68ffc0555c2','sys_file_reference',491,'uid_local','','','',0,1,0,'sys_file',163,''),('4a251fd4de86b8cbd0e2e7ac47550128','sys_file',9,'metadata','','','',0,0,0,'sys_file_metadata',5,''),('4a6fbef5f291502a7ee0ec9f9c842428','tx_grevman_domain_model_registration',134,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('4a9b870d7f84b1414cbc703fd418c70d','tx_grevman_domain_model_note',60,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('4ac406cb7551a04c28db346233994fa7','tx_grevman_domain_model_event',32,'parent','','','',0,1,0,'tx_grevman_domain_model_event',1,''),('4b899fa2410b450825cdc6d035e9b4e4','tx_grevman_domain_model_event',16,'member_groups','','','',0,1,0,'tx_grevman_domain_model_group',1,''),('4bee5685bdd3ba46ee4314a7beb867a6','tx_grevman_domain_model_note',51,'member','','','',0,0,0,'fe_users',10,''),('4c1caae8d89a57f4fa07cc63018f4075','sys_file_metadata',5,'file','','','',0,0,0,'sys_file',9,''),('4c6874b9cb8d0cd2067a3a5187e4b7cb','tx_grevman_domain_model_note',46,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('4c7c08533e856a6a524f70ff4e82e915','sys_file',156,'metadata','','','',0,0,0,'sys_file_metadata',8,''),('4c881f741e5e844aacddcf9ddc374de4','tx_grevman_domain_model_event',35,'member_groups','','','',0,1,0,'tx_grevman_domain_model_group',1,''),('4d67f25cfaa9af47b27221baabdb23dd','tx_grevman_domain_model_note',51,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('4dc8d22cc39fb8ef1d12f5ce2bc85c1d','tx_grevman_domain_model_registration',21,'event','','','',0,1,0,'tx_grevman_domain_model_event',37,''),('4e588eb3437d922d3535d1ea547e7238','tx_grevman_domain_model_registration',148,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('4e7cdaeb7a456706cf38440588d1a5ac','sys_file_reference',536,'uid_local','','','',0,1,0,'sys_file',163,''),('4ea0455268cf2d0204a3333e12520b6a','tx_grevman_domain_model_registration',11,'member','','','',0,1,0,'fe_users',10,''),('4eadcf28bed1248eb21c6f8c1dd4e8b8','tx_grevman_domain_model_registration',118,'member','','','',0,1,0,'fe_users',10,''),('4ec01bcf3a347fdc1fd830329dbde707','tx_grevman_domain_model_note',16,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('4fb00e24c9b27cf64cac4523cd83b64e','tx_grevman_domain_model_registration',133,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('4fe95bbb0bf4cd805e57fc82316405c5','tx_grevman_domain_model_registration',46,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('4ff62ca627fc663b9993a4f2ac04429e','tx_grevman_domain_model_registration',32,'member','','','',0,0,0,'fe_users',16,''),('5019aa2406d727cb2e896824b418286b','tx_grevman_domain_model_note',61,'member','','','',0,0,0,'fe_users',10,''),('510c9731e40d3d260ef34d568569d9b1','tx_grevman_domain_model_note',53,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('512b9a63017e9e77df946bd90d72bf0a','sys_file_reference',492,'uid_local','','','',0,1,0,'sys_file',163,''),('514349fa13736590cfd132f06ac3df56','tx_grevman_domain_model_note',28,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('51501ee0eec5de818d84e08a1bc23761','tx_grevman_domain_model_registration',54,'member','','','',0,0,0,'fe_users',10,''),('5176e2db5d6ee2bc2c222bcf118e977b','sys_file',149,'metadata','','','',0,0,0,'sys_file_metadata',1,''),('5191ed9caaf4e4badd95d79adcfc3cad','tx_grevman_domain_model_registration',70,'member','','','',0,0,0,'fe_users',10,''),('5198713510aa12ae454a17ac906d0cb6','sys_file_reference',479,'uid_local','','','',0,1,0,'sys_file',162,''),('51cf15fb84e8a986d167eed0171433b0','tx_grevman_domain_model_note',97,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('52210260df0e1be709de3d6bd0f04794','tx_grevman_domain_model_registration',82,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('52dd115c7993e29504d7d11df7bb0d2f','tx_grevman_domain_model_registration',85,'member','','','',0,0,0,'fe_users',12,''),('53062df53b877824ea23b81d44273786','tx_grevman_domain_model_event',31,'parent','','','',0,1,0,'tx_grevman_domain_model_event',1,''),('533df6a7c6ca585cc2f9f24ec1bcfc9c','tx_grevman_domain_model_registration',2,'member','','','',0,0,0,'fe_users',11,''),('53534cd6f6bacf264153265bab3c631f','tx_grevman_domain_model_registration',3,'event','','','',0,0,0,'tx_grevman_domain_model_event',2,''),('53e01f6e5c35c359f3d5949c5dd7451a','tx_grevman_domain_model_registration',64,'member','','','',0,0,0,'fe_users',16,''),('5458d201d0a0e552edea864391fed3fd','sys_file_reference',472,'uid_local','','','',0,1,0,'sys_file',162,''),('548e5013d48ac51cdfc810cd5794a188','tx_grevman_domain_model_registration',76,'member','','','',0,0,0,'fe_users',16,''),('54dc5fa6d5c6df603c7ce52bfc35eb98','tx_grevman_domain_model_note',135,'member','','','',0,1,0,'fe_users',10,''),('54e9377f75305b0898639706cb0d92dc','tx_grevman_domain_model_event',37,'parent','','','',0,1,0,'tx_grevman_domain_model_event',1,''),('55dbf0c7a45ba63aeec16d752121a007','sys_file_reference',493,'uid_local','','','',0,1,0,'sys_file',163,''),('5611e917c094fb6854602a5ba2cafe14','tx_grevman_domain_model_note',133,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('56247186f9f28bf598e1a4405ead5f77','sys_file',132,'storage','','','',0,0,0,'sys_file_storage',1,''),('5634ae816964e2279f3609430ee1324d','tx_grevman_domain_model_registration',97,'member','','','',0,1,0,'fe_users',12,''),('56ae7deeac92beb0e79ce6d57d5bb360','tx_grevman_domain_model_registration',116,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('56b7d9296369d0e9fb200a89ecef8cd2','sys_file',156,'storage','','','',0,0,0,'sys_file_storage',1,''),('56bd13ec071c3007a20cc12d7059e2d1','tx_grevman_domain_model_registration',135,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('56cf16045ddd1dd46c4296003dfe8f3b','tx_grevman_domain_model_note',23,'member','','','',0,0,0,'fe_users',10,''),('570b5e9896c6c97ef83c78652b039e9a','tx_grevman_domain_model_event',10,'parent','','','',0,1,0,'tx_grevman_domain_model_event',1,''),('57c8e0adce4ade6f147a77485d270fc6','tx_grevman_domain_model_registration',13,'event','','','',0,1,0,'tx_grevman_domain_model_event',21,''),('585e5f148115d86b84f55effad6ff92c','tx_grevman_domain_model_group',1,'members','','','',0,0,0,'fe_users',10,''),('586f6541921e18e89e699b25754f4518','sys_file_reference',507,'uid_local','','','',0,1,0,'sys_file',163,''),('58ff3fbece6fb3f5231ce06da504f70f','tx_grevman_domain_model_note',3,'member','','','',0,0,0,'fe_users',10,''),('594eadc0de3337b45e986eb063c0b1be','tx_grevman_domain_model_registration',75,'member','','','',0,0,0,'fe_users',11,''),('59d7ee4f41eba385471b7ae90e7f1021','tx_grevman_domain_model_note',75,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('59ea212c003d81d1c6886d8ee62b5a2b','tx_grevman_domain_model_registration',38,'member','','','',0,0,0,'fe_users',10,''),('59f531e61ca798329fbac25e09f35f02','tx_grevman_domain_model_registration',91,'member','','','',0,1,0,'fe_users',11,''),('5a3cda953a7c01b36f732e63d8ec7162','tx_grevman_domain_model_note',18,'member','','','',0,0,0,'fe_users',10,''),('5af62d064adf2d8118a323d4b809d1ff','sys_file_reference',487,'uid_local','','','',0,1,0,'sys_file',162,''),('5b1ec3cf7693eda0c4130a7f966e3f6a','tx_grevman_domain_model_note',7,'event','','','',0,1,0,'tx_grevman_domain_model_event',15,''),('5b6c9ae9ae8102997d94c6ea1fe67313','sys_file_reference',538,'uid_local','','','',0,1,0,'sys_file',163,''),('5b881762b986130165828828c4621b74','tx_grevman_domain_model_registration',6,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('5ba335bdb3c6fd4b52e558573ff66355','tx_grevman_domain_model_note',54,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('5c422f23adc530a5885d00758af7f904','sys_file',158,'metadata','','','',0,0,0,'sys_file_metadata',14,''),('5c6bce7f838a1449920f3dcaaa5c1f4c','tx_grevman_domain_model_registration',52,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('5cd15b1ea56b811afcf855ab77ef0ffd','tx_grevman_domain_model_note',76,'member','','','',0,1,0,'fe_users',10,''),('5d5649b45e0d0824c7346135842eceb5','tx_grevman_domain_model_note',122,'member','','','',0,1,0,'fe_users',10,''),('5d5eb46bc6cbce0db8341c11c73b59ae','tx_grevman_domain_model_note',48,'member','','','',0,0,0,'fe_users',10,''),('5d649eb9f201b48fd3ec188a9653fbc7','tx_grevman_domain_model_note',124,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('5e188713e20924ed4f668a013fd4acdf','tx_grevman_domain_model_event',36,'parent','','','',0,1,0,'tx_grevman_domain_model_event',1,''),('5e3843ff70bc14eb20c2657dfc802bd6','tx_grevman_domain_model_registration',29,'member','','','',0,0,0,'fe_users',12,''),('5ea8f5d30af7c3571bb2042e03a3a647','sys_file',163,'metadata','','','',0,0,0,'sys_file_metadata',19,''),('5f1ce987b177d42512e84272746d4c44','tx_grevman_domain_model_registration',17,'member','','','',0,1,0,'fe_users',14,''),('5f3e11ce5e94a5a93f2458cf87a3c567','tx_grevman_domain_model_event',40,'member_groups','','','',0,1,0,'tx_grevman_domain_model_group',1,''),('5f49fd9279fc1428e41b80c8e5f52a12','sys_file_reference',527,'uid_local','','','',0,1,0,'sys_file',163,''),('5f52e0b744901238124662e86644b882','sys_file_reference',490,'uid_local','','','',0,1,0,'sys_file',162,''),('5f6bd9f9566a2a25d8c113a00c371e23','tx_grevman_domain_model_registration',114,'member','','','',0,1,0,'fe_users',10,''),('5f96007970de0975234f532e9e5effee','tx_grevman_domain_model_registration',65,'member','','','',0,0,0,'fe_users',12,''),('5f997d606d135fa7175fc0bafccd35fc','tx_grevman_domain_model_registration',73,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('5fd8f2edec8f5417f15263e00cef0e30','tx_grevman_domain_model_event',45,'member_groups','','','',0,1,0,'tx_grevman_domain_model_group',1,''),('5ff9fbc762d94153c1c5383381c8adba','tx_grevman_domain_model_note',97,'member','','','',0,1,0,'fe_users',10,''),('6059ccb99d29f2b09fd675d4ee26de9c','tx_grevman_domain_model_event',18,'member_groups','','','',0,1,0,'tx_grevman_domain_model_group',1,''),('606f1c4fdf4a389fca649caba815e452','tx_grevman_domain_model_note',2,'member','','','',0,0,0,'fe_users',10,''),('606f2cc25e7f6dbb84eeefc31cacedcd','tx_grevman_domain_model_note',1,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('60714570d47a2a7cc728c93bcfb0f236','tx_grevman_domain_model_registration',58,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('608413f7af4cd2e2511ff94733dbdd9a','tx_grevman_domain_model_registration',144,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('60a50a17d03f17b5f9ba30d93fd81b6a','tx_grevman_domain_model_registration',4,'event','','','',0,0,0,'tx_grevman_domain_model_event',2,''),('612b03c569e104be2862c07993a15750','tx_grevman_domain_model_note',33,'member','','','',0,0,0,'fe_users',10,''),('618ee0cb5e9699e41b5e141589f7b1a1','tx_grevman_domain_model_registration',27,'member','','','',0,0,0,'fe_users',11,''),('61d6210fc65532b16750038e81df1ead','tx_grevman_domain_model_note',63,'member','','','',0,0,0,'fe_users',10,''),('6212557831d8138f41e85de4afa2bbb8','tx_grevman_domain_model_note',135,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('62169d8155501a0fb39af35f19bf3221','fe_users',11,'registrations','','','',0,0,0,'tx_grevman_domain_model_registration',155,''),('621ddc74c9a6e1a861c566a8ce981b61','tx_grevman_domain_model_registration',95,'member','','','',0,1,0,'fe_users',11,''),('6224a973139b5d261268be4c1451ee4a','tx_grevman_domain_model_note',67,'member','','','',0,0,0,'fe_users',10,''),('6258fba316c3aaeeb7c7a82bd2c4676e','tx_grevman_domain_model_note',72,'member','','','',0,1,0,'fe_users',10,''),('628bd9127271bd67f77b491001e57912','tx_grevman_domain_model_event',14,'member_groups','','','',0,1,0,'tx_grevman_domain_model_group',1,''),('634f84b0c76b13058930c999f3badcb6','sys_file_reference',514,'uid_local','','','',0,1,0,'sys_file',162,''),('6428b55d98ae893e7e386fb51120b410','sys_file',158,'storage','','','',0,0,0,'sys_file_storage',1,''),('647f93aa95ad05ac83dde8614348a03a','tx_grevman_domain_model_registration',61,'member','','','',0,0,0,'fe_users',12,''),('64f04d2820c99349129c0ce55b66b3a5','fe_users',16,'usergroup','','','',0,0,0,'fe_groups',3,''),('650abdc80092edef3786e1136a2ef26d','sys_file_reference',478,'uid_local','','','',0,1,0,'sys_file',163,''),('656e955984ccc3b195f242f0e09c20f7','tx_grevman_domain_model_note',38,'member','','','',0,0,0,'fe_users',10,''),('65891b1f0b32a1cfae34fd842090e8f6','sys_file_reference',537,'uid_local','','','',0,1,0,'sys_file',163,''),('65a949fed4b4b0b9e5b7f8834cb8ab28','tx_grevman_domain_model_registration',30,'member','','','',0,0,0,'fe_users',10,''),('65bbe4e7932d2f980d81778c82c638e8','tx_grevman_domain_model_event',36,'member_groups','','','',0,1,0,'tx_grevman_domain_model_group',1,''),('66012c365a1a75de88bd0ec9b0223f33','tx_grevman_domain_model_registration',67,'member','','','',0,0,0,'fe_users',11,''),('660c92409dd6d740b49c3c50a0a38344','tx_grevman_domain_model_event',23,'member_groups','','','',0,1,0,'tx_grevman_domain_model_group',1,''),('6769ad4ca54979b718b155198972bef2','tx_grevman_domain_model_registration',154,'member','','','',0,0,0,'fe_users',10,''),('679254e927c5a4ab8bb3c82c2ec3adc7','tx_grevman_domain_model_note',73,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('67a3cbfaf4244c0d8fdd121c2421bf2e','tx_grevman_domain_model_event',33,'parent','','','',0,1,0,'tx_grevman_domain_model_event',1,''),('67baa543112ef665fa9c1a9eb06a7b7a','tx_grevman_domain_model_registration',139,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('687221753fe9c490bd65fade4fc78894','tx_grevman_domain_model_note',42,'member','','','',0,0,0,'fe_users',10,''),('68881d98f12941a3921abec72791851c','tx_grevman_domain_model_registration',101,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('68d848f3c186ab708f4c89d64ab90af6','sys_file_reference',482,'uid_local','','','',0,1,0,'sys_file',163,''),('68f4cb3a39daaf0fba17df74ab49dbee','tx_grevman_domain_model_registration',10,'event','','','',0,1,0,'tx_grevman_domain_model_event',17,''),('6931a823f985a3a6c1163ed3492743d1','sys_file_metadata',9,'file','','','',0,0,0,'sys_file',8,''),('69ad08545d29b018244879765e26b3bd','tx_grevman_domain_model_note',139,'member','','','',0,0,0,'fe_users',10,''),('69d8f21375cbeeb24b4ee0bf5599c537','tx_grevman_domain_model_note',53,'member','','','',0,0,0,'fe_users',10,''),('6a36beed9ff784b7aafdaa581f2fe6d3','sys_file_metadata',8,'file','','','',0,0,0,'sys_file',156,''),('6a398aa587a373e5023913b88beace02','tx_grevman_domain_model_registration',111,'member','','','',0,1,0,'fe_users',11,''),('6a3c718aeb95e7e20101255306691d2b','tx_grevman_domain_model_note',73,'member','','','',0,1,0,'fe_users',10,''),('6a81fbb43e48220d38693fcc874db30a','tx_grevman_domain_model_registration',154,'event','','','',0,0,0,'tx_grevman_domain_model_event',49,''),('6b17afb271d9d171d81e1fdf6ba48957','tx_grevman_domain_model_note',20,'member','','','',0,0,0,'fe_users',10,''),('6b7c60afe7826c470382ce37306eb093','tx_grevman_domain_model_registration',59,'member','','','',0,0,0,'fe_users',11,''),('6b7f6cdb59e9e7bd22a0e7b658f90f74','tx_grevman_domain_model_registration',31,'member','','','',0,0,0,'fe_users',11,''),('6b8386587d9bc27cc21a0363a88a497f','tx_grevman_domain_model_registration',33,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('6cdcba90faee695e63fd8b0636b7cff2','tx_grevman_domain_model_registration',92,'member','','','',0,1,0,'fe_users',16,''),('6d1c00e8aea11b7d052dccfca856f220','tx_grevman_domain_model_note',81,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('6df33850e7c8f2060c8e5872f70607d5','tx_grevman_domain_model_registration',122,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('6e14bc3f29eb0f54d2625384a09e4fe2','tx_grevman_domain_model_registration',7,'event','','','',0,0,0,'tx_grevman_domain_model_event',2,''),('6e42b42fa248d8865288179f62acdaa9','tx_grevman_domain_model_note',29,'member','','','',0,0,0,'fe_users',10,''),('6e959b8856bae39a60e53c9807920bbc','tx_grevman_domain_model_event',39,'member_groups','','','',0,1,0,'tx_grevman_domain_model_group',1,''),('6fa3570e9a75d35e3f67208a0bcd6789','tx_grevman_domain_model_registration',122,'member','','','',0,1,0,'fe_users',10,''),('7002db1b4b45bdfceb79a69c2197e495','sys_file_reference',535,'uid_local','','','',0,1,0,'sys_file',163,''),('708d2f41d8779666e47162c2c8762a05','tx_grevman_domain_model_event',34,'parent','','','',0,1,0,'tx_grevman_domain_model_event',1,''),('7189dfd77e2c44cc01003c68ec1d3012','tx_grevman_domain_model_note',127,'member','','','',0,1,0,'fe_users',10,''),('71ac3322b199dbf715b29c84ae5dc1ed','tx_grevman_domain_model_note',139,'event','','','',0,0,0,'tx_grevman_domain_model_event',50,''),('71b1945b6a6d9635488ea5c01a4ef768','tx_grevman_domain_model_note',106,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('71bcd167f31cabbcb3dc0401e2993a1c','tx_grevman_domain_model_note',124,'member','','','',0,1,0,'fe_users',10,''),('71e302c58198ba558818e5e5e04eb0d8','tx_grevman_domain_model_registration',42,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('71e3ae93b49897179ed86a43fd90a3d4','tx_grevman_domain_model_registration',131,'member','','','',0,1,0,'fe_users',11,''),('71fbfedc9f9bd8eec01c5e8f516dbba5','fe_users',12,'usergroup','','','',0,0,0,'fe_groups',3,''),('722e6c7a4e7b0c44098cd7f7ecb55fe5','sys_file_reference',512,'uid_local','','','',0,1,0,'sys_file',162,''),('72e9156e88f8b15a9d0ccc96b1913783','tx_grevman_domain_model_event',4,'parent','','','',0,1,0,'tx_grevman_domain_model_event',1,''),('7380dc4caa1b67b99c18cc7f2f5c0438','tx_grevman_domain_model_note',120,'member','','','',0,1,0,'fe_users',10,''),('73a3c40581c903ac6f4998e1507946a4','sys_file_reference',528,'uid_local','','','',0,1,0,'sys_file',163,''),('73c3d7a0de73a900e8779096cc720953','tx_grevman_domain_model_registration',95,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('741ce1cecbf2cb9d65b89ca2ebad5337','tx_grevman_domain_model_registration',20,'event','','','',0,1,0,'tx_grevman_domain_model_event',36,''),('74232e43786d98a976ce30e058ac11fe','tx_grevman_domain_model_event',2,'member_groups','','','',0,0,0,'tx_grevman_domain_model_group',2,''),('7486b40880983d9ea4693924e733cab0','tx_grevman_domain_model_note',64,'member','','','',0,0,0,'fe_users',10,''),('748b935d57b5e8c55ee60052fc53e04d','tx_grevman_domain_model_note',38,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('75437711c6eff21c6c23edfbf494b454','tx_grevman_domain_model_note',92,'member','','','',0,1,0,'fe_users',10,''),('75f13ef0aea052a5b47c6cc6f544682a','tx_grevman_domain_model_registration',60,'member','','','',0,0,0,'fe_users',16,''),('75f99662d71a0176e7d7fdbe29787da5','tx_grevman_domain_model_registration',47,'member','','','',0,0,0,'fe_users',11,''),('76016ebdeda14b0d807838e33090733c','tx_grevman_domain_model_note',88,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('762903d992782e8244afb535af62e588','tx_grevman_domain_model_note',101,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('76af8b9755f272d7a8e25e332d71a4eb','tx_grevman_domain_model_note',117,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('76e65018efb57ea7522120f3ee3bb4a5','tx_grevman_domain_model_note',48,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('7732cfc8317eb320a8675ea2cfcf6698','tx_grevman_domain_model_event',38,'parent','','','',0,1,0,'tx_grevman_domain_model_event',1,''),('7738d708ebfe7a30eb866463586c9a7d','sys_file_reference',504,'uid_local','','','',0,1,0,'sys_file',163,''),('77c0abc3d6da2def20cb6a0118acf670','sys_file_reference',516,'uid_local','','','',0,1,0,'sys_file',162,''),('77df84c9e1e743e2b014e2be6a45f9b1','tx_grevman_domain_model_registration',149,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('7870d6edd8ecdf5a6ffcc5ae0f2c0561','tx_grevman_domain_model_registration',108,'member','','','',0,1,0,'fe_users',16,''),('7a375f7d025c76ace075e241c351179b','tx_grevman_domain_model_registration',48,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('7a5e1fe923459e1a266fba8252555e84','tx_grevman_domain_model_note',66,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('7a8b9703aba2a27b1004f3c496f097ca','tx_grevman_domain_model_note',86,'member','','','',0,1,0,'fe_users',10,''),('7b0b03af6999700ba0ae9fd494298f8b','tx_grevman_domain_model_note',15,'member','','','',0,0,0,'fe_users',10,''),('7b1085dbd0154fc5e8ff1684a039d549','tx_grevman_domain_model_note',79,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('7b152eaecd9a8f000262aea5804f7330','tx_grevman_domain_model_event',21,'parent','','','',0,1,0,'tx_grevman_domain_model_event',1,''),('7b5be4771ca5bf3e23c82a785925c74e','tx_grevman_domain_model_note',18,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('7baa1bbd844d48d14703a73136f48ed9','tx_grevman_domain_model_note',26,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('7be1ef0fd66ed19ce221f055b193a8bb','tx_grevman_domain_model_registration',102,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('7bfca2e28b49f247001278110fd3a390','tx_grevman_domain_model_registration',15,'event','','','',0,1,0,'tx_grevman_domain_model_event',25,''),('7dce9984fd1547b6c5efaa46476a3405','tx_grevman_domain_model_note',105,'member','','','',0,1,0,'fe_users',10,''),('7e0d01c3a3885a55a374d236dc7b51a8','tx_grevman_domain_model_registration',86,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('7ea2d7872244fce30b7de3257627f0fa','tx_grevman_domain_model_note',32,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('7f2c753c578ef3c4048d05bde9083a9c','tx_grevman_domain_model_note',108,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('7f57eb3565315220ab1b4d2c85a262be','tx_grevman_domain_model_registration',1,'member','','','',0,0,0,'fe_users',10,''),('7f8dc52256660059f72b8a60331fd097','tx_grevman_domain_model_note',80,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('800ad6945546f9d38a247b98f60ce01b','tx_grevman_domain_model_registration',89,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('80188c15e038dfdf58015d86036810cd','tx_grevman_domain_model_note',41,'member','','','',0,0,0,'fe_users',10,''),('801cf9373a8cf35715a4395c55c7e177','tx_grevman_domain_model_note',77,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('80384b425010bd6b67d67c06e714bc9e','tx_grevman_domain_model_registration',21,'member','','','',0,1,0,'fe_users',14,''),('807bd1c894c3f47ec9b05c82ebfbeff6','tx_grevman_domain_model_note',113,'member','','','',0,1,0,'fe_users',10,''),('814bd22a24f71b0ffc35ac18afa3fad8','tx_grevman_domain_model_note',85,'member','','','',0,1,0,'fe_users',10,''),('815194c2c2147bbe40fa401073cc7f06','tx_grevman_domain_model_note',57,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('81627a3e5a962f061f2935aad0452bb3','sys_file_reference',534,'uid_local','','','',0,1,0,'sys_file',163,''),('819cda29ded0cc5c4bb07b0f2b662ffd','tx_grevman_domain_model_note',21,'member','','','',0,0,0,'fe_users',10,''),('81a2a707f063318de7a189869fcb6c5e','sys_file_reference',542,'uid_local','','','',0,1,0,'sys_file',163,''),('81b331d01b67a6625855086b0fe8c07b','tx_grevman_domain_model_registration',150,'event','','','',0,1,0,'tx_grevman_domain_model_event',45,''),('81bcd44042c4cd2c3ff749f0b527a649','tx_grevman_domain_model_registration',9,'member','','','',0,0,0,'fe_users',12,''),('8282cf2c86c18b73a83f232bc4fe8e5e','tx_grevman_domain_model_registration',84,'member','','','',0,0,0,'fe_users',16,''),('82e9ae4ac89d4bcda913056d9b45c624','tx_grevman_domain_model_registration',107,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('835caa3fc6dc012f235e1e1dbbc6154c','tx_grevman_domain_model_registration',136,'member','','','',0,1,0,'fe_users',16,''),('83ac951d8c25be6a8758d738d874a1ee','sys_file',10,'storage','','','',0,0,0,'sys_file_storage',1,''),('83b402cb8f3618729a8a67d7e6d90370','tx_grevman_domain_model_note',43,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('8420de0eb68a93ce2539725f4936ec81','tx_grevman_domain_model_note',68,'member','','','',0,0,0,'fe_users',10,''),('842da01c3a4b0ce0270152bde5d0930a','sys_file',131,'storage','','','',0,0,0,'sys_file_storage',1,''),('8430f6110b89565fcb69869d8b3f572c','tx_grevman_domain_model_registration',50,'member','','','',0,0,0,'fe_users',10,''),('849fa823dc98f6f9bb05eaa2404cc6cb','sys_file_reference',529,'uid_local','','','',0,1,0,'sys_file',163,''),('84b716202c5ae3ad4ab58883437b9930','tx_grevman_domain_model_event',42,'member_groups','','','',0,1,0,'tx_grevman_domain_model_group',1,''),('8522e237ae16c2cb7cd6a5e9700c0db9','sys_file',159,'storage','','','',0,0,0,'sys_file_storage',1,''),('854484f5d60f0b7ff061f7f48b0c4121','sys_file_reference',502,'uid_local','','','',0,0,0,'sys_file',162,''),('85852137d6f1ff85b4fcaa47cd757b04','fe_users',10,'usergroup','','','',0,0,0,'fe_groups',3,''),('85ef14281dcb4efa6c0f889dc3aa325d','sys_file_reference',469,'uid_local','','','',0,1,0,'sys_file',153,''),('8608d8699880b6b3fb2866f3d7431880','tx_grevman_domain_model_note',64,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('86728a96055c40ce3b9d36733a485da8','tx_grevman_domain_model_registration',52,'member','','','',0,0,0,'fe_users',16,''),('86fae4c8859a496930df6f342eb6bf6a','tx_grevman_domain_model_note',31,'member','','','',0,0,0,'fe_users',10,''),('874abf0db6130b0e4d1e6a60fe9a00f4','tx_grevman_domain_model_event',20,'parent','','','',0,1,0,'tx_grevman_domain_model_event',1,''),('877ea7420ebcc637534b43b8c8df8cf1','fe_users',10,'registrations','','','',2,0,0,'tx_grevman_domain_model_registration',153,''),('87a43d56edeac9ebeac61f3f0bd5e3c8','tx_grevman_domain_model_registration',17,'event','','','',0,1,0,'tx_grevman_domain_model_event',28,''),('87b2baf94b0e8cbe69f899b43a26e0b0','tx_grevman_domain_model_note',112,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('881603099f6ba00c08bbb7dad33139c5','tx_grevman_domain_model_registration',138,'member','','','',0,1,0,'fe_users',10,''),('888ca44f2993ee3eb0424092091803d6','tx_grevman_domain_model_registration',44,'member','','','',0,0,0,'fe_users',16,''),('88a58a2fe9dd966833ee38a2c5cf30cb','tx_grevman_domain_model_note',120,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('88bf9dfa6fcf8c230cc8dc880376b5e9','sys_file_reference',498,'uid_local','','','',0,1,0,'sys_file',162,''),('88c2f9fc3c72b32f3082c127f5c10205','tx_grevman_domain_model_note',98,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('893e20b39f66903f90c681e8c41b6297','sys_file',3,'storage','','','',0,0,0,'sys_file_storage',1,''),('897cf8bc5cfb201528ce7a6b8021a9d2','tx_grevman_domain_model_note',21,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('89cb920418de4c3fda2f7337d89b1f4c','tx_grevman_domain_model_registration',103,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('8a67dea5247f1ac6af58fcaa78a82576','sys_file_metadata',12,'file','','','',0,0,0,'sys_file',133,''),('8a6bc5e37952f3015e6bf4e23446a501','tx_grevman_domain_model_note',134,'member','','','',0,1,0,'fe_users',10,''),('8be062684363cf7a350505af22024d3e','tx_grevman_domain_model_note',89,'member','','','',0,1,0,'fe_users',10,''),('8c7315ae04d851cca2785c32117a8476','tx_grevman_domain_model_registration',25,'member','','','',0,1,0,'fe_users',14,''),('8c7ff67f0bfe1177e90824dc53baa675','tx_grevman_domain_model_event',50,'registrations','','','',1,0,0,'tx_grevman_domain_model_registration',157,''),('8c955a7567fc90c5e24f8b260936c657','tx_grevman_domain_model_note',96,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('8d02866c2d5ec045597fa399d85c6502','tx_grevman_domain_model_registration',24,'event','','','',0,1,0,'tx_grevman_domain_model_event',40,''),('8d3367b3de4c06f46383e05b03a7490e','tx_grevman_domain_model_note',13,'member','','','',0,0,0,'fe_users',10,''),('8d57b28636a652b6c4ff764e877166e6','tx_grevman_domain_model_note',33,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('8d6298c9fd3c1940a0ae9beedd567158','tx_grevman_domain_model_note',94,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('8d86689aa761f9da5ce7abaab0cceebd','tx_grevman_domain_model_registration',75,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('8d9be70040dd2d6c15505131d6f0ff14','tx_grevman_domain_model_registration',28,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('8dd486d96619f4c7954ba991d28df1c3','sys_file_reference',543,'uid_local','','','',0,1,0,'sys_file',162,''),('8ded86b84e9be4deaada713f64f2c160','tx_grevman_domain_model_registration',136,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('8e422965a26e326eaeb517d5bf5d1c23','tx_grevman_domain_model_registration',14,'event','','','',0,1,0,'tx_grevman_domain_model_event',24,''),('8e6bd7929b7355cfeb77757fa6c927ce','tx_grevman_domain_model_registration',146,'member','','','',0,1,0,'fe_users',10,''),('8e95b5bb6d1224bb944877167337c2f6','tx_grevman_domain_model_note',127,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('8ebfaae715150dde218f2c5b827087a6','tx_grevman_domain_model_event',22,'member_groups','','','',0,1,0,'tx_grevman_domain_model_group',1,''),('8f1632579d5f903ec7db8e59692e5f36','tx_grevman_domain_model_registration',106,'member','','','',0,1,0,'fe_users',10,''),('8f2f68071263ca397659fcfeb69798d8','tx_grevman_domain_model_registration',39,'member','','','',0,0,0,'fe_users',11,''),('8f480479666e0a9da377f8bf326b3e9d','tx_grevman_domain_model_note',88,'member','','','',0,1,0,'fe_users',10,''),('8f88b3be3b70c00da233792679f87d61','tx_grevman_domain_model_note',106,'member','','','',0,1,0,'fe_users',10,''),('8fdecac2daaec08542e5154329f23d59','sys_file_reference',473,'uid_local','','','',0,1,0,'sys_file',162,''),('8fe4cbf425ee89b2b0db180abceb91d5','tx_grevman_domain_model_event',12,'member_groups','','','',0,1,0,'tx_grevman_domain_model_group',1,''),('9089613c8cb768e561c5dac2fe4685d3','tx_grevman_domain_model_note',100,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('91403eb7039acc684f5b77750673ae99','tx_grevman_domain_model_note',60,'member','','','',0,0,0,'fe_users',10,''),('91730e14bb22d28c591a848e928ea3d1','tx_grevman_domain_model_registration',138,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('9215c54f19a7a6304591b36d91c37cef','tx_grevman_domain_model_registration',16,'event','','','',0,1,0,'tx_grevman_domain_model_event',26,''),('92177f100529295c4cbe185d4e12f65c','tx_grevman_domain_model_note',11,'member','','','',0,1,0,'fe_users',14,''),('930fba739ced97ed21a1d84848605302','tx_grevman_domain_model_registration',90,'member','','','',0,1,0,'fe_users',10,''),('935bf56f19abf10263af333b23fb7e78','sys_file_metadata',7,'file','','','',0,0,0,'sys_file',134,''),('93cc2aaac94d3fb000559419765168cb','tx_grevman_domain_model_registration',156,'member','','','',0,0,0,'fe_users',10,''),('941f214c5864de594f06366c0e399187','sys_file_reference',526,'uid_local','','','',0,1,0,'sys_file',162,''),('945c1a4a2eaa64dbd7609a2142947dda','tx_grevman_domain_model_note',25,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('94851f00b5125c33803aa8f990372a6d','sys_file_reference',483,'uid_local','','','',0,1,0,'sys_file',162,''),('9535d4d91e590a4fcd1a8e34cdec87b5','tx_grevman_domain_model_registration',91,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('95470546f9eb04a895fc0f48d745a6f3','tx_grevman_domain_model_note',104,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('9580e85928b794ef6d7c12cd32e0de51','sys_file',162,'storage','','','',0,0,0,'sys_file_storage',1,''),('95ce75ad45b6e7d8f6678ceaf54a47a2','tx_grevman_domain_model_note',54,'member','','','',0,0,0,'fe_users',10,''),('95dd2ac5d4bf973c105b721a1e4a6296','tx_grevman_domain_model_note',29,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('95ec9edea615373394103b4ad5555fd8','tx_grevman_domain_model_event',41,'parent','','','',0,1,0,'tx_grevman_domain_model_event',1,''),('95f32caacb1f19eb6a0e30f6edab8ac7','tx_grevman_domain_model_note',126,'member','','','',0,1,0,'fe_users',10,''),('95ffbe737c1dd4067220d64069eeb014','tx_grevman_domain_model_note',89,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('960aa089e00265819ba438da103427b2','tx_grevman_domain_model_registration',80,'member','','','',0,0,0,'fe_users',16,''),('967d72041cb880c5ea6bc170c5302342','sys_file_reference',539,'uid_local','','','',0,1,0,'sys_file',163,''),('96927ba434d76e817077b5634f368e8e','tx_grevman_domain_model_registration',113,'member','','','',0,1,0,'fe_users',12,''),('96a59e61b73e768638019b2b1bb1c917','tx_grevman_domain_model_registration',120,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('96df25b0b0e553d9f9e39f889ed50225','tx_grevman_domain_model_note',83,'member','','','',0,1,0,'fe_users',10,''),('9740d26b654110ec0349cc1c827130c0','tx_grevman_domain_model_note',84,'member','','','',0,1,0,'fe_users',10,''),('97835b42415f21656908bbcab963d166','tx_grevman_domain_model_event',3,'member_groups','','','',0,1,0,'tx_grevman_domain_model_group',1,''),('97dbe383a8c8a179af301ade554a0bfc','sys_file_reference',544,'uid_local','','','',0,1,0,'sys_file',163,''),('98106a6299dd39954ce4a21d1c36da42','tx_grevman_domain_model_note',27,'member','','','',0,0,0,'fe_users',10,''),('98209d6a34c7af0c31c0d2fcd54fcc94','tx_grevman_domain_model_event',8,'member_groups','','','',0,1,0,'tx_grevman_domain_model_group',1,''),('987183e91a94eb378c1f696f29c5d6c8','tx_grevman_domain_model_registration',76,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('9893c9bda0c0b4ad1573324cc7b6b75d','tx_grevman_domain_model_note',36,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('98a267aa61b7bcfc6c3537fc24427288','tx_grevman_domain_model_registration',56,'member','','','',0,0,0,'fe_users',16,''),('98dc8792b9617f5c07c15b838f529eee','tx_grevman_domain_model_event',13,'member_groups','','','',0,1,0,'tx_grevman_domain_model_group',1,''),('99394646e4a81073a57a12e9377e72cd','sys_file_reference',470,'uid_local','','','',0,1,0,'sys_file',154,''),('9977e66c5865a8a5df336fcb7a5d2f59','sys_file_metadata',1,'file','','','',0,0,0,'sys_file',149,''),('99971f6ae39360e6e07433e37ace7fc4','tx_grevman_domain_model_note',55,'member','','','',0,0,0,'fe_users',10,''),('999fe42439057ece32d11c4bf6a62d87','tx_grevman_domain_model_note',40,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('99d71a2d1a9db912ff56c578ddab05a9','tx_grevman_domain_model_note',67,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('9aa91892fa709055329517d1daba88ea','tx_grevman_domain_model_note',110,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('9acf4df6906fc3502778196f63bc8c97','tx_grevman_domain_model_event',15,'parent','','','',0,1,0,'tx_grevman_domain_model_event',1,''),('9aea6716ec861cd736136ed4fa5e36e0','tx_grevman_domain_model_registration',88,'member','','','',0,1,0,'fe_users',16,''),('9b0d0f88be0a53e8727a18ef7de06e58','tx_grevman_domain_model_event',25,'member_groups','','','',0,1,0,'tx_grevman_domain_model_group',1,''),('9b7ce411ff080acf3c9e811d231554ba','sys_file_metadata',16,'file','','','',0,0,0,'sys_file',160,''),('9c1bf6904bb88d20371d13c295b291df','tx_grevman_domain_model_registration',31,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('9c5e42231b9a316fb3bc2b1d44fd3cdf','sys_file_metadata',6,'file','','','',0,0,0,'sys_file',10,''),('9c7bbdd0cd3a6ebe9db100417fc23299','tx_grevman_domain_model_note',125,'member','','','',0,1,0,'fe_users',10,''),('9ca3ac09ce88f6c51e2b783e96a94ae6','tx_grevman_domain_model_registration',137,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('9cd67c490351c9a77d4e6e5bd9a4a297','tx_grevman_domain_model_registration',25,'event','','','',0,1,0,'tx_grevman_domain_model_event',41,''),('9d177d91577c3842039403141f2888cc','sys_file_reference',515,'uid_local','','','',0,1,0,'sys_file',162,''),('9d56069837791b5a060bc2c4c0c4f197','tx_grevman_domain_model_registration',74,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('9d636f34d9af857808fe546cc394a350','tx_grevman_domain_model_registration',130,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('9dd623402a74ba73b68e620024df08b9','tx_grevman_domain_model_note',103,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('9e00e5cc44f23c4bbb0a0fcd26d06637','tx_grevman_domain_model_registration',112,'member','','','',0,1,0,'fe_users',16,''),('9e6463cf82b49eb80a72c28c088de2c7','tx_grevman_domain_model_registration',80,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('9e6ee1098f7291871076f1b92ee281a9','tx_grevman_domain_model_note',68,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('9ebb26f314fa7d3daa1387ec4698133c','tx_grevman_domain_model_registration',156,'event','','','',0,0,0,'tx_grevman_domain_model_event',50,''),('9f5dffef2d8854cb1c461545a2855ddd','sys_file_reference',510,'uid_local','','','',0,1,0,'sys_file',163,''),('9faf924cac0bfd66fe491d019fb8abeb','tx_grevman_domain_model_event',11,'parent','','','',0,1,0,'tx_grevman_domain_model_event',1,''),('a049abb9af325c3a26e45ee3fd68591d','tx_grevman_domain_model_registration',117,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('a0691f079c2a2bc0bfc5115b913891f5','tx_grevman_domain_model_event',9,'parent','','','',0,1,0,'tx_grevman_domain_model_event',1,''),('a07996518032da2d8ae692dea764aded','tx_grevman_domain_model_registration',135,'member','','','',0,1,0,'fe_users',11,''),('a0f70b5f6e8dc959a08c2eeca606912e','tx_grevman_domain_model_note',34,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('a102b35f7dcdb197b24b1aeae8f5ff56','tx_grevman_domain_model_registration',96,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('a24e4d35a06022c99818f15f8b91cdbb','tx_grevman_domain_model_note',46,'member','','','',0,0,0,'fe_users',10,''),('a3292d96da86f48d39e9791ac5be0b9c','tx_grevman_domain_model_note',129,'member','','','',0,1,0,'fe_users',10,''),('a39950e9b8081fa509f02ccc17b2e43f','sys_file_reference',557,'uid_local','','','',0,0,0,'sys_file',162,''),('a3c452a0e14a84ffe2d5171d6be78ef1','tx_grevman_domain_model_note',142,'event','','','',0,0,0,'tx_grevman_domain_model_event',50,''),('a3d0408c9228946dc6f691210cf097cb','tx_grevman_domain_model_registration',115,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('a3d76cefcb4c6622b7e29e6ea2733992','tx_grevman_domain_model_registration',100,'member','','','',0,1,0,'fe_users',16,''),('a3f520db1d1af594b6d2e4c0e521b6d4','tx_grevman_domain_model_note',24,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('a41d81f757a7fccb18dc3d53b4c1f6eb','tx_grevman_domain_model_event',35,'parent','','','',0,1,0,'tx_grevman_domain_model_event',1,''),('a41d94dfba6c62893ad64790411bbb79','tx_grevman_domain_model_note',1,'member','','','',0,0,0,'fe_users',10,''),('a46cc2d19469c0e28f1e210c2c9856a3','sys_file_reference',477,'uid_local','','','',0,1,0,'sys_file',162,''),('a47c595f30a39932843cfc6608e110c3','tx_grevman_domain_model_note',132,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('a4ccd22794aa259f362a141b5349ff8a','tx_grevman_domain_model_registration',9,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('a4d208a1c660345b70733af74c1b58cd','tx_grevman_domain_model_registration',157,'member','','','',0,0,0,'fe_users',14,''),('a546ac2f4d6958a56458739747c30239','tx_grevman_domain_model_registration',36,'member','','','',0,0,0,'fe_users',16,''),('a576d18bb58bf2554266c975add5eabc','tx_grevman_domain_model_group',1,'members','','','',1,0,0,'fe_users',11,''),('a5aa2598cb013e3dea700e5b717bff0c','tx_grevman_domain_model_event',39,'parent','','','',0,1,0,'tx_grevman_domain_model_event',1,''),('a5dc3cca450955826dc2faa20012b8c8','tx_grevman_domain_model_registration',70,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('a65158627151017c069886f35f65a696','tx_grevman_domain_model_event',3,'parent','','','',0,1,0,'tx_grevman_domain_model_event',1,''),('a676570b16d42e8d901f06388323f0c4','tx_grevman_domain_model_registration',35,'member','','','',0,0,0,'fe_users',11,''),('a67968d2d153ccd0221cc0aff588c4d3','tx_grevman_domain_model_registration',16,'member','','','',0,1,0,'fe_users',10,''),('a7a09451fd5bcef90fbc3559aadde859','tx_grevman_domain_model_registration',87,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('a7b1bc88c81537449019c9052a1ab545','sys_file',3,'metadata','','','',0,0,0,'sys_file_metadata',4,''),('a9b954fd729a55a75e0f590e8fe7ea1c','tx_grevman_domain_model_registration',79,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('a9fe512bf33054b612782a3f926e0cf4','sys_file_reference',519,'uid_local','','','',0,1,0,'sys_file',162,''),('aa1466e0c4f6b07cd1dc1ac1a8c0b45d','tx_grevman_domain_model_event',10,'member_groups','','','',0,1,0,'tx_grevman_domain_model_group',1,''),('aa1a3b10fad228d814f3068714c3dcf9','sys_file',163,'storage','','','',0,0,0,'sys_file_storage',1,''),('aa3ae487518edaff3f8e6e3a8e9f60e6','tx_grevman_domain_model_registration',11,'event','','','',0,1,0,'tx_grevman_domain_model_event',20,''),('aab6144eb63430be30a41affd2e6cdc2','tx_grevman_domain_model_registration',143,'member','','','',0,1,0,'fe_users',11,''),('ab0192e836f19b498750f274f13862f4','tx_grevman_domain_model_registration',93,'member','','','',0,1,0,'fe_users',12,''),('ab0791fb6eceb58bb7648d2d6a6a142c','tx_grevman_domain_model_registration',148,'member','','','',0,1,0,'fe_users',16,''),('ab186841d37d7c363422364dc4bc32e5','tx_grevman_domain_model_registration',124,'member','','','',0,1,0,'fe_users',16,''),('ab364d4c5800ceee44cbae4c4ec839d5','tx_grevman_domain_model_registration',13,'member','','','',0,1,0,'fe_users',10,''),('ab94c2de4a1f4fb56ac2ba519faed8d0','tx_grevman_domain_model_registration',84,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('abc5d91f8b811ca7c6ac905c9e878a90','sys_file_reference',484,'uid_local','','','',0,1,0,'sys_file',162,''),('ac3a59f1c46dd25c27087eacf3360d7d','tx_grevman_domain_model_registration',53,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('ac3fa06adf8f4d5a575ce385d638e225','tx_grevman_domain_model_registration',98,'member','','','',0,1,0,'fe_users',10,''),('ac59ac01ea156401abc7192aa0ef9da8','tx_grevman_domain_model_event',1,'images','','','',0,0,0,'sys_file_reference',502,''),('acc4add943c0e8c52dfdc32e3697cc23','tx_grevman_domain_model_note',19,'member','','','',0,0,0,'fe_users',10,''),('ace76d95bfcbb07b9caca03c29c85aa8','fe_users',11,'usergroup','','','',0,0,0,'fe_groups',3,''),('ae078b43f5950349ff6915bc1bb29b85','tx_grevman_domain_model_event',26,'parent','','','',0,1,0,'tx_grevman_domain_model_event',1,''),('ae207b51f78fd6606c533257f7573d34','tx_grevman_domain_model_registration',119,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('ae8ec1ed8c318a69570ccf7482b4984f','tx_grevman_domain_model_registration',79,'member','','','',0,0,0,'fe_users',11,''),('af06740a9a6ba6453bfb549eb3e5d4a8','tx_grevman_domain_model_registration',30,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('af23497ed23796f3d269db28cc710545','tx_grevman_domain_model_event',50,'notes','','','',3,0,0,'tx_grevman_domain_model_note',142,''),('af3c617d5228d61d2fa2c1e9984c32c3','tx_grevman_domain_model_event',37,'member_groups','','','',0,1,0,'tx_grevman_domain_model_group',1,''),('af7ef656b523bb5f9eea0d90262c6a87','tx_grevman_domain_model_registration',147,'member','','','',0,1,0,'fe_users',11,''),('af93f6044b838a4c263a808504dbd931','sys_file_reference',485,'uid_local','','','',0,1,0,'sys_file',163,''),('b02b0518ebb2426cd98a0ef62a770e69','tx_grevman_domain_model_note',15,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('b04dc218c2950d9fab069a2db291c2e1','tx_grevman_domain_model_note',81,'member','','','',0,1,0,'fe_users',10,''),('b06cbc678300f109c8c4bad5c27430b2','sys_file_reference',496,'uid_local','','','',0,1,0,'sys_file',162,''),('b0c300a4b99e6259db39373e8810a2b7','tx_grevman_domain_model_registration',81,'member','','','',0,0,0,'fe_users',12,''),('b0c5d8d9965672f356befb445e5d30d1','tx_grevman_domain_model_note',25,'member','','','',0,0,0,'fe_users',10,''),('b0f4eb5269cde018cca2941d32b2a1f2','fe_users',10,'notes','','','',2,0,0,'tx_grevman_domain_model_note',137,''),('b17a3df8f80adc2accf50a8db2e720d5','tx_grevman_domain_model_note',92,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('b197a67f84b2bd7333ec4eabe20cb62d','tx_grevman_domain_model_note',22,'member','','','',0,0,0,'fe_users',10,''),('b1c53662af2bb8fa6dcc5e753c947b26','sys_file_reference',546,'uid_local','','','',0,0,0,'sys_file',163,''),('b1f1febe227003cb1b397830834b3a0a','tx_grevman_domain_model_event',26,'member_groups','','','',0,1,0,'tx_grevman_domain_model_group',1,''),('b318086aca61fe6bf686993cc21c4f38','tx_grevman_domain_model_note',138,'event','','','',0,0,0,'tx_grevman_domain_model_event',50,''),('b33f61948b8540fb82d431ecb8e57181','tx_grevman_domain_model_note',43,'member','','','',0,0,0,'fe_users',10,''),('b3939f3820664ed428ec993620d3de5b','sys_file_reference',525,'uid_local','','','',0,1,0,'sys_file',162,''),('b3b5558ddcded39ae36084aa02efc9d5','tx_grevman_domain_model_note',6,'member','','','',0,1,0,'fe_users',10,''),('b3d7b4363616e734be68385f230b78fc','tx_grevman_domain_model_registration',97,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('b3e948d16eed1759d6c84fdaa38eb592','tx_grevman_domain_model_registration',39,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('b47d99990a9ad34fc57cece6dbed0771','tx_grevman_domain_model_registration',29,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('b4a6326fce51017c5593bd6f777f9240','tx_grevman_domain_model_registration',10,'member','','','',0,1,0,'fe_users',10,''),('b4b652acbd95ddfddd0dec8c0ef9a47f','tx_grevman_domain_model_note',10,'member','','','',0,1,0,'fe_users',10,''),('b4c2f7b85f5ab82485b47f822fa3f084','tx_grevman_domain_model_note',27,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('b56641a2d1e88baf5501cd9145d78a54','tx_grevman_domain_model_registration',98,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('b5fd935ae167507d2f92f4b00ea4ff51','tx_grevman_domain_model_note',75,'member','','','',0,1,0,'fe_users',10,''),('b6009b9156c254672d9ca5b9988a20fa','tx_grevman_domain_model_note',30,'member','','','',0,0,0,'fe_users',10,''),('b61ff500bd2dcbbfb7ad519bd7db3108','tx_grevman_domain_model_event',50,'notes','','','',0,0,0,'tx_grevman_domain_model_note',137,''),('b62708f0bc8cb2fb1639bb61c44e54b7','tx_grevman_domain_model_registration',34,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('b64b857b7dabd85cff72fa687d8b6d58','tx_grevman_domain_model_event',14,'parent','','','',0,1,0,'tx_grevman_domain_model_event',1,''),('b6636192ae90a04fad875a1759cbe29d','tx_grevman_domain_model_event',32,'member_groups','','','',0,1,0,'tx_grevman_domain_model_group',1,''),('b6917056299eecdb2173a3ced607a4c6','tx_grevman_domain_model_note',102,'member','','','',0,1,0,'fe_users',10,''),('b693b5c41bcb7433f72d60225d70df0b','sys_file_reference',506,'uid_local','','','',0,1,0,'sys_file',163,''),('b6a7601f4c3e71210caa68e1072752e5','tx_grevman_domain_model_note',4,'member','','','',0,0,0,'fe_users',10,''),('b71d66ca8b502e7e5a8d0d1fc609d9c8','tx_grevman_domain_model_event',13,'parent','','','',0,1,0,'tx_grevman_domain_model_event',1,''),('b7d5a12c3e9ffd3db9ada32b75c21134','fe_users',10,'registrations','','','',1,0,0,'tx_grevman_domain_model_registration',154,''),('b84b1082ecbe77a46b96ad008fc52e49','tx_grevman_domain_model_note',90,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('b8cb4541d00a9a48595e5b62c86c9c13','tx_grevman_domain_model_event',50,'files','','','',0,0,0,'sys_file_reference',558,''),('b945ea537346b2d47dc3837021674ff6','tx_grevman_domain_model_registration',142,'member','','','',0,1,0,'fe_users',10,''),('b97800c0d87adbbd822874233d09f819','tx_grevman_domain_model_event',43,'link','','typolink','4993c8ffed88a1f5819fdc6f834e3b5c:0',-1,1,0,'pages',1,''),('b990b84f73eeb6bd45f8540cab5326a5','tx_grevman_domain_model_note',62,'member','','','',0,0,0,'fe_users',10,''),('b9ab66ac36f9b0850f7737dee69d45a8','tx_grevman_domain_model_note',65,'member','','','',0,0,0,'fe_users',10,''),('b9eb15f298b1676b0d0ec27e14da1570','tx_grevman_domain_model_registration',102,'member','','','',0,1,0,'fe_users',10,''),('b9efc5892c55f7c0c72b3e3749c4aa36','tx_grevman_domain_model_note',50,'member','','','',0,0,0,'fe_users',10,''),('b9fd855b4db8cfdf27d0ec4d19601803','tx_grevman_domain_model_note',131,'member','','','',0,1,0,'fe_users',10,''),('ba471c06b5c3f57fac482f6ab3fea93b','tx_grevman_domain_model_registration',57,'member','','','',0,0,0,'fe_users',12,''),('ba7a75d86fd752d0155da77bb7e82e3f','tx_grevman_domain_model_registration',54,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('bab86bff5b0630894866fe8aaff620c2','sys_file',134,'metadata','','','',0,0,0,'sys_file_metadata',7,''),('baba3ecab97fba2b09d682a1ecb204bf','tx_grevman_domain_model_event',9,'member_groups','','','',0,1,0,'tx_grevman_domain_model_group',1,''),('bb4936c063668cd86a4ce9ecec0b999d','tx_grevman_domain_model_registration',53,'member','','','',0,0,0,'fe_users',12,''),('bb8723624214941cb0e472034d5b31c8','sys_file_metadata',14,'file','','','',0,0,0,'sys_file',158,''),('bc050a0a7f442a178b85919345268b8a','tx_grevman_domain_model_registration',126,'member','','','',0,1,0,'fe_users',10,''),('bc81068ad21ca3d1a98cc4f0d20704ba','tx_grevman_domain_model_note',101,'member','','','',0,1,0,'fe_users',10,''),('bcc2fd5d5bf749e69acb34b7187cf570','tx_grevman_domain_model_registration',77,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('bcc853d59cea0c004b077b2b990e579c','tx_grevman_domain_model_registration',110,'member','','','',0,1,0,'fe_users',10,''),('bd756e9169543667c15a58eea5e1b25b','tx_grevman_domain_model_registration',24,'member','','','',0,1,0,'fe_users',14,''),('be4812eb1a48c0c5016bf95d9ff10ffa','tx_grevman_domain_model_note',69,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('be76c81502aafbc89bd36e8aab8272d0','tx_grevman_domain_model_note',20,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('be9cf39cdae8c22c032fa11928f4b533','tx_grevman_domain_model_registration',87,'member','','','',0,1,0,'fe_users',11,''),('befb277a1be59abfba2dc2eac284489f','tx_grevman_domain_model_note',121,'member','','','',0,1,0,'fe_users',10,''),('bf9ebb1f5f289f74f6c6c1881f5db428','tx_grevman_domain_model_event',45,'guests','','','',0,1,0,'tx_grevman_domain_model_guest',1,''),('bfa27cb6cc57e807c4d1918c98926455','tx_grevman_domain_model_event',30,'parent','','','',0,1,0,'tx_grevman_domain_model_event',1,''),('bfc9f144435993ba1c7df2aa98d58069','tx_grevman_domain_model_note',112,'member','','','',0,1,0,'fe_users',10,''),('bfea44dec3cc1391d428fc2c6ce5416a','tx_grevman_domain_model_registration',69,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('c239df0adb033c13f1a0530f5460a141','tx_grevman_domain_model_note',133,'member','','','',0,1,0,'fe_users',10,''),('c2509b5394a0925db35847fb864c27f3','tx_grevman_domain_model_event',38,'member_groups','','','',0,1,0,'tx_grevman_domain_model_group',1,''),('c2db2d185e97fb2ed9859cfebdbe6718','sys_file',9,'storage','','','',0,0,0,'sys_file_storage',1,''),('c3557685ea71711614fb6b16593d0602','tx_grevman_domain_model_registration',109,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('c36cc5d01323091113cb1ea30028d2f9','tx_grevman_domain_model_note',98,'member','','','',0,1,0,'fe_users',10,''),('c38f496007f9cea19a7f7aeb20877900','tx_grevman_domain_model_event',31,'member_groups','','','',0,1,0,'tx_grevman_domain_model_group',1,''),('c46111af7b9313f452473d53f9422f09','tx_grevman_domain_model_note',7,'member','','','',0,1,0,'fe_users',10,''),('c4c7f86bd4da4277267d6921515c2ec6','tx_grevman_domain_model_note',116,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('c5da238be7aa422519231099ad37b959','tx_grevman_domain_model_registration',132,'member','','','',0,1,0,'fe_users',16,''),('c5f80bce153391fbe7190f2819a3bec1','tx_grevman_domain_model_note',90,'member','','','',0,1,0,'fe_users',10,''),('c6037e489548db31e3d6a1da42dabcf3','tx_grevman_domain_model_registration',2,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('c6a69c53b7cdf0674c29739d9a8e5340','tx_grevman_domain_model_event',41,'member_groups','','','',0,1,0,'tx_grevman_domain_model_group',1,''),('c6ce34146251ed8fe5c6e7da7c81d768','tx_grevman_domain_model_event',28,'member_groups','','','',0,1,0,'tx_grevman_domain_model_group',1,''),('c71cd195955f5402f9410c7c77111195','sys_file',133,'metadata','','','',0,0,0,'sys_file_metadata',12,''),('c74980d272e38550744f276693dfa868','fe_users',10,'notes','','','',3,0,0,'tx_grevman_domain_model_note',136,''),('c74e82e0d4e725855956cb6e9ee9bfd0','tx_grevman_domain_model_registration',47,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('c7864b3d88cf27eb00a71ce2e41eed93','sys_file_reference',474,'uid_local','','','',0,1,0,'sys_file',162,''),('c7925ef0c906c1160e727686958d7c28','tx_grevman_domain_model_note',23,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('c7e76893ca9ea08a6462c087cf7769d7','tx_grevman_domain_model_note',72,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('c84e80db98855d6a63e5bc6a98c6f770','tx_grevman_domain_model_note',114,'member','','','',0,1,0,'fe_users',10,''),('c877ce70156fd2fa5e365b7aa2dd6be1','tx_grevman_domain_model_note',59,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('c89a1367e1682265f72f76a0277800f1','tx_grevman_domain_model_event',34,'member_groups','','','',0,1,0,'tx_grevman_domain_model_group',1,''),('c928091493edcdc7ed39f8f8aefe8393','tx_grevman_domain_model_event',1,'guests','','','',0,0,0,'tx_grevman_domain_model_guest',1,''),('cb4d968b115473a5caf9570ac99c85ed','tx_grevman_domain_model_note',71,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('cb952b3be5f4a02ba53e46e8bdad0591','tx_grevman_domain_model_note',8,'event','','','',0,1,0,'tx_grevman_domain_model_event',16,''),('cba99364fc95712734136d88b3f17739','tx_grevman_domain_model_note',47,'member','','','',0,0,0,'fe_users',10,''),('cbca2cfbb7d6709d41a8f58c91ed5fc9','sys_file',10,'metadata','','','',0,0,0,'sys_file_metadata',6,''),('cc0835a91a2ae654f64deb38ce219501','fe_users',13,'usergroup','','','',0,0,0,'fe_groups',3,''),('cd10868881a160a8c466907e2bf083cd','tx_grevman_domain_model_note',37,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('ce4f3fb10a07e9a3b98c4847e48d1c70','tx_grevman_domain_model_registration',49,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('ce77822de304d2541a2d248fa25ffcb3','tx_grevman_domain_model_event',44,'link','','typolink','76063fbe162996cff6fd113185c6c87b:0',-1,1,0,'pages',1,''),('cee50ffda4f4beb5fcd4faa180f45acc','tx_grevman_domain_model_note',8,'member','','','',0,1,0,'fe_users',10,''),('cf3b482d8fc36d9a0da68e4201560bcb','tx_grevman_domain_model_note',137,'event','','','',0,0,0,'tx_grevman_domain_model_event',50,''),('cf723664b472a2f95d3893baac18bb18','sys_file_reference',517,'uid_local','','','',0,1,0,'sys_file',162,''),('d04bd06caf1a1be83d94687cb2108908','tx_grevman_domain_model_note',111,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('d05c1e268341747606f30ac919dd66c5','tx_grevman_domain_model_registration',71,'member','','','',0,0,0,'fe_users',11,''),('d113477fdc31e34c0fe4f445ba4f9d87','tx_grevman_domain_model_registration',60,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('d1a0190edeac8246660898094722734d','tx_grevman_domain_model_note',16,'member','','','',0,0,0,'fe_users',10,''),('d2090f4fb4b1c374052213f4c819e18a','tx_grevman_domain_model_registration',99,'member','','','',0,1,0,'fe_users',11,''),('d24cd9353d22bc44634aaaefd1b1ddc9','tx_grevman_domain_model_event',50,'parent','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('d2c31995ce2cc2dd04ca51a9afa8cec3','fe_users',10,'registrations','','','',0,0,0,'tx_grevman_domain_model_registration',156,''),('d2f42b5d37c4dd6f6d363c5a678d7d66','tx_grevman_domain_model_note',39,'member','','','',0,0,0,'fe_users',10,''),('d30f52d57e9964c2bb1dccab967b6fe3','tx_grevman_domain_model_registration',92,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('d31346526510da096e893f7dff19ef42','tx_grevman_domain_model_note',2,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('d34d13c95397c8a103141ddff50668b3','sys_file_reference',558,'uid_local','','','',0,0,0,'sys_file',163,''),('d3cbdd965a829ed8df6e301ca4554f29','tx_grevman_domain_model_registration',61,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('d40f605540dd2f6501d89dcfcd381c0e','tx_grevman_domain_model_registration',126,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('d42300c8fabd53bf09847a14f61c45c3','sys_file_reference',518,'uid_local','','','',0,1,0,'sys_file',162,''),('d42f11e8e12ef2ed0f36bf7708c412ae','tx_grevman_domain_model_note',55,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('d4b71a1051b2471b0a4b4ff9bf2a2ae1','tx_grevman_domain_model_note',91,'member','','','',0,1,0,'fe_users',10,''),('d4e1a125f8beb2e00275b6995254a2ff','sys_file_reference',480,'uid_local','','','',0,1,0,'sys_file',163,''),('d4e22a9246a5fb62bc9a6c6dff66507b','tx_grevman_domain_model_note',117,'member','','','',0,1,0,'fe_users',10,''),('d4ec4da3feafe9030ce8259bbf6c8a4b','tx_grevman_domain_model_event',50,'notes','','','',2,0,0,'tx_grevman_domain_model_note',139,''),('d50f1890f7a28524da93258f0f71d011','tx_grevman_domain_model_note',107,'member','','','',0,1,0,'fe_users',10,''),('d556b7d9c270b2c561e90cf9c5d7dbe4','tx_grevman_domain_model_registration',18,'event','','','',0,1,0,'tx_grevman_domain_model_event',29,''),('d5cbf0ad4b2b37f29dc632fe4eaa086e','tx_grevman_domain_model_registration',51,'member','','','',0,0,0,'fe_users',11,''),('d5ee85a1d537b79236a32fd2659e8930','tx_grevman_domain_model_registration',137,'member','','','',0,1,0,'fe_users',12,''),('d6d43d1c5321ddfcda4cf62eccb1f773','tx_grevman_domain_model_note',17,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('d6ef37ba3f26a37e3039cc07f4a8736f','tx_grevman_domain_model_event',5,'parent','','','',0,1,0,'tx_grevman_domain_model_event',1,''),('d73a8f0ecf7dd877fd1da73aae7eca5d','tx_grevman_domain_model_note',56,'member','','','',0,0,0,'fe_users',10,''),('d7a0df0bb7ec3d66c08bd7b299364c74','tx_grevman_domain_model_registration',128,'member','','','',0,1,0,'fe_users',16,''),('d80015a1f42fbaffda4bbef498db51f6','tx_grevman_domain_model_registration',57,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('d81c912b4ac9e55cf9af229b835a3998','tx_grevman_domain_model_note',70,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('d850ab5f37f40f6cd82e268b16ac6e06','tx_grevman_domain_model_registration',143,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('d86b49f21dead4f88292a5a6b2e7c6e5','sys_file',161,'metadata','','','',0,0,0,'sys_file_metadata',17,''),('d87cbef57c28a5ad8e1a4d288192f8b1','tx_grevman_domain_model_event',1,'files','','','',0,0,0,'sys_file_reference',546,''),('d88682a2dccb362600e2bf60030d0bb5','sys_file',133,'storage','','','',0,0,0,'sys_file_storage',1,''),('d9144f47a99deb66fdd41ff79cc8c772','fe_users',15,'usergroup','','','',0,0,0,'fe_groups',4,''),('d9489c6903d0b7544e04fcd58acc40d9','tx_grevman_domain_model_registration',141,'member','','','',0,1,0,'fe_users',12,''),('d9b864035ce92bb54aa87eb5d3b1b6b0','sys_file_reference',497,'uid_local','','','',0,1,0,'sys_file',162,''),('d9cd123c659904f644896ba05a93a2a6','tx_grevman_domain_model_note',123,'member','','','',0,1,0,'fe_users',10,''),('d9f2d73ff61b23aca3d5fdb9f88d2621','tx_grevman_domain_model_note',70,'member','','','',0,0,0,'fe_users',10,''),('da1dc09391e7bf7be1776ea007a9f06f','tx_grevman_domain_model_note',110,'member','','','',0,1,0,'fe_users',10,''),('da81d43b2e2f896233c4d5eafcc775b5','tx_grevman_domain_model_registration',40,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('daaddb19bdbd3cb240996a956c20b176','tx_grevman_domain_model_registration',123,'member','','','',0,1,0,'fe_users',11,''),('daae15b5890518049e8c2d5407a65593','tx_grevman_domain_model_note',59,'member','','','',0,0,0,'fe_users',10,''),('dae5aaba178217b95e034163eb916702','tx_grevman_domain_model_registration',7,'member','','','',0,0,0,'fe_users',10,''),('db1aec5556aa3a9a94e29b11ccc91782','tx_grevman_domain_model_note',116,'member','','','',0,1,0,'fe_users',10,''),('dc86354d5984d45aa4017fe69bedadb3','sys_file_reference',524,'uid_local','','','',0,1,0,'sys_file',162,''),('dcbf38e13d707a3d45a1a32de9a3b408','tx_grevman_domain_model_registration',41,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('dcc494d6e0793b48ac94ec4f78ab4c17','tx_grevman_domain_model_registration',112,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('dd0e1042ed8cadf5d631228deb8b7d3d','tx_grevman_domain_model_registration',157,'event','','','',0,0,0,'tx_grevman_domain_model_event',50,''),('dd7df7432619d47e367e8ee8f18bac00','sys_file_metadata',3,'file','','','',0,0,0,'sys_file',154,''),('de056c7cac4209c1c222620d666c38a7','tx_grevman_domain_model_note',118,'member','','','',0,1,0,'fe_users',10,''),('de3e4227bfc48d9074f1dcfe9b8fa821','sys_file',160,'metadata','','','',0,0,0,'sys_file_metadata',16,''),('de5cefab9b7eaba0f5acd4aa3e6a95ed','tx_grevman_domain_model_note',57,'member','','','',0,0,0,'fe_users',10,''),('deb1f2628cb2f5986294ef5af2cabb3b','tx_grevman_domain_model_event',7,'member_groups','','','',0,1,0,'tx_grevman_domain_model_group',1,''),('dee44ca10d4099a46a96b43f0edb58d5','tx_grevman_domain_model_registration',14,'member','','','',0,1,0,'fe_users',10,''),('df342f9ab4b2e945c007f4e53f3c3dbc','tx_grevman_domain_model_registration',72,'member','','','',0,0,0,'fe_users',16,''),('dfc958ab598276f462dbb63cc1265814','tx_grevman_domain_model_registration',48,'member','','','',0,0,0,'fe_users',16,''),('e01f21dd30f0b856961fa11849153d2a','sys_file_reference',501,'uid_local','','','',0,1,0,'sys_file',162,''),('e069320e68e497c5b8ee327e59f3fc8a','tx_grevman_domain_model_registration',109,'member','','','',0,1,0,'fe_users',12,''),('e0831a4f56d41dda43b63ebd7e899945','tx_grevman_domain_model_note',37,'member','','','',0,0,0,'fe_users',10,''),('e08ff63ae379a53ab0b017fa627a37f3','sys_file',153,'metadata','','','',0,0,0,'sys_file_metadata',2,''),('e0f4bba38cef2db2d4b9155f5d4675ec','tx_grevman_domain_model_note',11,'event','','','',0,1,0,'tx_grevman_domain_model_event',34,''),('e112d17e61ed02c86743a6fe65095027','tx_grevman_domain_model_registration',67,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('e1fb7b019e5b4b2b6d26f63e074dcc27','sys_file_reference',523,'uid_local','','','',0,1,0,'sys_file',162,''),('e26c3141924cb49f746a389a0a77f64a','tx_grevman_domain_model_registration',82,'member','','','',0,0,0,'fe_users',10,''),('e3332d01ca4e512cd6eacc275ca180cb','tx_grevman_domain_model_event',16,'parent','','','',0,1,0,'tx_grevman_domain_model_event',1,''),('e33424a3418cf16f01ac9fbf3febb981','tx_grevman_domain_model_note',28,'member','','','',0,0,0,'fe_users',10,''),('e3558a4d89be3780b9cbb3853451a79b','sys_file_reference',533,'uid_local','','','',0,1,0,'sys_file',163,''),('e39e3087df14df34c25fb8922256449e','tx_grevman_domain_model_registration',121,'member','','','',0,1,0,'fe_users',12,''),('e3a3ce5ee983399570b818d5b381d614','tx_grevman_domain_model_registration',127,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('e3c24e064c57a422d65fc4d587cb6d03','tx_grevman_domain_model_registration',107,'member','','','',0,1,0,'fe_users',11,''),('e41fb6147c19a8248c8ea185507493d4','sys_file',157,'metadata','','','',0,0,0,'sys_file_metadata',13,''),('e4755ff26a64b5032d993be36d515e32','tx_grevman_domain_model_registration',118,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('e4988ff3dc21e34bf1ecee76761ea72c','sys_file_reference',511,'uid_local','','','',0,1,0,'sys_file',162,''),('e4cb2e2825d7d947016a3824eed55980','tx_grevman_domain_model_registration',145,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('e56819111d15d25d89389c958cf6dccf','sys_file',132,'metadata','','','',0,0,0,'sys_file_metadata',11,''),('e5eb9473f660dbbe340e15cf40047cb2','sys_file_metadata',10,'file','','','',0,0,0,'sys_file',131,''),('e617a880d7cfd2c40739464305c2e270','tx_grevman_domain_model_note',56,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('e66f640726c8cc5650293b95da813fe7','tx_grevman_domain_model_registration',101,'member','','','',0,1,0,'fe_users',12,''),('e6730e9134ee07ea6b5035c756f2040d','tx_grevman_domain_model_registration',27,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('e6af62a1711c7e72a0a9d23330a6cd34','sys_file_reference',475,'uid_local','','','',0,1,0,'sys_file',162,''),('e6c3bdef11bbb6ac2ee34368541bb71c','tx_grevman_domain_model_note',14,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('e7078142a505afda6191ccc831a88dc5','tx_grevman_domain_model_note',34,'member','','','',0,0,0,'fe_users',10,''),('e7461cebd1f62a732d945cbf6b1bf69f','sys_file_reference',488,'uid_local','','','',0,1,0,'sys_file',162,''),('e756a957a9883f8c995a13179482649a','tx_grevman_domain_model_note',10,'event','','','',0,1,0,'tx_grevman_domain_model_event',27,''),('e7dc629a06d07ed07b14280aed76df41','tx_grevman_domain_model_event',50,'images','','','',0,0,0,'sys_file_reference',557,''),('e7df0dafb5fd50d0c5de44b75648b983','tx_grevman_domain_model_group',2,'members','','','',1,0,0,'fe_users',12,''),('e7ea80cf00c6f4e7e95ec507ac6fd564','tx_grevman_domain_model_registration',28,'member','','','',0,0,0,'fe_users',16,''),('e834a903e3322b419da99744f3a1b730','tx_grevman_domain_model_note',58,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('e83e09d7f2a2da1ee89f66e990b60419','tx_grevman_domain_model_note',129,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('e83f3d666be13ffe3a9042a459ce96f0','sys_file_metadata',2,'file','','','',0,0,0,'sys_file',153,''),('e84d3445abb96c026a27baaeeed79321','tx_grevman_domain_model_note',76,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('e861f51072dc7f0ab955df41f090cb08','tx_grevman_domain_model_registration',119,'member','','','',0,1,0,'fe_users',11,''),('e873bdabfc6a85dcb0d6158deff1310d','tx_grevman_domain_model_note',93,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('e8865d558e19f5a292fae39386de22c9','sys_file_reference',481,'uid_local','','','',0,1,0,'sys_file',162,''),('e895059f7502862e0426d074f93a7e7c','tx_grevman_domain_model_event',1,'member_groups','','','',0,0,0,'tx_grevman_domain_model_group',1,''),('e8beb637397f4336f245a446deb5f97b','tx_grevman_domain_model_registration',131,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('e92f81c07bc9c1caf24d5154c0594ab2','tx_grevman_domain_model_registration',129,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('e95293f746c80ac00b2c7f988afeb9cb','tx_grevman_domain_model_registration',36,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('e968623475345c601c76918262c4a9f3','tx_grevman_domain_model_event',5,'member_groups','','','',0,1,0,'tx_grevman_domain_model_group',1,''),('e9ce36fbc51321e22239deda893e4010','tx_grevman_domain_model_registration',81,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('e9da2b210345adf74894c6f5ea892e00','tx_grevman_domain_model_registration',59,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('e9e7e8b05289f54e218fb1a98cf11a92','tx_grevman_domain_model_registration',125,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('e9f8ea1cc9e4e4970d5efbcf744b0afb','tx_grevman_domain_model_registration',64,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('ea9af1f151fb45e318a461fb5681a019','tx_grevman_domain_model_registration',127,'member','','','',0,1,0,'fe_users',11,''),('eb06c35e34a8b626422ce70f568d7ebe','tx_grevman_domain_model_note',35,'member','','','',0,0,0,'fe_users',10,''),('eb4b75ed72808c72dbcdce653e46932d','tx_grevman_domain_model_note',87,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('eb777c76647df4ccfe63fa00d609bf1b','tx_grevman_domain_model_note',47,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('ec4a05300a3ce570649f786c96fbb93f','sys_file_reference',545,'uid_local','','','',0,1,0,'sys_file',162,''),('ec95e555000fc0220f355a6298477938','sys_file_reference',531,'uid_local','','','',0,1,0,'sys_file',163,''),('ed156d515ac902f7508c7caeed4fbf2a','tx_grevman_domain_model_event',17,'member_groups','','','',0,1,0,'tx_grevman_domain_model_group',1,''),('ed1894847977aafa423f995fcaee3826','sys_file',134,'storage','','','',0,0,0,'sys_file_storage',1,''),('ed47ec7a4e75bad2e5ea648a3d4fa6da','tx_grevman_domain_model_registration',96,'member','','','',0,1,0,'fe_users',16,''),('ed9def4e795c51310ad067edfccc0eb7','tx_grevman_domain_model_registration',4,'member','','','',0,0,0,'fe_users',12,''),('edcad91af2e01a372a3e68b86033098a','tx_grevman_domain_model_registration',133,'member','','','',0,1,0,'fe_users',12,''),('ee158cbd5c96e7446a1c2be6a0970f32','tx_grevman_domain_model_event',42,'guests','','','',0,1,0,'tx_grevman_domain_model_guest',1,''),('ee281e9df3986519b27008569fe0351d','tx_grevman_domain_model_note',40,'member','','','',0,0,0,'fe_users',10,''),('eea32f16d86bfaa40289dc1c744b956e','tx_grevman_domain_model_note',142,'member','','','',0,0,0,'fe_users',14,''),('eec39cc2c7a29bd3796fe339320b8f99','tx_grevman_domain_model_note',62,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('eed1f0244a14b10f9b8cdebfe6788da7','tx_grevman_domain_model_registration',34,'member','','','',0,0,0,'fe_users',10,''),('eef39d9b6f891eceb5521ba59a7b3a9b','tx_grevman_domain_model_note',132,'member','','','',0,1,0,'fe_users',10,''),('ef16fd164356408bf178d6c7b29c9a08','tx_grevman_domain_model_note',3,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('ef841049530f6f5b418de5d0a6d7d7c5','tx_grevman_domain_model_note',5,'member','','','',0,0,0,'fe_users',10,''),('efefeaf9440a836ce550cb64d9762ae7','tx_grevman_domain_model_registration',23,'member','','','',0,1,0,'fe_users',14,''),('f07ee3f1d08e2deae1da6c8be59df56a','tx_grevman_domain_model_event',43,'member_groups','','','',0,1,0,'tx_grevman_domain_model_group',2,''),('f0a43e18e817c7362eab7e3e311caa29','tx_grevman_domain_model_note',44,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('f13a8a19b3aee24a1cf1c88052923cff','sys_file_reference',530,'uid_local','','','',0,1,0,'sys_file',163,''),('f1719afec5893cff2964e51282c8dadf','tx_grevman_domain_model_registration',37,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('f17951f8a720ed2d637d2ce339af5bbb','tx_grevman_domain_model_registration',5,'event','','','',0,0,0,'tx_grevman_domain_model_event',2,''),('f1dbd03ae966cc85a6e094c9b2913175','tx_grevman_domain_model_note',105,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('f208c0ee078ce640c9154b4da224c777','tx_grevman_domain_model_note',63,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('f21690075baeaae5c33af628452bbc4a','tx_grevman_domain_model_registration',20,'member','','','',0,1,0,'fe_users',14,''),('f27e2c061fa1f610fcb2766f8403436d','sys_file_reference',494,'uid_local','','','',0,1,0,'sys_file',163,''),('f2ca18192a62c45dbeb2ccec7b60b53f','tx_grevman_domain_model_note',122,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('f2eaa553a6536cee906ee7d78697be50','tx_grevman_domain_model_note',32,'member','','','',0,0,0,'fe_users',10,''),('f4261362fa4279d46c840f84f6b6eaa1','tx_grevman_domain_model_registration',121,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('f44200d3bc6ac6d1cfddf1cbcf2d8f30','tx_grevman_domain_model_note',36,'member','','','',0,0,0,'fe_users',10,''),('f478c879e596705782b023ec9310a31f','sys_file',131,'metadata','','','',0,0,0,'sys_file_metadata',10,''),('f492590fffe67212ff558749f14461be','tx_grevman_domain_model_registration',123,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('f4d9cb8af349c33f1b11736a3c138d48','tx_grevman_domain_model_note',74,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('f5aa77ce1f5e00a81f24c918c8ebbc5c','tx_grevman_domain_model_event',19,'member_groups','','','',0,1,0,'tx_grevman_domain_model_group',1,''),('f5c99251bd7e4b33d039eb0d0246a58d','tx_grevman_domain_model_note',12,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('f62e1a6fcfe8a8eed294ee4180814ccf','tx_grevman_domain_model_registration',129,'member','','','',0,1,0,'fe_users',12,''),('f6981c87a25a8cb1cb9ed84c9598e399','tx_grevman_domain_model_registration',32,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('f6a7054cce4198f78c2b6ae0b45ef892','tx_grevman_domain_model_note',99,'member','','','',0,1,0,'fe_users',10,''),('f7567bb64a8162b3902c22380d42440b','tx_grevman_domain_model_event',20,'member_groups','','','',0,1,0,'tx_grevman_domain_model_group',1,''),('f7726abc232b579510d5e67f31200aee','tx_grevman_domain_model_note',39,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('f7ad813e0b2a42048ee55833951c9bb1','tx_grevman_domain_model_note',17,'member','','','',0,0,0,'fe_users',10,''),('f7f73c25f7bb8b4bf64608c968ac8471','tx_grevman_domain_model_registration',134,'member','','','',0,1,0,'fe_users',10,''),('f8024848ce5c8a189a232f930071c409','tx_grevman_domain_model_note',126,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('f80f9d396029d86a8f5491ddeb2d4634','sys_file_reference',471,'uid_local','','','',0,1,0,'sys_file',162,''),('f84e111180d7092b47d6aa6ff27c58e0','sys_file_reference',500,'uid_local','','','',0,1,0,'sys_file',162,''),('f86139ef430e2552bc6615f8160a1376','tx_grevman_domain_model_registration',110,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('f891df2d79376f4857dcd6e23da2a319','tx_grevman_domain_model_note',79,'member','','','',0,1,0,'fe_users',10,''),('f898a1eaeb8b6fabf0aa7a51dfefa4ab','tx_grevman_domain_model_registration',106,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('f973568d8f9b1b276b6d71b2b1b4d20c','tx_grevman_domain_model_note',96,'member','','','',0,1,0,'fe_users',10,''),('fa0aee726f987a85648f9bd156f1592f','tx_grevman_domain_model_registration',35,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('fa12d948e016a683f29c425345bae1e6','tx_grevman_domain_model_note',128,'member','','','',0,1,0,'fe_users',10,''),('fa74f1cb255aa8adb16d185d4c41102d','tx_grevman_domain_model_registration',43,'member','','','',0,0,0,'fe_users',11,''),('fae06194d499c4885944df1b67cfe7d3','sys_file',161,'storage','','','',0,0,0,'sys_file_storage',1,''),('fb167914c28024111d4f7eb824bedfd2','tx_grevman_domain_model_event',17,'parent','','','',0,1,0,'tx_grevman_domain_model_event',1,''),('fb6c15e68b457503226659b14f8f647b','sys_file_reference',548,'uid_local','','','',0,1,0,'sys_file',163,''),('fb8fbdf02b1d1848c0aa0dcca437bcc4','tx_grevman_domain_model_note',52,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('fbe62127453c4788ee955ac0e6e4a6c6','tx_grevman_domain_model_note',109,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('fbf7beab7274529d29c84024ecfcbc77','sys_file_reference',499,'uid_local','','','',0,1,0,'sys_file',162,''),('fc2da03c15365c242cd1c48cd4e6a227','tx_grevman_domain_model_registration',94,'member','','','',0,1,0,'fe_users',10,''),('fcbac18a487a78724e0abd61e668f3f0','sys_file_reference',520,'uid_local','','','',0,1,0,'sys_file',162,''),('fd332954fb1406d529303e8ee1ef2f14','tx_grevman_domain_model_note',100,'member','','','',0,1,0,'fe_users',10,''),('fd4541cd26c3e55dbbfc4cd1b65df6d1','tx_grevman_domain_model_registration',105,'member','','','',0,1,0,'fe_users',12,''),('fd489e38047067d5a117340779c6e65e','tx_grevman_domain_model_note',69,'member','','','',0,0,0,'fe_users',10,''),('fe178ae11c9d44f03eed68235f0e3130','tx_grevman_domain_model_event',2,'link','','typolink','f992614796c62361b6d1a023a4f61baa:0',-1,0,0,'pages',1,''),('fe4175ed05ecf424746db8a3e71ff8e7','tx_grevman_domain_model_note',102,'event','','','',0,1,0,'tx_grevman_domain_model_event',42,''),('fe566d3b328b8e43a064a0afe9406f7d','sys_file_reference',476,'uid_local','','','',0,1,0,'sys_file',162,''),('ff13cb81328a7ac8aca161313df2d3db','sys_file_metadata',4,'file','','','',0,0,0,'sys_file',3,'');
/*!40000 ALTER TABLE `sys_refindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_registry`
--

DROP TABLE IF EXISTS `sys_registry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_registry` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_namespace` varchar(128) NOT NULL DEFAULT '',
  `entry_key` varchar(128) NOT NULL DEFAULT '',
  `entry_value` mediumblob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `entry_identifier` (`entry_namespace`,`entry_key`)
) ENGINE=InnoDB AUTO_INCREMENT=130 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_registry`
--

LOCK TABLES `sys_registry` WRITE;
/*!40000 ALTER TABLE `sys_registry` DISABLE KEYS */;
INSERT INTO `sys_registry` VALUES (1,'installUpdate','TYPO3\\CMS\\Install\\Updates\\ExtensionManagerTables','i:1;'),(2,'installUpdate','TYPO3\\CMS\\Install\\Updates\\WizardDoneToRegistry','i:1;'),(3,'installUpdate','TYPO3\\CMS\\Install\\Updates\\StartModuleUpdate','i:1;'),(4,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FrontendUserImageUpdateWizard','i:1;'),(5,'installUpdate','TYPO3\\CMS\\Install\\Updates\\DatabaseRowsUpdateWizard','i:1;'),(6,'installUpdate','TYPO3\\CMS\\Install\\Updates\\CommandLineBackendUserRemovalUpdate','i:1;'),(7,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FillTranslationSourceField','i:1;'),(8,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SectionFrameToFrameClassUpdate','i:1;'),(9,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SplitMenusUpdate','i:1;'),(10,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BulletContentElementUpdate','i:1;'),(11,'installUpdate','TYPO3\\CMS\\Install\\Updates\\UploadContentElementUpdate','i:1;'),(12,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigrateFscStaticTemplateUpdate','i:1;'),(13,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FileReferenceUpdate','i:1;'),(14,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigrateFeSessionDataUpdate','i:1;'),(15,'installUpdate','TYPO3\\CMS\\Install\\Updates\\Compatibility7ExtractionUpdate','i:1;'),(16,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FormLegacyExtractionUpdate','i:1;'),(17,'installUpdate','TYPO3\\CMS\\Install\\Updates\\RteHtmlAreaExtractionUpdate','i:1;'),(18,'installUpdate','TYPO3\\CMS\\Install\\Updates\\LanguageSortingUpdate','i:1;'),(19,'installUpdate','TYPO3\\CMS\\Install\\Updates\\Typo3DbExtractionUpdate','i:1;'),(20,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FuncExtractionUpdate','i:1;'),(21,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigrateUrlTypesInPagesUpdate','i:1;'),(22,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SeparateSysHistoryFromSysLogUpdate','i:1;'),(23,'installUpdate','TYPO3\\CMS\\Install\\Updates\\RedirectExtractionUpdate','i:1;'),(24,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendUserStartModuleUpdate','i:1;'),(25,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigratePagesLanguageOverlayUpdate','i:1;'),(26,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigratePagesLanguageOverlayBeGroupsAccessRights','i:1;'),(27,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendLayoutIconUpdateWizard','i:1;'),(28,'installUpdate','TYPO3\\CMS\\Install\\Updates\\RedirectsExtensionUpdate','i:1;'),(29,'installUpdate','TYPO3\\CMS\\Install\\Updates\\AdminPanelInstall','i:1;'),(30,'installUpdate','TYPO3\\CMS\\Install\\Updates\\PopulatePageSlugs','i:1;'),(31,'installUpdate','TYPO3\\CMS\\Install\\Updates\\Argon2iPasswordHashes','i:1;'),(32,'installUpdate','TYPO3\\CMS\\Form\\Hooks\\FormFileExtensionUpdate','i:1;'),(34,'extensionDataImport','typo3conf/ext/news/ext_tables_static+adt.sql','s:0:\"\";'),(35,'extensionDataImport','typo3conf/ext/bootstrap_package/ext_tables_static+adt.sql','s:0:\"\";'),(36,'extensionDataImport','typo3conf/ext/vhs/ext_tables_static+adt.sql','s:0:\"\";'),(37,'extensionDataImport','typo3conf/ext/gridelements/ext_tables_static+adt.sql','s:0:\"\";'),(38,'extensionDataImport','typo3conf/ext/slickcarousel/ext_tables_static+adt.sql','s:0:\"\";'),(39,'extensionDataImport','typo3conf/ext/ws_flexslider/ext_tables_static+adt.sql','s:0:\"\";'),(40,'extensionDataImport','typo3/sysext/indexed_search/ext_tables_static+adt.sql','s:0:\"\";'),(41,'extensionDataImport','typo3conf/ext/user_customer/Initialisation/Files','i:1;'),(42,'extensionDataImport','typo3conf/ext/user_customer/ext_tables_static+adt.sql','s:0:\"\";'),(43,'extensionDataImport','typo3conf/ext/pizpalue/Initialisation/Files','i:1;'),(44,'extensionDataImport','typo3conf/ext/pizpalue/ext_tables_static+adt.sql','s:0:\"\";'),(45,'extensionDataImport','typo3conf/ext/pizpalue/Initialisation/dataImported','i:1;'),(46,'extensionDataImport','typo3conf/ext/timelog/ext_tables_static+adt.sql','s:0:\"\";'),(47,'extensionDataImport','typo3/sysext/feedit/ext_tables_static+adt.sql','s:0:\"\";'),(48,'extensionDataImport','typo3conf/ext/frontend_editing/ext_tables_static+adt.sql','s:0:\"\";'),(49,'extensionDataImport','typo3conf/ext/tt_address/ext_tables_static+adt.sql','s:0:\"\";'),(56,'languagePacks','baseUrl','s:33:\"https://localize.typo3.org/xliff/\";'),(57,'languagePacks','de-pizpalue','i:1585553744;'),(58,'languagePacks','de-slickcarousel','i:1585553744;'),(59,'languagePacks','de-timelog','i:1585553747;'),(60,'languagePacks','de-ws_flexslider','i:1585553747;'),(61,'languagePacks','de','i:1624432022;'),(62,'extensionDataImport','typo3conf/ext/auxlibs/ext_tables_static+adt.sql','s:0:\"\";'),(64,'extensionDataImport','typo3conf/ext/extension_builder/ext_tables_static+adt.sql','s:0:\"\";'),(65,'extensionDataImport','typo3/sysext/seo/ext_tables_static+adt.sql','s:0:\"\";'),(66,'extensionDataImport','typo3conf/ext/flux/ext_tables_static+adt.sql','s:0:\"\";'),(67,'extensionDataImport','typo3conf/ext/ppflux/ext_tables_static+adt.sql','s:0:\"\";'),(68,'extensionDataImport','typo3conf/ext/flux_element/ext_tables_static+adt.sql','s:0:\"\";'),(69,'extensionDataImport','typo3conf/ext/flux_elements/ext_tables_static+adt.sql','s:0:\"\";'),(70,'languagePacks','de-flux_elements','i:1585553741;'),(71,'languagePacks','de-user_customer','i:1585553747;'),(73,'extensionDataImport','typo3conf/ext/pp_gridelements/ext_tables_static+adt.sql','s:0:\"\";'),(74,'extensionDataImport','typo3conf/ext/books/ext_tables_static+adt.sql','s:0:\"\";'),(75,'extensionDataImport','typo3conf/ext/pizpalue_distribution/ext_tables_static+adt.sql','s:0:\"\";'),(76,'extensionDataImport','typo3conf/ext/pizpalue_distribution/Initialisation/dataImported','i:1;'),(77,'extensionDataImport','typo3/sysext/setup/ext_tables_static+adt.sql','s:0:\"\";'),(78,'extensionDataImport','typo3conf/ext/delme/ext_tables_static+adt.sql','s:0:\"\";'),(79,'installUpdate','TYPO3\\CMS\\Install\\Updates\\RsaauthExtractionUpdate','i:1;'),(80,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FeeditExtractionUpdate','i:1;'),(81,'installUpdate','TYPO3\\CMS\\Install\\Updates\\TaskcenterExtractionUpdate','i:1;'),(82,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysActionExtractionUpdate','i:1;'),(83,'siteConfigImport','default','i:1;'),(84,'extensionDataImport','typo3conf/ext/di_examples/ext_tables_static+adt.sql','s:0:\"\";'),(85,'extensionDataImport','typo3conf/ext/user_pizpalue/Initialisation/Files','i:1;'),(86,'extensionDataImport','typo3conf/ext/user_pizpalue/ext_tables_static+adt.sql','s:0:\"\";'),(87,'extensionDataImport','typo3conf/ext/container/ext_tables_static+adt.sql','s:0:\"\";'),(88,'extensionDataImport','typo3conf/ext/container_elements/ext_tables_static+adt.sql','s:0:\"\";'),(89,'extensionDataImport','typo3conf/ext/wasist/ext_tables_static+adt.sql','s:0:\"\";'),(90,'extensionDataImport','typo3conf/ext/realer/ext_tables_static+adt.sql','s:0:\"\";'),(91,'extensionDataImport','typo3/sysext/t3editor/ext_tables_static+adt.sql','s:0:\"\";'),(92,'extensionDataImport','typo3conf/ext/eventnews/ext_tables_static+adt.sql','s:0:\"\";'),(101,'extensionDataImport','typo3conf/ext/vinfo/ext_tables_static+adt.sql','s:0:\"\";'),(102,'extensionDataImport','typo3conf/ext/vinfo/Initialisation/Files','i:1;'),(105,'core','formProtectionSessionToken:3','s:64:\"623f02b0171e0daa5a58d2e763ac4372456dc32f393d301d3bcb4ef766c304a9\";'),(106,'core','formProtectionSessionToken:4','s:64:\"0bd617c9bc8cb1bc7ec8ed24d8ea30cbfb19cc5b6ea3dde626c79cfc1c02a9ba\";'),(108,'extensionDataImport','typo3conf/ext/typoscript_rendering/ext_tables_static+adt.sql','s:0:\"\";'),(109,'extensionDataImport','typo3conf/ext/bookmark_pages/ext_tables_static+adt.sql','s:0:\"\";'),(110,'extensionDataImport','typo3/sysext/felogin/ext_tables_static+adt.sql','s:0:\"\";'),(111,'extensionDataImport','typo3conf/ext/powermail/ext_tables_static+adt.sql','s:0:\"\";'),(112,'languagePacks','de-container','i:1624432017;'),(113,'languagePacks','de-bookmark_pages','i:1619683385;'),(114,'extensionDataImport','typo3conf/ext/grevman/ext_tables_static+adt.sql','s:0:\"\";'),(115,'languagePacks','de-grevman','i:1624432019;'),(116,'languagePacks','de-user_pizpalue','i:1624432022;'),(117,'languagePacks','de-wasist','i:1624432022;'),(118,'extensionDataImport','typo3conf/ext/user_grevman/ext_tables_static+adt.sql','s:0:\"\";'),(119,'extensionDataImport','typo3/sysext/recycler/ext_tables_static+adt.sql','s:0:\"\";'),(123,'core','formProtectionSessionToken:1','s:64:\"f423e039047c64f96ec61223606d00c60d9927140f9f6445b9124c4922738b56\";'),(124,'extensionDataImport','typo3conf/ext/femanager/ext_tables_static+adt.sql','s:0:\"\";'),(125,'extensionDataImport','typo3conf/ext/grevman/Initialisation/Files','i:1;'),(126,'core','sys_refindex_lastUpdate','i:1634550263;'),(127,'extensionDataImport','typo3/sysext/scheduler/ext_tables_static+adt.sql','s:0:\"\";'),(128,'tx_scheduler','lastRun','a:3:{s:5:\"start\";i:1634550227;s:3:\"end\";i:1634550227;s:4:\"type\";s:6:\"manual\";}'),(129,'extensionDataImport','typo3conf/ext/pvh/ext_tables_static+adt.sql','s:0:\"\";');
/*!40000 ALTER TABLE `sys_registry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_template`
--

DROP TABLE IF EXISTS `sys_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_template` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `sitetitle` varchar(255) NOT NULL DEFAULT '',
  `root` smallint(5) unsigned NOT NULL DEFAULT 0,
  `clear` smallint(5) unsigned NOT NULL DEFAULT 0,
  `include_static_file` text DEFAULT NULL,
  `constants` text DEFAULT NULL,
  `config` text DEFAULT NULL,
  `basedOn` tinytext DEFAULT NULL,
  `includeStaticAfterBasedOn` smallint(5) unsigned NOT NULL DEFAULT 0,
  `static_file_mode` smallint(5) unsigned NOT NULL DEFAULT 0,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `roottemplate` (`deleted`,`hidden`,`root`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_template`
--

LOCK TABLES `sys_template` WRITE;
/*!40000 ALTER TABLE `sys_template` DISABLE KEYS */;
INSERT INTO `sys_template` VALUES (3,1,1639215659,1550653971,1,0,0,0,0,256,'',0,0,0,0,0,0,0,0,'Pizpalue','',1,3,'EXT:bootstrap_package/Configuration/TypoScript,EXT:form/Configuration/TypoScript/,EXT:pizpalue/Configuration/TypoScript/Main','pizpalue.agency.siteMode = 1\npage.theme.contact.button.pageUid = 0','','',0,0,2),(27,223,1639124295,1624374369,1,0,0,0,0,256,NULL,0,0,0,0,0,0,0,0,'+ext','',0,0,'EXT:grevman/Configuration/TypoScript','plugin.tx_grevman_events.settings.event.list.displayDays = 360\r\nplugin.tx_grevman_events.settings.general.timeZone = Europe/Zurich',NULL,'',0,0,0);
/*!40000 ALTER TABLE `sys_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tt_content`
--

DROP TABLE IF EXISTS `tt_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tt_content` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rowDescription` text DEFAULT NULL,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l18n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l18n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `CType` varchar(255) NOT NULL DEFAULT '',
  `header` varchar(255) NOT NULL DEFAULT '',
  `header_position` varchar(255) NOT NULL DEFAULT '',
  `bodytext` mediumtext DEFAULT NULL,
  `bullets_type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_description` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `assets` int(10) unsigned NOT NULL DEFAULT 0,
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `imagewidth` int(10) unsigned NOT NULL DEFAULT 0,
  `imageorient` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imagecols` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imageborder` smallint(5) unsigned NOT NULL DEFAULT 0,
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` varchar(255) NOT NULL DEFAULT '',
  `frame_class` varchar(60) NOT NULL DEFAULT 'default',
  `cols` int(10) unsigned NOT NULL DEFAULT 0,
  `space_before_class` varchar(60) NOT NULL DEFAULT '',
  `space_after_class` varchar(60) NOT NULL DEFAULT '',
  `records` text DEFAULT NULL,
  `pages` text DEFAULT NULL,
  `colPos` int(10) unsigned NOT NULL DEFAULT 0,
  `subheader` varchar(255) NOT NULL DEFAULT '',
  `header_link` varchar(1024) NOT NULL DEFAULT '',
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  `header_layout` varchar(30) NOT NULL DEFAULT '0',
  `list_type` varchar(255) NOT NULL DEFAULT '',
  `sectionIndex` smallint(5) unsigned NOT NULL DEFAULT 0,
  `linkToTop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `file_collections` text DEFAULT NULL,
  `filelink_size` smallint(5) unsigned NOT NULL DEFAULT 0,
  `filelink_sorting` varchar(64) NOT NULL DEFAULT '',
  `filelink_sorting_direction` varchar(4) NOT NULL DEFAULT '',
  `target` varchar(30) NOT NULL DEFAULT '',
  `date` int(10) unsigned NOT NULL DEFAULT 0,
  `recursive` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imageheight` int(10) unsigned NOT NULL DEFAULT 0,
  `pi_flexform` mediumtext DEFAULT NULL,
  `accessibility_title` varchar(30) NOT NULL DEFAULT '',
  `accessibility_bypass` smallint(5) unsigned NOT NULL DEFAULT 0,
  `accessibility_bypass_text` varchar(30) NOT NULL DEFAULT '',
  `selected_categories` text DEFAULT NULL,
  `category_field` varchar(64) NOT NULL DEFAULT '',
  `table_class` varchar(60) NOT NULL DEFAULT '',
  `table_caption` varchar(255) DEFAULT NULL,
  `table_delimiter` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_enclosure` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_header_position` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_tfoot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `categories` int(11) NOT NULL DEFAULT 0,
  `teaser` text DEFAULT NULL,
  `readmore_label` varchar(255) NOT NULL DEFAULT '',
  `quote_source` varchar(255) NOT NULL DEFAULT '',
  `quote_link` varchar(1024) NOT NULL DEFAULT '',
  `panel_class` varchar(60) NOT NULL DEFAULT 'default',
  `file_folder` text DEFAULT NULL,
  `icon` varchar(255) NOT NULL DEFAULT '',
  `icon_set` varchar(255) NOT NULL DEFAULT '',
  `icon_file` int(10) unsigned DEFAULT 0,
  `icon_position` varchar(255) NOT NULL DEFAULT '',
  `icon_size` varchar(60) NOT NULL DEFAULT 'default',
  `icon_type` varchar(60) NOT NULL DEFAULT 'default',
  `icon_color` varchar(255) NOT NULL DEFAULT '',
  `icon_background` varchar(255) NOT NULL DEFAULT '',
  `external_media_source` varchar(1024) NOT NULL DEFAULT '',
  `external_media_ratio` varchar(10) NOT NULL DEFAULT '',
  `tx_bootstrappackage_card_group_item` int(10) unsigned DEFAULT 0,
  `tx_bootstrappackage_carousel_item` int(10) unsigned DEFAULT 0,
  `tx_bootstrappackage_accordion_item` int(10) unsigned DEFAULT 0,
  `tx_bootstrappackage_icon_group_item` int(10) unsigned DEFAULT 0,
  `tx_bootstrappackage_tab_item` int(10) unsigned DEFAULT 0,
  `tx_bootstrappackage_timeline_item` int(10) unsigned DEFAULT 0,
  `background_color_class` varchar(255) NOT NULL DEFAULT '',
  `background_image` int(10) unsigned DEFAULT 0,
  `background_image_options` mediumtext DEFAULT NULL,
  `tx_pizpalue_classes` varchar(255) NOT NULL DEFAULT '',
  `tx_pizpalue_style` text DEFAULT NULL,
  `tx_pizpalue_attributes` varchar(255) NOT NULL DEFAULT '',
  `tx_pizpalue_animation` varchar(255) NOT NULL DEFAULT '',
  `tx_pizpalue_image_variants` varchar(255) NOT NULL DEFAULT 'variants',
  `tx_pizpalue_image_scaling` text DEFAULT NULL,
  `tx_pizpalue_layout_breakpoint` varchar(15) NOT NULL DEFAULT '',
  `aspect_ratio` varchar(255) NOT NULL DEFAULT '1.3333333333333',
  `items_per_page` int(10) unsigned DEFAULT 10,
  `tx_pizpalue_background_image_variants` varchar(255) NOT NULL DEFAULT 'pageVariants',
  `tx_container_parent` int(11) NOT NULL DEFAULT 0,
  `tx_pizpalue_header_class` varchar(255) NOT NULL DEFAULT '',
  `tx_pizpalue_subheader_class` varchar(255) NOT NULL DEFAULT '',
  `tx_pizpalue_image_aspect_ratio` text DEFAULT NULL,
  `frame_layout` varchar(255) NOT NULL DEFAULT 'default',
  `frame_options` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`sorting`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l18n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`),
  KEY `container_parent` (`tx_container_parent`)
) ENGINE=InnoDB AUTO_INCREMENT=1035 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tt_content`
--

LOCK TABLES `tt_content` WRITE;
/*!40000 ALTER TABLE `tt_content` DISABLE KEYS */;
INSERT INTO `tt_content` VALUES (344,NULL,1,1634545047,1550653971,1,0,0,0,0,'',2624,0,0,0,0,NULL,0,'a:37:{s:5:\"CType\";N;s:6:\"colPos\";N;s:19:\"tx_container_parent\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:24:\"tx_pizpalue_header_class\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:27:\"tx_pizpalue_subheader_class\";N;s:8:\"bodytext\";N;s:6:\"layout\";N;s:29:\"tx_pizpalue_layout_breakpoint\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:11:\"frame_class\";N;s:12:\"frame_layout\";N;s:13:\"frame_options\";N;s:22:\"background_color_class\";N;s:16:\"background_image\";N;s:24:\"background_image_options\";N;s:37:\"tx_pizpalue_background_image_variants\";N;s:21:\"tx_pizpalue_animation\";N;s:19:\"tx_pizpalue_classes\";N;s:17:\"tx_pizpalue_style\";N;s:22:\"tx_pizpalue_attributes\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,'text','Kundeninfo','','<p><strong>###ppCustomerCompany###</strong><br /> ###ppCustomerContactAddress###<br /> ###ppCustomerContactZip### ###ppCustomerContactCity###</p>',0,0,0,0,0,0,0,1,0,0,'0','default',0,'','','','',10,'','',0,'100','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,207,0,'','','','','default','','','',0,'0','default','default','','','','',0,0,0,0,0,0,'none',0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"parallax\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fade\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"filter\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"behaviour\">\n                    <value index=\"vDEF\">cover</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','','','','0','variants',NULL,'','1.3333333333333',10,'pageVariants',0,'none','none','0','default',''),(1014,'',223,1624372778,1624372778,1,0,0,0,0,'',256,0,0,0,0,NULL,0,'',0,0,0,0,0,0,0,'list','','',NULL,0,0,0,0,0,0,0,2,0,0,'0','default',0,'','',NULL,'',0,'','',0,'0','grevman_events',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0,NULL,'','','','default',NULL,'','',0,'','default','default','#FFFFFF','#333333','','',0,0,0,0,0,0,'none',0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"parallax\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fade\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"filter\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','','','','0','variants','xl: 1.0,\nlg: 1.0,\nmd: 1.0,\nsm: 1.0,\nxs: 1.0','','1.3333333333333',10,'pageVariants',0,'none','none','xl: 0,\nlg: 0,\nmd: 0,\nsm: 0,\nxs: 0','default',''),(1015,'',227,1624547430,1624547430,1,0,0,0,0,'',256,0,0,0,0,NULL,0,'',0,0,0,0,0,0,0,'login','','',NULL,0,0,0,0,0,0,0,2,0,0,'0','default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.showForgotPassword\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.showPermaLogin\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"settings.showLogoutFormAfterLogin\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.pages\">\n                    <value index=\"vDEF\">223</value>\n                </field>\n                <field index=\"settings.recursive\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"s_redirect\">\n            <language index=\"lDEF\">\n                <field index=\"settings.redirectMode\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.redirectFirstMethod\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.redirectPageLogin\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.redirectPageLoginError\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.redirectPageLogout\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.redirectDisable\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"s_messages\">\n            <language index=\"lDEF\">\n                <field index=\"settings.welcome_header\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.welcome_message\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.success_header\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.success_message\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.error_header\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.error_message\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.status_header\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.status_message\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.logout_header\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.logout_message\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.forgot_header\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.forgot_reset_message\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'',NULL,'','',NULL,124,0,0,0,0,0,NULL,'','','','default',NULL,'','',0,'','default','default','#FFFFFF','#333333','','',0,0,0,0,0,0,'none',0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"parallax\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fade\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"filter\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','','','','0','variants','xl: 1.0,\nlg: 1.0,\nmd: 1.0,\nsm: 1.0,\nxs: 1.0','','1.3333333333333',10,'pageVariants',0,'none','none','xl: 0,\nlg: 0,\nmd: 0,\nsm: 0,\nxs: 0','default',''),(1033,'',1,1633542717,1633542717,1,0,0,0,0,'',1312,0,0,0,0,NULL,0,'',0,0,0,0,0,0,0,'header','Grevman development site','center',NULL,0,0,0,0,0,0,0,1,0,0,'0','default',0,'','',NULL,NULL,0,'','',0,'1','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0,NULL,'','','','default',NULL,'','',0,'','default','default','#FFFFFF','#333333','','',0,0,0,0,0,0,'primary',0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"behaviour\">\n                    <value index=\"vDEF\">cover</value>\n                </field>\n                <field index=\"parallax\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fade\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"filter\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','','','','0','variants','xxl: 1.0,\nxl: 1.0,\nlg: 1.0,\nmd: 1.0,\nsm: 1.0,\nxs: 1.0','','1.3333333333333',10,'pageVariants',0,'none','none','xxl: 0,\nxl: 0,\nlg: 0,\nmd: 0,\nsm: 0,\nxs: 0','default',''),(1034,'',234,1639141369,1639141248,1,0,0,0,0,'',256,0,0,0,0,NULL,0,'a:40:{s:5:\"CType\";N;s:6:\"colPos\";N;s:19:\"tx_container_parent\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:24:\"tx_pizpalue_header_class\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:27:\"tx_pizpalue_subheader_class\";N;s:9:\"list_type\";N;s:26:\"tx_pizpalue_image_variants\";N;s:5:\"pages\";N;s:9:\"recursive\";N;s:6:\"layout\";N;s:29:\"tx_pizpalue_layout_breakpoint\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:11:\"frame_class\";N;s:12:\"frame_layout\";N;s:13:\"frame_options\";N;s:22:\"background_color_class\";N;s:16:\"background_image\";N;s:24:\"background_image_options\";N;s:37:\"tx_pizpalue_background_image_variants\";N;s:21:\"tx_pizpalue_animation\";N;s:19:\"tx_pizpalue_classes\";N;s:17:\"tx_pizpalue_style\";N;s:22:\"tx_pizpalue_attributes\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,'list','','',NULL,0,0,0,0,0,0,0,1,0,0,'0','default',0,'','',NULL,'',0,'','',0,'0','grevman_messenger',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0,NULL,'','','','default',NULL,'','',0,'','default','default','#FFFFFF','#333333','','',0,0,0,0,0,0,'none',0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"behaviour\">\n                    <value index=\"vDEF\">cover</value>\n                </field>\n                <field index=\"parallax\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fade\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"filter\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','','','','0','variants','xxl: 1.0,\nxl: 1.0,\nlg: 1.0,\nmd: 1.0,\nsm: 1.0,\nxs: 1.0','','1.3333333333333',10,'pageVariants',0,'none','none','xxl: 0,\nxl: 0,\nlg: 0,\nmd: 0,\nsm: 0,\nxs: 0','default','');
/*!40000 ALTER TABLE `tt_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_bootstrappackage_accordion_item`
--

DROP TABLE IF EXISTS `tx_bootstrappackage_accordion_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_bootstrappackage_accordion_item` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) NOT NULL DEFAULT '',
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `tt_content` int(10) unsigned DEFAULT 0,
  `header` varchar(255) NOT NULL DEFAULT '',
  `bodytext` text DEFAULT NULL,
  `media` int(10) unsigned DEFAULT 0,
  `mediaorient` varchar(60) NOT NULL DEFAULT 'left',
  `imagecols` smallint(5) unsigned NOT NULL DEFAULT 1,
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l10n_parent`,`sys_language_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_bootstrappackage_accordion_item`
--

LOCK TABLES `tx_bootstrappackage_accordion_item` WRITE;
/*!40000 ALTER TABLE `tx_bootstrappackage_accordion_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_bootstrappackage_accordion_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_bootstrappackage_card_group_item`
--

DROP TABLE IF EXISTS `tx_bootstrappackage_card_group_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_bootstrappackage_card_group_item` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) NOT NULL DEFAULT '',
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `tt_content` int(10) unsigned DEFAULT 0,
  `header` varchar(255) NOT NULL DEFAULT '',
  `subheader` varchar(255) NOT NULL DEFAULT '',
  `image` int(11) NOT NULL DEFAULT 0,
  `bodytext` text DEFAULT NULL,
  `link` varchar(1024) NOT NULL DEFAULT '',
  `link_title` varchar(255) NOT NULL DEFAULT '',
  `link_icon` int(10) unsigned DEFAULT 0,
  `link_class` varchar(255) NOT NULL DEFAULT '',
  `link_icon_set` varchar(255) NOT NULL DEFAULT '',
  `link_icon_identifier` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l10n_parent`,`sys_language_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_bootstrappackage_card_group_item`
--

LOCK TABLES `tx_bootstrappackage_card_group_item` WRITE;
/*!40000 ALTER TABLE `tx_bootstrappackage_card_group_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_bootstrappackage_card_group_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_bootstrappackage_carousel_item`
--

DROP TABLE IF EXISTS `tx_bootstrappackage_carousel_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_bootstrappackage_carousel_item` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) NOT NULL DEFAULT '',
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `tt_content` int(10) unsigned DEFAULT 0,
  `item_type` varchar(255) NOT NULL DEFAULT '',
  `header` varchar(255) NOT NULL DEFAULT '',
  `header_layout` smallint(5) unsigned NOT NULL DEFAULT 1,
  `header_class` varchar(255) NOT NULL DEFAULT '',
  `subheader` varchar(255) NOT NULL DEFAULT '',
  `subheader_layout` smallint(5) unsigned NOT NULL DEFAULT 2,
  `subheader_class` varchar(255) NOT NULL DEFAULT '',
  `nav_title` varchar(255) NOT NULL DEFAULT '',
  `button_text` varchar(255) NOT NULL DEFAULT '',
  `bodytext` text DEFAULT NULL,
  `image` int(10) unsigned DEFAULT 0,
  `link` varchar(1024) NOT NULL DEFAULT '',
  `text_color` varchar(255) NOT NULL DEFAULT '',
  `background_color` varchar(255) NOT NULL DEFAULT '',
  `background_image` int(10) unsigned DEFAULT 0,
  `background_image_options` mediumtext DEFAULT NULL,
  `header_position` varchar(255) NOT NULL DEFAULT 'center',
  `layout` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l10n_parent`,`sys_language_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_bootstrappackage_carousel_item`
--

LOCK TABLES `tx_bootstrappackage_carousel_item` WRITE;
/*!40000 ALTER TABLE `tx_bootstrappackage_carousel_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_bootstrappackage_carousel_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_bootstrappackage_icon_group_item`
--

DROP TABLE IF EXISTS `tx_bootstrappackage_icon_group_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_bootstrappackage_icon_group_item` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) NOT NULL DEFAULT '',
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `tt_content` int(10) unsigned DEFAULT 0,
  `header` varchar(255) NOT NULL DEFAULT '',
  `subheader` varchar(255) NOT NULL DEFAULT '',
  `icon_file` int(10) unsigned DEFAULT 0,
  `link` varchar(1024) NOT NULL DEFAULT '',
  `bodytext` text DEFAULT NULL,
  `icon_set` varchar(255) NOT NULL DEFAULT '',
  `icon_identifier` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l10n_parent`,`sys_language_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_bootstrappackage_icon_group_item`
--

LOCK TABLES `tx_bootstrappackage_icon_group_item` WRITE;
/*!40000 ALTER TABLE `tx_bootstrappackage_icon_group_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_bootstrappackage_icon_group_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_bootstrappackage_tab_item`
--

DROP TABLE IF EXISTS `tx_bootstrappackage_tab_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_bootstrappackage_tab_item` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) NOT NULL DEFAULT '',
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `tt_content` int(10) unsigned DEFAULT 0,
  `header` varchar(255) NOT NULL DEFAULT '',
  `bodytext` text DEFAULT NULL,
  `media` int(10) unsigned DEFAULT 0,
  `mediaorient` varchar(60) NOT NULL DEFAULT 'left',
  `imagecols` smallint(5) unsigned NOT NULL DEFAULT 1,
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l10n_parent`,`sys_language_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_bootstrappackage_tab_item`
--

LOCK TABLES `tx_bootstrappackage_tab_item` WRITE;
/*!40000 ALTER TABLE `tx_bootstrappackage_tab_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_bootstrappackage_tab_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_bootstrappackage_timeline_item`
--

DROP TABLE IF EXISTS `tx_bootstrappackage_timeline_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_bootstrappackage_timeline_item` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) NOT NULL DEFAULT '',
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `tt_content` int(10) unsigned DEFAULT 0,
  `date` datetime DEFAULT NULL,
  `header` varchar(255) NOT NULL DEFAULT '',
  `bodytext` text DEFAULT NULL,
  `icon_file` int(10) unsigned DEFAULT 0,
  `image` int(10) unsigned DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `icon_set` varchar(255) NOT NULL DEFAULT '',
  `icon_identifier` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l10n_parent`,`sys_language_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_bootstrappackage_timeline_item`
--

LOCK TABLES `tx_bootstrappackage_timeline_item` WRITE;
/*!40000 ALTER TABLE `tx_bootstrappackage_timeline_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_bootstrappackage_timeline_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_extensionmanager_domain_model_extension`
--

DROP TABLE IF EXISTS `tx_extensionmanager_domain_model_extension`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_extensionmanager_domain_model_extension` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `extension_key` varchar(60) NOT NULL DEFAULT '',
  `repository` int(10) unsigned NOT NULL DEFAULT 1,
  `version` varchar(15) NOT NULL DEFAULT '',
  `alldownloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `downloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(150) NOT NULL DEFAULT '',
  `description` mediumtext DEFAULT NULL,
  `state` int(11) NOT NULL DEFAULT 0,
  `review_state` int(11) NOT NULL DEFAULT 0,
  `category` int(11) NOT NULL DEFAULT 0,
  `last_updated` int(10) unsigned NOT NULL DEFAULT 0,
  `serialized_dependencies` mediumtext DEFAULT NULL,
  `author_name` varchar(255) NOT NULL DEFAULT '',
  `author_email` varchar(255) NOT NULL DEFAULT '',
  `ownerusername` varchar(50) NOT NULL DEFAULT '',
  `md5hash` varchar(35) NOT NULL DEFAULT '',
  `update_comment` mediumtext DEFAULT NULL,
  `authorcompany` varchar(255) NOT NULL DEFAULT '',
  `integer_version` int(11) NOT NULL DEFAULT 0,
  `current_version` int(11) NOT NULL DEFAULT 0,
  `lastreviewedversion` int(11) NOT NULL DEFAULT 0,
  `documentation_link` varchar(2048) DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `versionextrepo` (`extension_key`,`version`,`repository`),
  KEY `index_extrepo` (`extension_key`,`repository`),
  KEY `index_versionrepo` (`integer_version`,`repository`,`extension_key`),
  KEY `index_currentversions` (`current_version`,`review_state`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_extensionmanager_domain_model_extension`
--

LOCK TABLES `tx_extensionmanager_domain_model_extension` WRITE;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_extensionmanager_domain_model_repository`
--

DROP TABLE IF EXISTS `tx_extensionmanager_domain_model_repository`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_extensionmanager_domain_model_repository` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(150) NOT NULL DEFAULT '',
  `description` mediumtext DEFAULT NULL,
  `wsdl_url` varchar(100) NOT NULL DEFAULT '',
  `mirror_list_url` varchar(100) NOT NULL DEFAULT '',
  `last_update` int(10) unsigned NOT NULL DEFAULT 0,
  `extension_count` int(11) NOT NULL DEFAULT 0,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_extensionmanager_domain_model_repository`
--

LOCK TABLES `tx_extensionmanager_domain_model_repository` WRITE;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_repository` DISABLE KEYS */;
INSERT INTO `tx_extensionmanager_domain_model_repository` VALUES (1,'TYPO3.org Main Repository','Main repository on typo3.org. This repository has some mirrors configured which are available with the mirror url.','https://typo3.org/wsdl/tx_ter_wsdl.php','https://repositories.typo3.org/mirrors.xml.gz',1624267671,1806,0);
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_repository` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_grevman_domain_model_event`
--

DROP TABLE IF EXISTS `tx_grevman_domain_model_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_grevman_domain_model_event` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `member_groups` int(10) unsigned NOT NULL DEFAULT 0,
  `registrations` varchar(2000) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `notes` int(10) unsigned NOT NULL DEFAULT 0,
  `guests` int(10) unsigned NOT NULL DEFAULT 0,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `startdate` int(11) NOT NULL DEFAULT 0,
  `enddate` int(11) NOT NULL DEFAULT 0,
  `teaser` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` double NOT NULL DEFAULT 0,
  `link` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `program` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `images` int(10) unsigned NOT NULL DEFAULT 0,
  `files` int(10) unsigned NOT NULL DEFAULT 0,
  `parent` int(10) unsigned DEFAULT 0,
  `enable_recurrence` smallint(6) NOT NULL DEFAULT 0,
  `recurrence_enddate` int(11) NOT NULL DEFAULT 0,
  `recurrence_rule` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `recurrence_dates` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recurrence_exception_dates` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recurrence_set` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_grevman_domain_model_event`
--

LOCK TABLES `tx_grevman_domain_model_event` WRITE;
/*!40000 ALTER TABLE `tx_grevman_domain_model_event` DISABLE KEYS */;
INSERT INTO `tx_grevman_domain_model_event` VALUES (1,224,1645092224,1624338623,1,0,0,0,0,NULL,'a:24:{s:5:\"title\";N;s:4:\"slug\";N;s:9:\"startdate\";N;s:7:\"enddate\";N;s:6:\"teaser\";N;s:11:\"description\";N;s:7:\"program\";N;s:4:\"link\";N;s:8:\"location\";N;s:5:\"price\";N;s:6:\"images\";N;s:5:\"files\";N;s:13:\"member_groups\";N;s:13:\"registrations\";N;s:5:\"notes\";N;s:6:\"guests\";N;s:17:\"enable_recurrence\";N;s:18:\"recurrence_enddate\";N;s:15:\"recurrence_rule\";N;s:16:\"recurrence_dates\";N;s:26:\"recurrence_exception_dates\";N;s:14:\"recurrence_set\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;}',0,0,0,0,0,0,0,'Event 1',1,'0',0,1,'event1',1638979680,0,'<p>This event defines a recurrence to obtain eventst in the summer and in the winter hence thwy are exposed to daylight saving time changes. This event defines a recurrence to obtain eventst in the summer and in the winter hence thwy are exposed to daylight saving time changes.</p>','<p>Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here.</p>\r\n<p>Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here.</p>',50,'https://www.diemtigtal.ch/','<p>Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here</p>','Altes Schulhaus, Sportwil',1,1,0,1,0,'FREQ=WEEKLY','','',NULL),(2,224,1639127335,1624431427,1,0,1,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,'Event 2',1,'4',1,0,'event2',1639990800,1640084400,'<p>This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser.</p>','<p>This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description.</p>\r\n<p>This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description.</p>',0,'t3://page?uid=1','<p>This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program.</p>','Sunebühel',0,0,0,0,0,'',NULL,NULL,NULL),(43,224,1639126059,1639126013,1,1,0,0,0,NULL,'a:3:{s:5:\"title\";N;s:9:\"startdate\";N;s:7:\"enddate\";N;}',0,0,0,0,0,0,0,'Event 2',1,'0',0,0,'event2',1639990800,1640084400,'<p>This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser.</p>','<p>This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description.</p>\r\n<p>This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description.</p>',0,'t3://page?uid=1','<p>This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program.</p>','Sunebühel',0,0,0,0,0,'','','',''),(44,224,1639126835,1639126817,1,1,0,0,0,NULL,'a:3:{s:5:\"title\";N;s:9:\"startdate\";N;s:7:\"enddate\";N;}',0,0,0,0,0,0,0,'Event 2',1,'0',0,0,'event2',1639990800,1640084400,'<p>This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser.</p>','<p>This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description.</p>\r\n<p>This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description.</p>',0,'t3://page?uid=1','<p>This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program.</p>','Sunebühel',0,0,0,0,0,'','','',''),(45,224,1639127281,1639127038,1,1,0,0,0,NULL,'a:24:{s:5:\"title\";N;s:4:\"slug\";N;s:9:\"startdate\";N;s:7:\"enddate\";N;s:6:\"teaser\";N;s:11:\"description\";N;s:7:\"program\";N;s:4:\"link\";N;s:8:\"location\";N;s:5:\"price\";N;s:6:\"images\";N;s:5:\"files\";N;s:13:\"member_groups\";N;s:13:\"registrations\";N;s:5:\"notes\";N;s:6:\"guests\";N;s:17:\"enable_recurrence\";N;s:18:\"recurrence_enddate\";N;s:15:\"recurrence_rule\";N;s:16:\"recurrence_dates\";N;s:26:\"recurrence_exception_dates\";N;s:14:\"recurrence_set\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;}',0,0,0,0,0,0,0,'Event 1 copy',1,'1',0,1,'event1',1639411680,0,'<p>This event defines a recurrence to obtain eventst in the summer and in the winter hence thwy are exposed to daylight saving time changes. This event defines a recurrence to obtain eventst in the summer and in the winter hence thwy are exposed to daylight saving time changes.</p>','<p>Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here.</p>\r\n<p>Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here.</p>',50,'https://www.diemtigtal.ch/','<p>Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here</p>','Altes Schulhaus, Sportwil',1,1,0,1,0,'FREQ=MONTHLY;INTERVAL=3','01.07.22','06.07.22',''),(46,224,1644941267,1642609041,0,0,0,0,0,NULL,'',0,0,0,0,0,0,0,'Event 1',1,'2',0,0,'event1',1646755680,0,'<p>This event defines a recurrence to obtain eventst in the summer and in the winter hence thwy are exposed to daylight saving time changes. This event defines a recurrence to obtain eventst in the summer and in the winter hence thwy are exposed to daylight saving time changes.</p>','<p>Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here.</p>\r\n<p>Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here.</p>',50,'https://www.diemtigtal.ch/','<p>Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here</p>','Altes Schulhaus, Sportwil',1,1,1,0,0,'','','',''),(47,224,1642609089,1642609089,0,0,0,0,0,NULL,'',0,0,0,0,0,0,0,'Event 1',1,'1',0,0,'event1',1656688080,0,'<p>This event defines a recurrence to obtain eventst in the summer and in the winter hence thwy are exposed to daylight saving time changes. This event defines a recurrence to obtain eventst in the summer and in the winter hence thwy are exposed to daylight saving time changes.</p>','<p>Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here.</p>\r\n<p>Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here.</p>',50,'https://www.diemtigtal.ch/','<p>Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here</p>','Altes Schulhaus, Sportwil',1,1,1,0,0,'','','',''),(48,224,1642609484,1642609452,0,0,0,0,0,NULL,'',0,0,0,0,0,0,0,'Event 1',1,'1',1,0,'event1',1656688080,0,'<p>This event defines a recurrence to obtain eventst in the summer and in the winter hence thwy are exposed to daylight saving time changes. This event defines a recurrence to obtain eventst in the summer and in the winter hence thwy are exposed to daylight saving time changes.</p>','<p>Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here.</p>\r\n<p>Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here.</p>',50,'https://www.diemtigtal.ch/','<p>Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here</p>','Altes Schulhaus, Sportwil',1,1,1,0,0,'','','',''),(49,224,1642609504,1642609504,0,0,0,0,0,NULL,'',0,0,0,0,0,0,0,'Event 1',1,'1',0,0,'event1',1654700880,0,'<p>This event defines a recurrence to obtain eventst in the summer and in the winter hence thwy are exposed to daylight saving time changes. This event defines a recurrence to obtain eventst in the summer and in the winter hence thwy are exposed to daylight saving time changes.</p>','<p>Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here.</p>\r\n<p>Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here.</p>',50,'https://www.diemtigtal.ch/','<p>Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here</p>','Altes Schulhaus, Sportwil',1,1,1,0,0,'','','',''),(50,224,1645095814,1644999360,0,0,0,0,0,NULL,'a:19:{s:5:\"title\";N;s:4:\"slug\";N;s:9:\"startdate\";N;s:7:\"enddate\";N;s:6:\"teaser\";N;s:11:\"description\";N;s:7:\"program\";N;s:4:\"link\";N;s:8:\"location\";N;s:5:\"price\";N;s:6:\"images\";N;s:5:\"files\";N;s:13:\"member_groups\";N;s:13:\"registrations\";N;s:5:\"notes\";N;s:6:\"guests\";N;s:17:\"enable_recurrence\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;}',0,0,0,0,0,0,0,'Event 1',1,'156,157',4,0,'event1',1645027680,0,'<p>This event defines a recurrence to obtain eventst in the summer and in the winter hence thwy are exposed to daylight saving time changes. This event defines a recurrence to obtain eventst in the summer and in the winter hence thwy are exposed to daylight saving time changes.</p>','<p>Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here.</p>\r\n<p>Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here.</p>',50,'https://www.diemtigtal.ch/','<p>Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here</p>','Altes Schulhaus, Sportwil',1,1,1,0,0,'','','','');
/*!40000 ALTER TABLE `tx_grevman_domain_model_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_grevman_domain_model_group`
--

DROP TABLE IF EXISTS `tx_grevman_domain_model_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_grevman_domain_model_group` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `members` int(10) unsigned NOT NULL DEFAULT 0,
  `events` int(10) unsigned NOT NULL DEFAULT 0,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_grevman_domain_model_group`
--

LOCK TABLES `tx_grevman_domain_model_group` WRITE;
/*!40000 ALTER TABLE `tx_grevman_domain_model_group` DISABLE KEYS */;
INSERT INTO `tx_grevman_domain_model_group` VALUES (1,224,1634970534,1624338555,1,0,0,0,0,NULL,'a:5:{s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:4:\"name\";N;s:6:\"events\";N;s:7:\"members\";N;}',0,0,0,0,0,0,0,3,1,'Group 1'),(2,224,1634970546,1624431273,1,0,0,0,0,NULL,'a:5:{s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:4:\"name\";N;s:6:\"events\";N;s:7:\"members\";N;}',0,0,0,0,0,0,0,4,1,'Group 2');
/*!40000 ALTER TABLE `tx_grevman_domain_model_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_grevman_domain_model_guest`
--

DROP TABLE IF EXISTS `tx_grevman_domain_model_guest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_grevman_domain_model_guest` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_grevman_domain_model_guest`
--

LOCK TABLES `tx_grevman_domain_model_guest` WRITE;
/*!40000 ALTER TABLE `tx_grevman_domain_model_guest` DISABLE KEYS */;
INSERT INTO `tx_grevman_domain_model_guest` VALUES (1,224,1626764780,1624351729,1,0,0,0,0,0,0,NULL,'a:8:{s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:10:\"first_name\";N;s:9:\"last_name\";N;s:5:\"phone\";N;s:5:\"email\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;}',0,0,0,0,0,0,0,'Guest1','Last1','111','info@info.info');
/*!40000 ALTER TABLE `tx_grevman_domain_model_guest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_grevman_domain_model_note`
--

DROP TABLE IF EXISTS `tx_grevman_domain_model_note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_grevman_domain_model_note` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `event` int(10) unsigned NOT NULL DEFAULT 0,
  `text` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `member` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=144 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_grevman_domain_model_note`
--

LOCK TABLES `tx_grevman_domain_model_note` WRITE;
/*!40000 ALTER TABLE `tx_grevman_domain_model_note` DISABLE KEYS */;
INSERT INTO `tx_grevman_domain_model_note` VALUES (136,224,1645097068,1642609484,0,0,0,0,0,NULL,'',0,0,0,0,0,0,0,48,'A test note...',10),(137,224,1645097068,1645013281,0,0,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,50,'Meine erste Nachricht',10),(138,224,1645097068,1645013495,0,0,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,50,'Meine zweite Nachricht',10),(139,224,1645097068,1645014368,0,0,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,50,'Meine dritte Nachricht',10),(140,224,1645029945,1645014910,0,1,0,0,0,NULL,'',0,0,0,0,0,0,0,50,'Meine vierte Nachricht',14),(141,224,1645029961,1645017522,0,1,0,0,0,NULL,'',0,0,0,0,0,0,0,50,'Meine fünfte Nachricht',14),(142,224,1645095814,1645029982,0,0,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,50,'Eine weitere Notiz mir Veränderung mit Anpassung4',14),(143,224,1645032370,1645032360,0,1,0,0,0,NULL,'',0,0,0,0,0,0,0,50,'Eine neue Nachricht',14);
/*!40000 ALTER TABLE `tx_grevman_domain_model_note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_grevman_domain_model_registration`
--

DROP TABLE IF EXISTS `tx_grevman_domain_model_registration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_grevman_domain_model_registration` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `event` int(10) unsigned NOT NULL DEFAULT 0,
  `member` int(10) unsigned NOT NULL DEFAULT 0,
  `state` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=158 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_grevman_domain_model_registration`
--

LOCK TABLES `tx_grevman_domain_model_registration` WRITE;
/*!40000 ALTER TABLE `tx_grevman_domain_model_registration` DISABLE KEYS */;
INSERT INTO `tx_grevman_domain_model_registration` VALUES (150,224,1639127281,1639127183,0,1,0,0,0,NULL,'',0,0,0,0,0,0,0,45,10,6),(151,224,1645097068,1642609041,0,0,0,0,0,NULL,'',0,0,0,0,0,0,0,46,10,6),(152,224,1645097068,1642609089,0,0,0,0,0,NULL,'',0,0,0,0,0,0,0,47,10,6),(153,224,1645097068,1642609452,0,0,0,0,0,NULL,'',0,0,0,0,0,0,0,48,10,9),(154,224,1645097068,1642609504,0,0,0,0,0,NULL,'a:4:{s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:5:\"state\";N;s:6:\"member\";N;}',0,0,0,0,0,0,0,49,10,9),(155,224,1644941267,1644941267,0,0,0,0,0,NULL,'',0,0,0,0,0,0,0,46,11,6),(156,224,1645097068,1644999360,0,0,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,50,10,6),(157,224,1645095212,1645017492,0,0,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,50,14,9);
/*!40000 ALTER TABLE `tx_grevman_domain_model_registration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_grevman_event_group_mm`
--

DROP TABLE IF EXISTS `tx_grevman_event_group_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_grevman_event_group_mm` (
  `uid_local` int(10) unsigned NOT NULL DEFAULT 0,
  `uid_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid_local`,`uid_foreign`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_grevman_event_group_mm`
--

LOCK TABLES `tx_grevman_event_group_mm` WRITE;
/*!40000 ALTER TABLE `tx_grevman_event_group_mm` DISABLE KEYS */;
INSERT INTO `tx_grevman_event_group_mm` VALUES (1,1,1,1),(2,2,1,1),(3,1,1,0),(4,1,1,0),(5,1,1,0),(6,1,1,0),(7,1,1,0),(8,1,1,0),(9,1,1,0),(10,1,1,0),(11,1,1,0),(12,1,1,0),(13,1,1,0),(14,1,1,0),(15,1,1,0),(16,1,1,0),(17,1,1,0),(18,1,1,0),(19,1,1,0),(20,1,1,0),(21,1,1,0),(22,1,1,0),(23,1,1,0),(24,1,1,0),(25,1,1,0),(26,1,1,0),(27,1,1,0),(28,1,1,0),(29,1,1,0),(30,1,1,0),(31,1,1,0),(32,1,1,0),(33,1,1,0),(34,1,1,0),(35,1,1,0),(36,1,1,0),(37,1,1,0),(38,1,1,0),(39,1,1,0),(40,1,1,0),(41,1,1,0),(42,1,1,0),(43,2,1,0),(44,2,1,0),(45,1,1,0),(46,1,1,0),(47,1,1,0),(48,1,1,0),(49,1,1,0),(50,1,1,0);
/*!40000 ALTER TABLE `tx_grevman_event_group_mm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_grevman_event_guest_mm`
--

DROP TABLE IF EXISTS `tx_grevman_event_guest_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_grevman_event_guest_mm` (
  `uid_local` int(10) unsigned NOT NULL DEFAULT 0,
  `uid_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid_local`,`uid_foreign`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_grevman_event_guest_mm`
--

LOCK TABLES `tx_grevman_event_guest_mm` WRITE;
/*!40000 ALTER TABLE `tx_grevman_event_guest_mm` DISABLE KEYS */;
INSERT INTO `tx_grevman_event_guest_mm` VALUES (1,1,1,0),(42,1,1,0),(45,1,1,0);
/*!40000 ALTER TABLE `tx_grevman_event_guest_mm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_grevman_group_member_mm`
--

DROP TABLE IF EXISTS `tx_grevman_group_member_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_grevman_group_member_mm` (
  `uid_local` int(10) unsigned NOT NULL DEFAULT 0,
  `uid_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid_local`,`uid_foreign`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_grevman_group_member_mm`
--

LOCK TABLES `tx_grevman_group_member_mm` WRITE;
/*!40000 ALTER TABLE `tx_grevman_group_member_mm` DISABLE KEYS */;
INSERT INTO `tx_grevman_group_member_mm` VALUES (1,10,1,1),(1,11,2,1),(1,14,3,1),(2,11,1,2),(2,12,2,0),(2,13,3,0),(2,15,4,1);
/*!40000 ALTER TABLE `tx_grevman_group_member_mm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_impexp_presets`
--

DROP TABLE IF EXISTS `tx_impexp_presets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_impexp_presets` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_uid` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `public` smallint(6) NOT NULL DEFAULT 0,
  `item_uid` int(11) NOT NULL DEFAULT 0,
  `preset_data` blob DEFAULT NULL,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `lookup` (`item_uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_impexp_presets`
--

LOCK TABLES `tx_impexp_presets` WRITE;
/*!40000 ALTER TABLE `tx_impexp_presets` DISABLE KEYS */;
INSERT INTO `tx_impexp_presets` VALUES (1,1,'grevman-test',1,0,'a:15:{s:8:\"pagetree\";a:3:{s:2:\"id\";s:1:\"0\";s:6:\"levels\";s:3:\"999\";s:6:\"tables\";a:9:{i:0;s:14:\"backend_layout\";i:1;s:9:\"be_groups\";i:2;s:8:\"be_users\";i:3;s:9:\"fe_groups\";i:4;s:8:\"fe_users\";i:5;s:12:\"sys_language\";i:6;s:12:\"sys_template\";i:7;s:10:\"tt_content\";i:8;s:29:\"tx_grevman_domain_model_event\";}}s:12:\"external_ref\";a:1:{s:6:\"tables\";a:1:{i:0;s:4:\"_ALL\";}}s:15:\"external_static\";a:1:{s:6:\"tables\";s:0:\"\";}s:19:\"showStaticRelations\";s:0:\"\";s:15:\"excludeDisabled\";s:1:\"1\";s:20:\"download_export_name\";s:14:\"tree_PID0_L999\";s:6:\"preset\";a:2:{s:5:\"title\";s:12:\"grevman-test\";s:6:\"public\";i:1;}s:4:\"meta\";a:3:{s:5:\"title\";s:0:\"\";s:11:\"description\";s:0:\"\";s:5:\"notes\";s:0:\"\";}s:8:\"filetype\";s:3:\"xml\";s:8:\"filename\";s:0:\"\";s:24:\"excludeHTMLfileResources\";s:0:\"\";s:26:\"saveFilesOutsideExportFile\";s:0:\"\";s:13:\"extension_dep\";s:0:\"\";s:10:\"softrefCfg\";a:2:{s:32:\"1c8d070c152eeab20233c19daf5679df\";a:1:{s:4:\"mode\";s:0:\"\";}s:32:\"f992614796c62361b6d1a023a4f61baa\";a:1:{s:4:\"mode\";s:0:\"\";}}s:7:\"exclude\";a:0:{}}',0,1634550886,1634550886),(2,1,'grevman-test-static',1,0,'a:15:{s:8:\"pagetree\";a:3:{s:2:\"id\";s:1:\"0\";s:6:\"levels\";s:3:\"999\";s:6:\"tables\";a:18:{i:0;s:14:\"backend_layout\";i:1;s:9:\"be_groups\";i:2;s:8:\"be_users\";i:3;s:9:\"fe_groups\";i:4;s:8:\"fe_users\";i:5;s:8:\"sys_file\";i:6;s:17:\"sys_file_metadata\";i:7;s:18:\"sys_file_reference\";i:8;s:16:\"sys_file_storage\";i:9;s:14:\"sys_filemounts\";i:10;s:12:\"sys_language\";i:11;s:12:\"sys_template\";i:12;s:10:\"tt_content\";i:13;s:29:\"tx_grevman_domain_model_event\";i:14;s:29:\"tx_grevman_domain_model_group\";i:15;s:29:\"tx_grevman_domain_model_guest\";i:16;s:28:\"tx_grevman_domain_model_note\";i:17;s:36:\"tx_grevman_domain_model_registration\";}}s:12:\"external_ref\";a:1:{s:6:\"tables\";s:0:\"\";}s:15:\"external_static\";a:1:{s:6:\"tables\";a:1:{i:0;s:4:\"_ALL\";}}s:19:\"showStaticRelations\";s:1:\"1\";s:15:\"excludeDisabled\";s:1:\"1\";s:20:\"download_export_name\";s:14:\"tree_PID0_L999\";s:6:\"preset\";a:2:{s:5:\"title\";s:19:\"grevman-test-static\";s:6:\"public\";i:1;}s:4:\"meta\";a:3:{s:5:\"title\";s:0:\"\";s:11:\"description\";s:0:\"\";s:5:\"notes\";s:0:\"\";}s:8:\"filetype\";s:3:\"xml\";s:8:\"filename\";s:8:\"test.xml\";s:24:\"excludeHTMLfileResources\";s:0:\"\";s:26:\"saveFilesOutsideExportFile\";s:0:\"\";s:13:\"extension_dep\";s:0:\"\";s:10:\"softrefCfg\";a:2:{s:32:\"1c8d070c152eeab20233c19daf5679df\";a:1:{s:4:\"mode\";s:0:\"\";}s:32:\"f992614796c62361b6d1a023a4f61baa\";a:1:{s:4:\"mode\";s:0:\"\";}}s:7:\"exclude\";a:0:{}}',0,1634559000,1634559000);
/*!40000 ALTER TABLE `tx_impexp_presets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_scheduler_task`
--

DROP TABLE IF EXISTS `tx_scheduler_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_scheduler_task` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `nextexecution` int(10) unsigned NOT NULL DEFAULT 0,
  `lastexecution_time` int(10) unsigned NOT NULL DEFAULT 0,
  `lastexecution_failure` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastexecution_context` varchar(3) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `serialized_task_object` mediumblob DEFAULT NULL,
  `serialized_executions` mediumblob DEFAULT NULL,
  `task_group` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `index_nextexecution` (`nextexecution`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_scheduler_task`
--

LOCK TABLES `tx_scheduler_task` WRITE;
/*!40000 ALTER TABLE `tx_scheduler_task` DISABLE KEYS */;
INSERT INTO `tx_scheduler_task` VALUES (1,1634548145,1,0,'',0,1634549575,'','BE','O:48:\"TYPO3\\CMS\\Scheduler\\Task\\FileStorageIndexingTask\":10:{s:10:\"storageUid\";i:1;s:12:\"\0*\0scheduler\";N;s:10:\"\0*\0taskUid\";i:1;s:11:\"\0*\0disabled\";b:1;s:19:\"\0*\0runOnNextCronJob\";b:0;s:12:\"\0*\0execution\";O:29:\"TYPO3\\CMS\\Scheduler\\Execution\":6:{s:8:\"\0*\0start\";i:1634548107;s:6:\"\0*\0end\";i:1634548107;s:11:\"\0*\0interval\";i:0;s:11:\"\0*\0multiple\";i:0;s:10:\"\0*\0cronCmd\";s:0:\"\";s:23:\"\0*\0isNewSingleExecution\";b:0;}s:16:\"\0*\0executionTime\";i:1634548107;s:14:\"\0*\0description\";s:0:\"\";s:12:\"\0*\0taskGroup\";i:0;s:9:\"\0*\0logger\";N;}','',0),(2,1634548426,1,0,'',0,1634549579,'','BE','O:54:\"TYPO3\\CMS\\Scheduler\\Task\\RecyclerGarbageCollectionTask\":10:{s:12:\"numberOfDays\";i:30;s:12:\"\0*\0scheduler\";N;s:10:\"\0*\0taskUid\";i:2;s:11:\"\0*\0disabled\";b:1;s:19:\"\0*\0runOnNextCronJob\";b:0;s:12:\"\0*\0execution\";O:29:\"TYPO3\\CMS\\Scheduler\\Execution\":6:{s:8:\"\0*\0start\";i:1634548400;s:6:\"\0*\0end\";i:1634548400;s:11:\"\0*\0interval\";i:0;s:11:\"\0*\0multiple\";i:0;s:10:\"\0*\0cronCmd\";s:0:\"\";s:23:\"\0*\0isNewSingleExecution\";b:0;}s:16:\"\0*\0executionTime\";i:1634548400;s:14:\"\0*\0description\";s:0:\"\";s:12:\"\0*\0taskGroup\";i:0;s:9:\"\0*\0logger\";N;}','',0),(3,1634550162,1,0,'',0,1634550227,'','BE','O:50:\"TYPO3\\CMS\\Scheduler\\Task\\FileStorageExtractionTask\":11:{s:10:\"storageUid\";i:1;s:12:\"maxFileCount\";i:100;s:12:\"\0*\0scheduler\";N;s:10:\"\0*\0taskUid\";i:3;s:11:\"\0*\0disabled\";b:1;s:19:\"\0*\0runOnNextCronJob\";b:0;s:12:\"\0*\0execution\";O:29:\"TYPO3\\CMS\\Scheduler\\Execution\":6:{s:8:\"\0*\0start\";i:1634550147;s:6:\"\0*\0end\";i:1634550147;s:11:\"\0*\0interval\";i:0;s:11:\"\0*\0multiple\";i:0;s:10:\"\0*\0cronCmd\";s:0:\"\";s:23:\"\0*\0isNewSingleExecution\";b:0;}s:16:\"\0*\0executionTime\";i:1634550147;s:14:\"\0*\0description\";s:0:\"\";s:12:\"\0*\0taskGroup\";i:0;s:9:\"\0*\0logger\";N;}','',0);
/*!40000 ALTER TABLE `tx_scheduler_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_scheduler_task_group`
--

DROP TABLE IF EXISTS `tx_scheduler_task_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_scheduler_task_group` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `groupName` varchar(80) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_scheduler_task_group`
--

LOCK TABLES `tx_scheduler_task_group` WRITE;
/*!40000 ALTER TABLE `tx_scheduler_task_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_scheduler_task_group` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-02-17 13:00:46
