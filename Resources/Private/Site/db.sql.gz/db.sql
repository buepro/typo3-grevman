
-- Dump of TYPO3 Connection "Default"
-- MySQL dump 10.19  Distrib 10.3.29-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: db    Database: db
-- ------------------------------------------------------
-- Server version	10.3.30-MariaDB-1:10.3.30+maria~focal-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `backend_layout`
--

DROP TABLE IF EXISTS `backend_layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backend_layout` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `config` text NOT NULL,
  `icon` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_layout`
--

LOCK TABLES `backend_layout` WRITE;
/*!40000 ALTER TABLE `backend_layout` DISABLE KEYS */;
/*!40000 ALTER TABLE `backend_layout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_dashboards`
--

DROP TABLE IF EXISTS `be_dashboards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_dashboards` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `identifier` varchar(120) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `title` varchar(120) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `widgets` text COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_dashboards`
--

LOCK TABLES `be_dashboards` WRITE;
/*!40000 ALTER TABLE `be_dashboards` DISABLE KEYS */;
INSERT INTO `be_dashboards` VALUES (1,0,1633586401,1633586401,1,0,0,0,0,'e03f4772850a5196ac12827aca28b5ca22369aa6','My dashboard','{\"0b07d07cdb5c0d4bac40d94df95f217e782e9db9\":{\"identifier\":\"t3information\"},\"c2c591de8cedd1f6a8f1e1d99bc4908de014d61f\":{\"identifier\":\"t3news\"},\"28f94dfda6be78c710093ac34d6d8075269bdd5e\":{\"identifier\":\"docGettingStarted\"}}');
/*!40000 ALTER TABLE `be_dashboards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_groups`
--

DROP TABLE IF EXISTS `be_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `non_exclude_fields` text DEFAULT NULL,
  `explicit_allowdeny` text DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `custom_options` text DEFAULT NULL,
  `db_mountpoints` text DEFAULT NULL,
  `pagetypes_select` text DEFAULT NULL,
  `tables_select` text DEFAULT NULL,
  `tables_modify` text DEFAULT NULL,
  `groupMods` text DEFAULT NULL,
  `file_mountpoints` text DEFAULT NULL,
  `file_permissions` text DEFAULT NULL,
  `lockToDomain` varchar(50) NOT NULL DEFAULT '',
  `TSconfig` text DEFAULT NULL,
  `subgroup` text DEFAULT NULL,
  `workspace_perms` smallint(6) NOT NULL DEFAULT 1,
  `category_perms` text DEFAULT NULL,
  `availableWidgets` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_groups`
--

LOCK TABLES `be_groups` WRITE;
/*!40000 ALTER TABLE `be_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `be_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_users`
--

DROP TABLE IF EXISTS `be_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `username` varchar(50) NOT NULL DEFAULT '',
  `avatar` int(10) unsigned NOT NULL DEFAULT 0,
  `password` varchar(100) NOT NULL DEFAULT '',
  `admin` smallint(5) unsigned NOT NULL DEFAULT 0,
  `usergroup` varchar(255) NOT NULL DEFAULT '',
  `lang` varchar(6) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `db_mountpoints` text DEFAULT NULL,
  `options` smallint(5) unsigned NOT NULL DEFAULT 0,
  `realName` varchar(80) NOT NULL DEFAULT '',
  `userMods` text DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `uc` mediumblob DEFAULT NULL,
  `file_mountpoints` text DEFAULT NULL,
  `file_permissions` text DEFAULT NULL,
  `workspace_perms` smallint(6) NOT NULL DEFAULT 1,
  `lockToDomain` varchar(50) NOT NULL DEFAULT '',
  `disableIPlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `TSconfig` text DEFAULT NULL,
  `lastlogin` int(10) unsigned NOT NULL DEFAULT 0,
  `createdByAction` int(11) NOT NULL DEFAULT 0,
  `usergroup_cached_list` text DEFAULT NULL,
  `workspace_id` int(11) NOT NULL DEFAULT 0,
  `category_perms` text DEFAULT NULL,
  `password_reset_token` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `username` (`username`),
  KEY `parent` (`pid`,`deleted`,`disable`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_users`
--

LOCK TABLES `be_users` WRITE;
/*!40000 ALTER TABLE `be_users` DISABLE KEYS */;
INSERT INTO `be_users` VALUES (1,0,1634545462,1550653930,0,0,0,0,0,NULL,'admin',0,'$argon2i$v=19$m=65536,t=16,p=1$eFNaZS5zUm0ubmguSXhSUA$foOpAgOnfNOUoswnTTHJ7PfEp2dJnbi/tYf+Vy8cXM4',1,'','','',NULL,0,'',NULL,'','a:38:{s:14:\"interfaceSetup\";s:0:\"\";s:10:\"moduleData\";a:19:{s:10:\"web_layout\";a:3:{s:8:\"function\";s:1:\"1\";s:8:\"language\";s:1:\"0\";s:21:\"tt_content_showHidden\";s:1:\"1\";}s:8:\"web_list\";a:1:{s:15:\"bigControlPanel\";s:1:\"1\";}s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";a:0:{}s:10:\"FormEngine\";a:2:{i:0;a:1:{s:32:\"03503ca1cd5cd0415c40d453219dffaa\";a:4:{i:0;s:17:\"leader1, Trainer1\";i:1;a:5:{s:4:\"edit\";a:1:{s:8:\"fe_users\";a:1:{i:14;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:32:\"&edit%5Bfe_users%5D%5B14%5D=edit\";i:3;a:5:{s:5:\"table\";s:8:\"fe_users\";s:3:\"uid\";i:14;s:3:\"pid\";i:226;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}}i:1;s:32:\"03503ca1cd5cd0415c40d453219dffaa\";}s:16:\"opendocs::recent\";a:8:{s:32:\"e2fe31fc6353286fd05ca174ce654c03\";a:4:{i:0;s:12:\"My dashboard\";i:1;a:5:{s:4:\"edit\";a:1:{s:13:\"be_dashboards\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:36:\"&edit%5Bbe_dashboards%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:13:\"be_dashboards\";s:3:\"uid\";i:1;s:3:\"pid\";i:0;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"3da537a72022f134d5a59a9a16d10af1\";a:4:{i:0;s:25:\"fileadmin/ (auto-created)\";i:1;a:5:{s:4:\"edit\";a:1:{s:16:\"sys_file_storage\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:39:\"&edit%5Bsys_file_storage%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:16:\"sys_file_storage\";s:3:\"uid\";i:1;s:3:\"pid\";i:0;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"daa7369ae4e210bfcb1572adf51b12e5\";a:4:{i:0;s:5:\"_cli_\";i:1;a:5:{s:4:\"edit\";a:1:{s:8:\"be_users\";a:1:{i:6;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:31:\"&edit%5Bbe_users%5D%5B6%5D=edit\";i:3;a:5:{s:5:\"table\";s:8:\"be_users\";s:3:\"uid\";i:6;s:3:\"pid\";i:0;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"89494ca03c0d71614c20797c37296c5a\";a:4:{i:0;s:5:\"admin\";i:1;a:5:{s:4:\"edit\";a:1:{s:8:\"be_users\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:31:\"&edit%5Bbe_users%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:8:\"be_users\";s:3:\"uid\";i:1;s:3:\"pid\";i:0;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"20d77471730f2d8166ad0fb66acfba22\";a:4:{i:0;s:10:\"Kundeninfo\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:344;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:35:\"&edit%5Btt_content%5D%5B344%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:344;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"bef91f73c1250eb36d9b7bfeb3f0f194\";a:4:{i:0;s:6:\"event2\";i:1;a:5:{s:4:\"edit\";a:1:{s:29:\"tx_grevman_domain_model_event\";a:1:{i:2;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:52:\"&edit%5Btx_grevman_domain_model_event%5D%5B2%5D=edit\";i:3;a:5:{s:5:\"table\";s:29:\"tx_grevman_domain_model_event\";s:3:\"uid\";i:2;s:3:\"pid\";i:224;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"3338380b8b1dbd26b7a7487c0099813b\";a:4:{i:0;s:6:\"event1\";i:1;a:5:{s:4:\"edit\";a:1:{s:29:\"tx_grevman_domain_model_event\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:52:\"&edit%5Btx_grevman_domain_model_event%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:29:\"tx_grevman_domain_model_event\";s:3:\"uid\";i:1;s:3:\"pid\";i:224;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"1c9fba2793da3a4b1dd8d16fdb60531d\";a:4:{i:0;s:17:\"leader1, Trainer1\";i:1;a:5:{s:4:\"edit\";a:1:{s:8:\"fe_users\";a:1:{s:5:\"14,15\";s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";s:8:\"password\";s:6:\"noView\";N;}i:2;s:58:\"&edit%5Bfe_users%5D%5B14%2C15%5D=edit&columnsOnly=password\";i:3;a:5:{s:5:\"table\";s:8:\"fe_users\";s:3:\"uid\";i:14;s:3:\"pid\";i:226;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}}s:4:\"list\";a:3:{s:32:\"tx_timelog_domain_model_interval\";s:1:\"0\";s:31:\"tx_timelog_domain_model_project\";s:1:\"0\";s:33:\"tx_timelog_domain_model_taskgroup\";s:1:\"0\";}s:6:\"web_ts\";a:11:{s:8:\"function\";s:87:\"TYPO3\\CMS\\Tstemplate\\Controller\\TypoScriptTemplateObjectBrowserModuleFunctionController\";s:19:\"constant_editor_cat\";s:24:\"pizpalue: administration\";s:15:\"ts_browser_type\";s:5:\"const\";s:16:\"ts_browser_const\";s:1:\"0\";s:19:\"ts_browser_fixedLgd\";s:1:\"1\";s:23:\"ts_browser_showComments\";s:1:\"1\";s:25:\"tsbrowser_depthKeys_setup\";a:120:{s:24:\"page.jsFooterInline.1020\";i:1;s:24:\"page.jsFooterInline.1030\";i:1;s:14:\"module.tx_form\";i:1;s:23:\"module.tx_form.settings\";i:1;s:42:\"module.tx_form.settings.yamlConfigurations\";i:1;s:9:\"page.1.10\";i:1;s:18:\"tt_content.stdWrap\";i:1;s:24:\"plugin.tx_ttaddress.view\";i:1;s:42:\"plugin.tx_ttaddress.view.templateRootPaths\";i:1;s:41:\"plugin.tx_ttaddress.view.partialRootPaths\";i:1;s:40:\"plugin.tx_ttaddress.view.layoutRootPaths\";i:1;s:26:\"lib.dynamicContentSlide.20\";i:1;s:20:\"lib.dynamicContent.5\";i:1;s:35:\"lib.dynamicContent.5.colPos.cObject\";i:1;s:43:\"lib.dynamicContent.5.colPos.cObject.ifEmpty\";i:1;s:51:\"lib.dynamicContent.5.colPos.cObject.ifEmpty.cObject\";i:1;s:57:\"lib.dynamicContent.5.colPos.cObject.ifEmpty.cObject.value\";i:1;s:34:\"lib.dynamicContent.5.slide.cObject\";i:1;s:43:\"lib.dynamicContent.5.slide.cObject.override\";i:1;s:46:\"lib.dynamicContent.5.slide.cObject.override.if\";i:1;s:55:\"lib.dynamicContent.5.slide.cObject.override.if.isInList\";i:1;s:26:\"lib.contentElement.gallery\";i:1;s:23:\"plugin.tx_form.settings\";i:1;s:42:\"plugin.tx_form.settings.yamlConfigurations\";i:1;s:44:\"lib.contentElement.settings.responsiveimages\";i:1;s:23:\"tt_content.ce-container\";i:1;s:34:\"plugin.tx_news.settings.list.media\";i:1;s:40:\"plugin.tx_news.settings.list.media.image\";i:1;s:29:\"plugin.tx_news.settings.media\";i:1;s:36:\"plugin.tx_news.view.partialRootPaths\";i:1;s:35:\"plugin.tx_news.view.layoutRootPaths\";i:1;s:15:\"plugin.pizpalue\";i:1;s:27:\"plugin.pizpalue._LOCAL_LANG\";i:1;s:35:\"plugin.pizpalue._LOCAL_LANG.default\";i:1;s:39:\"plugin.tx_bootstrap_package._LOCAL_LANG\";i:1;s:47:\"plugin.tx_bootstrap_package._LOCAL_LANG.default\";i:1;s:36:\"lib.parseFunc_RTE.tags.link.typolink\";i:1;s:46:\"lib.parseFunc_RTE.tags.link.typolink.parameter\";i:1;s:37:\"lib.parseFunc_RTE.tags.link.parseFunc\";i:1;s:33:\"lib.parseFunc_RTE.tags.a.typolink\";i:1;s:43:\"lib.parseFunc_RTE.tags.a.typolink.extTarget\";i:1;s:52:\"lib.parseFunc_RTE.tags.a.typolink.extTarget.override\";i:1;s:34:\"lib.parseFunc_RTE.tags.a.parseFunc\";i:1;s:68:\"lib.contentElement.settings.responsiveimages.noFrameVariants.default\";i:1;s:65:\"lib.contentElement.settings.responsiveimages.pageVariants.default\";i:1;s:27:\"plugin.tx_fluxelements.view\";i:1;s:43:\"plugin.tx_fluxelements.view.layoutRootPaths\";i:1;s:44:\"plugin.tx_fluxelements.view.partialRootPaths\";i:1;s:45:\"plugin.tx_fluxelements.view.templateRootPaths\";i:1;s:29:\"plugin.tx_news._LOCAL_LANG.es\";i:1;s:11:\"lib.tx_news\";i:1;s:23:\"lib.tt_content.shortcut\";i:1;s:18:\"tt_content.list.20\";i:1;s:24:\"plugin.tx_news.variables\";i:1;s:28:\"plugin.tx_news.settings.list\";i:1;s:45:\"lib.containerContentElement.templateRootPaths\";i:1;s:61:\"lib.contentElement.settings.responsiveimages.variants.default\";i:1;s:59:\"lib.contentElement.settings.responsiveimages.variants.large\";i:1;s:60:\"lib.contentElement.settings.responsiveimages.variants.medium\";i:1;s:59:\"lib.contentElement.settings.responsiveimages.variants.small\";i:1;s:64:\"lib.contentElement.settings.responsiveimages.variants.extrasmall\";i:1;s:27:\"tt_content.shortcut.20.conf\";i:1;s:53:\"tt_content.shortcut.20.conf.tx_news_domain_model_news\";i:1;s:29:\"tt_content.shortcut.variables\";i:1;s:39:\"tt_content.shortcut.variables.shortcuts\";i:1;s:44:\"tt_content.shortcut.variables.shortcuts.conf\";i:1;s:52:\"tt_content.shortcut.variables.shortcuts.conf.pages.5\";i:1;s:82:\"tt_content.shortcut.variables.shortcuts.conf.pages.5.tt_content_shortcut_recursive\";i:1;s:46:\"tt_content.shortcut.variables.shortcuts.source\";i:1;s:36:\"tt_content.pp_modal_dialog.variables\";i:1;s:46:\"tt_content.pp_modal_dialog.variables.shortcuts\";i:1;s:51:\"tt_content.pp_modal_dialog.variables.shortcuts.conf\";i:1;s:57:\"tt_content.pp_modal_dialog.variables.shortcuts.conf.pages\";i:1;s:53:\"tt_content.pp_modal_dialog.variables.shortcuts.source\";i:1;s:49:\"tt_content.pp_modal_dialog.variables.shortcuts.20\";i:1;s:56:\"tt_content.pp_modal_dialog.variables.shortcuts.20.source\";i:1;s:54:\"tt_content.pp_modal_dialog.variables.shortcuts.20.conf\";i:1;s:84:\"lib.contentElement.settings.responsiveimages.contentelements.textpic.left.multiplier\";i:1;s:76:\"lib.contentElement.settings.responsiveimages.contentelements.pp_modal_dialog\";i:1;s:68:\"lib.contentElement.settings.responsiveimages.contentelements.textpic\";i:1;s:73:\"lib.contentElement.settings.responsiveimages.contentelements.textpic.left\";i:1;s:81:\"lib.contentElement.settings.responsiveimages.contentelements.textpic.left.gutters\";i:1;s:70:\"lib.contentElement.settings.responsiveimages.backendlayout.2_columns.0\";i:1;s:81:\"lib.contentElement.settings.responsiveimages.backendlayout.2_columns.0.multiplier\";i:1;s:78:\"lib.contentElement.settings.responsiveimages.backendlayout.2_columns.0.gutters\";i:1;s:78:\"lib.contentElement.settings.responsiveimages.backendlayout.subnavigation_right\";i:1;s:80:\"lib.contentElement.settings.responsiveimages.backendlayout.subnavigation_right.0\";i:1;s:91:\"lib.contentElement.settings.responsiveimages.backendlayout.subnavigation_right.0.multiplier\";i:1;s:88:\"lib.contentElement.settings.responsiveimages.backendlayout.subnavigation_right.0.gutters\";i:1;s:43:\"lib.contentElement.settings.gallery.columns\";i:1;s:18:\"page.headerData.10\";i:1;s:24:\"page.includeJSFooterlibs\";i:1;s:32:\"plugin.tx_felogin_login.settings\";i:1;s:21:\"lib.dynamicContent.10\";i:1;s:29:\"lib.dynamicContent.10.stdWrap\";i:1;s:33:\"lib.contentElement.dataProcessing\";i:1;s:32:\"tt_content.list.20.powermail_pi1\";i:1;s:32:\"tt_content.list.20.powermail_pi2\";i:1;s:23:\"tt_content.default.wrap\";i:1;s:36:\"lib.containerContentElement.settings\";i:1;s:54:\"lib.containerContentElement.settings.containerElements\";i:1;s:14:\"styles.content\";i:1;s:18:\"styles.content.get\";i:1;s:25:\"styles.content.get.select\";i:1;s:46:\"lib.parseFunc_RTE.externalBlocks.table.stdWrap\";i:1;s:42:\"lib.parseFunc.nonTypoTagStdWrap.HTMLparser\";i:1;s:32:\"lib.parseFunc_RTE.externalBlocks\";i:1;s:61:\"lib.parseFunc_RTE.externalBlocks.table.stdWrap.parseFunc.tags\";i:1;s:43:\"lib.parseFunc_RTE.externalBlocks.pp:gettext\";i:1;s:40:\"lib.parseFunc_RTE.externalBlocks.gettext\";i:1;s:22:\"lib.parseFunc_RTE.tags\";i:1;s:18:\"lib.parseFunc.tags\";i:1;s:35:\"lib.parseFunc_RTE.externalBlocks.ol\";i:1;s:43:\"lib.parseFunc_RTE.externalBlocks.ol.stdWrap\";i:1;s:35:\"lib.parseFunc_RTE.externalBlocks.ul\";i:1;s:43:\"lib.parseFunc_RTE.externalBlocks.pp-gettext\";i:1;s:51:\"lib.parseFunc_RTE.externalBlocks.pp-gettext.stdWrap\";i:1;s:6:\"plugin\";i:1;s:26:\"plugin.tx_news._LOCAL_LANG\";i:1;s:10:\"tt_content\";i:1;}s:20:\"tsbrowser_conditions\";a:7:{s:32:\"4f5b345c1e805a673ddc410db8568348\";s:0:\"\";s:32:\"8d603c08ff24469dcd95c7cd95556376\";s:0:\"\";s:32:\"31a5ee3355ea1fe5e2136f0597c24dd8\";s:0:\"\";s:32:\"5d872687d14b03945fefc8f61eedd660\";s:0:\"\";s:32:\"8d5162ca104fa7e79fe80fd92bb657fb\";s:0:\"\";s:32:\"ffb7c399fe1d1c6c494fdaf47b419bd4\";s:8:\"[1 == 1]\";s:32:\"23112cc5ca5eddcbc1338b155c8beb7c\";s:0:\"\";}s:25:\"tsbrowser_depthKeys_const\";a:16:{s:14:\"styles.content\";i:1;s:20:\"pizpalue.animation.1\";i:1;s:19:\"plugin.tx_news.view\";i:1;s:23:\"plugin.tx_news.view.twb\";i:1;s:33:\"plugin.bootstrap_package.settings\";i:1;s:20:\"page.theme.copyright\";i:1;s:19:\"page.theme.language\";i:1;s:23:\"plugin.tx_bookmarkpages\";i:1;s:32:\"plugin.tx_bookmarkpages.settings\";i:1;s:36:\"plugin.tx_containerelements.settings\";i:1;s:50:\"plugin.tx_containerelements.settings.imageVariants\";i:1;s:57:\"plugin.tx_containerelements.settings.imageVariants.gutter\";i:1;s:66:\"plugin.tx_containerelements.settings.imageVariants.gutter.variants\";i:1;s:6:\"plugin\";i:1;s:19:\"plugin.tx_ttaddress\";i:1;s:24:\"plugin.tx_ttaddress.view\";i:1;}s:24:\"ts_analyzer_checkLinenum\";s:1:\"1\";s:23:\"ts_analyzer_checkSyntax\";s:1:\"1\";}s:9:\"tx_beuser\";s:530:\"O:40:\"TYPO3\\CMS\\Beuser\\Domain\\Model\\ModuleData\":2:{s:9:\"\0*\0demand\";O:36:\"TYPO3\\CMS\\Beuser\\Domain\\Model\\Demand\":12:{s:11:\"\0*\0userName\";s:0:\"\";s:11:\"\0*\0userType\";i:0;s:9:\"\0*\0status\";i:0;s:9:\"\0*\0logins\";i:0;s:19:\"\0*\0backendUserGroup\";N;s:6:\"\0*\0uid\";N;s:16:\"\0*\0_localizedUid\";N;s:15:\"\0*\0_languageUid\";N;s:16:\"\0*\0_versionedUid\";N;s:6:\"\0*\0pid\";N;s:61:\"\0TYPO3\\CMS\\Extbase\\DomainObject\\AbstractDomainObject\0_isClone\";b:0;s:69:\"\0TYPO3\\CMS\\Extbase\\DomainObject\\AbstractDomainObject\0_cleanProperties\";a:0:{}}s:18:\"\0*\0compareUserList\";a:0:{}}\";s:13:\"system_config\";a:9:{s:4:\"tree\";s:8:\"confVars\";s:11:\"regexSearch\";b:0;s:8:\"node_tca\";a:123:{s:37:\"tt_content.columns.pi_flexform.config\";i:1;s:40:\"tt_content.columns.pi_flexform.config.ds\";i:1;s:31:\"tt_content.columns.CType.config\";i:1;s:37:\"tt_content.columns.CType.config.items\";i:1;s:14:\"pages.palettes\";i:1;s:11:\"pages.types\";i:1;s:13:\"pages.types.4\";i:1;s:32:\"tt_content.columns.colPos.config\";i:1;s:38:\"tt_content.columns.colPos.config.items\";i:1;s:31:\"tt_content.columns.image.config\";i:1;s:54:\"tt_content.columns.image.config.overrideChildTca.types\";i:1;s:56:\"tt_content.columns.image.config.overrideChildTca.columns\";i:1;s:66:\"tt_content.columns.image.config.overrideChildTca.columns.uid_local\";i:1;s:73:\"tt_content.columns.image.config.overrideChildTca.columns.uid_local.config\";i:1;s:84:\"tt_content.columns.image.config.overrideChildTca.columns.uid_local.config.appearance\";i:1;s:56:\"tt_content.columns.image.config.overrideChildTca.types.0\";i:1;s:56:\"tt_content.columns.image.config.overrideChildTca.types.1\";i:1;s:23:\"sys_file_reference.ctrl\";i:1;s:56:\"tt_content.columns.image.config.overrideChildTca.types.2\";i:1;s:56:\"tt_content.columns.image.config.overrideChildTca.types.3\";i:1;s:56:\"tt_content.columns.image.config.overrideChildTca.types.4\";i:1;s:56:\"tt_content.columns.image.config.overrideChildTca.types.5\";i:1;s:27:\"sys_file_reference.palettes\";i:1;s:47:\"sys_file_reference.palettes.videoOverlayPalette\";i:1;s:43:\"tt_content.types.textmedia.columnsOverrides\";i:1;s:50:\"tt_content.types.textmedia.columnsOverrides.assets\";i:1;s:57:\"tt_content.types.textmedia.columnsOverrides.assets.config\";i:1;s:74:\"tt_content.types.textmedia.columnsOverrides.assets.config.overrideChildTca\";i:1;s:82:\"tt_content.types.textmedia.columnsOverrides.assets.config.overrideChildTca.columns\";i:1;s:87:\"tt_content.types.textmedia.columnsOverrides.assets.config.overrideChildTca.columns.crop\";i:1;s:94:\"tt_content.types.textmedia.columnsOverrides.assets.config.overrideChildTca.columns.crop.config\";i:1;s:107:\"tt_content.types.textmedia.columnsOverrides.assets.config.overrideChildTca.columns.crop.config.cropVariants\";i:1;s:32:\"tt_content.columns.assets.config\";i:1;s:49:\"tt_content.columns.assets.config.overrideChildTca\";i:1;s:57:\"tt_content.columns.assets.config.overrideChildTca.columns\";i:1;s:67:\"tt_content.columns.assets.config.overrideChildTca.columns.uid_local\";i:1;s:74:\"tt_content.columns.assets.config.overrideChildTca.columns.uid_local.config\";i:1;s:85:\"tt_content.columns.assets.config.overrideChildTca.columns.uid_local.config.appearance\";i:1;s:39:\"tt_content.types.table.columnsOverrides\";i:1;s:48:\"tt_content.types.table.columnsOverrides.bodytext\";i:1;s:55:\"tt_content.types.table.columnsOverrides.bodytext.config\";i:1;s:37:\"tt_content.columns.frame_class.config\";i:1;s:46:\"tt_content.types.ce_container.columnsOverrides\";i:1;s:58:\"tt_content.types.ce_container.columnsOverrides.frame_class\";i:1;s:65:\"tt_content.types.ce_container.columnsOverrides.frame_class.config\";i:1;s:27:\"tt_content.palettes.headers\";i:1;s:27:\"tt_content.palettes.general\";i:1;s:42:\"tt_content.columns.CType.config.itemGroups\";i:1;s:45:\"tt_content.containerConfiguration.ce_columns2\";i:1;s:38:\"tx_vinfo_domain_model_business.columns\";i:1;s:43:\"tx_vinfo_domain_model_business.columns.vote\";i:1;s:50:\"tx_vinfo_domain_model_business.columns.vote.config\";i:1;s:35:\"tx_vinfo_domain_model_business.vote\";i:1;s:42:\"tx_vinfo_domain_model_business.vote.config\";i:1;s:61:\"tx_vinfo_domain_model_business.columns.vote.config.renderType\";i:1;s:35:\"tx_vinfo_domain_model_query.columns\";i:1;s:42:\"tx_vinfo_domain_model_query.columns.status\";i:1;s:49:\"tx_vinfo_domain_model_query.columns.status.config\";i:1;s:55:\"tx_vinfo_domain_model_query.columns.status.config.items\";i:1;s:16:\"tt_content.types\";i:1;s:31:\"tx_news_domain_model_news.types\";i:1;s:33:\"tx_news_domain_model_news.types.0\";i:1;s:50:\"tx_news_domain_model_news.types.0.columnsOverrides\";i:1;s:60:\"tx_news_domain_model_news.types.0.columnsOverrides.fal_media\";i:1;s:67:\"tx_news_domain_model_news.types.0.columnsOverrides.fal_media.config\";i:1;s:84:\"tx_news_domain_model_news.types.0.columnsOverrides.fal_media.config.overrideChildTca\";i:1;s:92:\"tx_news_domain_model_news.types.0.columnsOverrides.fal_media.config.overrideChildTca.columns\";i:1;s:97:\"tx_news_domain_model_news.types.0.columnsOverrides.fal_media.config.overrideChildTca.columns.crop\";i:1;s:104:\"tx_news_domain_model_news.types.0.columnsOverrides.fal_media.config.overrideChildTca.columns.crop.config\";i:1;s:117:\"tx_news_domain_model_news.types.0.columnsOverrides.fal_media.config.overrideChildTca.columns.crop.config.cropVariants\";i:1;s:145:\"tx_news_domain_model_news.types.0.columnsOverrides.fal_media.config.overrideChildTca.columns.crop.config.cropVariants.default.allowedAspectRatios\";i:1;s:134:\"tx_news_domain_model_news.types.0.columnsOverrides.fal_media.config.overrideChildTca.columns.crop.config.cropVariants.default.cropArea\";i:1;s:149:\"tx_news_domain_model_news.types.0.columnsOverrides.fal_media.config.overrideChildTca.columns.crop.config.cropVariants.default.allowedAspectRatios.1:1\";i:1;s:149:\"tx_news_domain_model_news.types.0.columnsOverrides.fal_media.config.overrideChildTca.columns.crop.config.cropVariants.default.allowedAspectRatios.1:2\";i:1;s:149:\"tx_news_domain_model_news.types.0.columnsOverrides.fal_media.config.overrideChildTca.columns.crop.config.cropVariants.default.allowedAspectRatios.2:1\";i:1;s:149:\"tx_news_domain_model_news.types.0.columnsOverrides.fal_media.config.overrideChildTca.columns.crop.config.cropVariants.default.allowedAspectRatios.3:4\";i:1;s:149:\"tx_news_domain_model_news.types.0.columnsOverrides.fal_media.config.overrideChildTca.columns.crop.config.cropVariants.default.allowedAspectRatios.4:3\";i:1;s:150:\"tx_news_domain_model_news.types.0.columnsOverrides.fal_media.config.overrideChildTca.columns.crop.config.cropVariants.default.allowedAspectRatios.9:16\";i:1;s:39:\"tt_content.types.image.columnsOverrides\";i:1;s:45:\"tt_content.types.image.columnsOverrides.image\";i:1;s:52:\"tt_content.types.image.columnsOverrides.image.config\";i:1;s:69:\"tt_content.types.image.columnsOverrides.image.config.overrideChildTca\";i:1;s:77:\"tt_content.types.image.columnsOverrides.image.config.overrideChildTca.columns\";i:1;s:82:\"tt_content.types.image.columnsOverrides.image.config.overrideChildTca.columns.crop\";i:1;s:89:\"tt_content.types.image.columnsOverrides.image.config.overrideChildTca.columns.crop.config\";i:1;s:102:\"tt_content.types.image.columnsOverrides.image.config.overrideChildTca.columns.crop.config.cropVariants\";i:1;s:110:\"tt_content.types.image.columnsOverrides.image.config.overrideChildTca.columns.crop.config.cropVariants.default\";i:1;s:24:\"tt_content.columns.image\";i:1;s:21:\"tt_content.types.list\";i:1;s:38:\"tt_content.types.list.columnsOverrides\";i:1;s:45:\"tt_content.types.list.columnsOverrides.assets\";i:1;s:52:\"tt_content.types.list.columnsOverrides.assets.config\";i:1;s:77:\"tt_content.types.list.columnsOverrides.assets.config.overrideChildTca.columns\";i:1;s:82:\"tt_content.types.list.columnsOverrides.assets.config.overrideChildTca.columns.crop\";i:1;s:89:\"tt_content.types.list.columnsOverrides.assets.config.overrideChildTca.columns.crop.config\";i:1;s:102:\"tt_content.types.list.columnsOverrides.assets.config.overrideChildTca.columns.crop.config.cropVariants\";i:1;s:110:\"tt_content.types.list.columnsOverrides.assets.config.overrideChildTca.columns.crop.config.cropVariants.default\";i:1;s:22:\"tt_content.types.media\";i:1;s:39:\"tt_content.types.media.columnsOverrides\";i:1;s:46:\"tt_content.types.media.columnsOverrides.assets\";i:1;s:62:\"tt_content.types.media.columnsOverrides.assets.config.filter.0\";i:1;s:73:\"tt_content.types.media.columnsOverrides.assets.config.filter.0.parameters\";i:1;s:53:\"tt_content.types.media.columnsOverrides.assets.config\";i:1;s:78:\"tt_content.types.media.columnsOverrides.assets.config.overrideChildTca.columns\";i:1;s:95:\"tt_content.types.media.columnsOverrides.assets.config.overrideChildTca.columns.uid_local.config\";i:1;s:106:\"tt_content.types.media.columnsOverrides.assets.config.overrideChildTca.columns.uid_local.config.appearance\";i:1;s:83:\"tt_content.types.media.columnsOverrides.assets.config.overrideChildTca.columns.crop\";i:1;s:90:\"tt_content.types.media.columnsOverrides.assets.config.overrideChildTca.columns.crop.config\";i:1;s:103:\"tt_content.types.media.columnsOverrides.assets.config.overrideChildTca.columns.crop.config.cropVariants\";i:1;s:111:\"tt_content.types.media.columnsOverrides.assets.config.overrideChildTca.columns.crop.config.cropVariants.default\";i:1;s:69:\"tt_content.types.list.columnsOverrides.assets.config.overrideChildTca\";i:1;s:70:\"tt_content.types.media.columnsOverrides.assets.config.overrideChildTca\";i:1;s:87:\"tt_content.types.list.columnsOverrides.assets.config.overrideChildTca.columns.uid_local\";i:1;s:94:\"tt_content.types.list.columnsOverrides.assets.config.overrideChildTca.columns.uid_local.config\";i:1;s:105:\"tt_content.types.list.columnsOverrides.assets.config.overrideChildTca.columns.uid_local.config.appearance\";i:1;s:88:\"tt_content.types.media.columnsOverrides.assets.config.overrideChildTca.columns.uid_local\";i:1;s:17:\"fe_groups.columns\";i:1;s:24:\"fe_groups.columns.events\";i:1;s:31:\"fe_groups.columns.events.config\";i:1;s:8:\"fe_users\";i:1;s:16:\"fe_users.columns\";i:1;s:26:\"fe_users.columns.usergroup\";i:1;s:33:\"fe_users.columns.usergroup.config\";i:1;}s:25:\"node_httpMiddlewareStacks\";a:2:{s:8:\"frontend\";i:1;s:7:\"backend\";i:1;}s:13:\"node_confVars\";a:15:{s:51:\"SC_OPTIONS.GLOBAL.extTablesInclusion-PostProcessing\";i:1;s:22:\"SC_OPTIONS.t3lib/class\";i:1;s:36:\"SC_OPTIONS.t3lib/class.t3lib_tcemain\";i:1;s:60:\"SC_OPTIONS.t3lib/class.t3lib_tcemain.php.processDatamapClass\";i:1;s:28:\"SYS.formEngine.formDataGroup\";i:1;s:44:\"SYS.formEngine.formDataGroup.flexFormSegment\";i:1;s:46:\"SYS.formEngine.formDataGroup.tcaDatabaseRecord\";i:1;s:15:\"SYS.linkHandler\";i:1;s:22:\"MAIL.templateRootPaths\";i:1;s:20:\"MAIL.layoutRootPaths\";i:1;s:11:\"RTE.Presets\";i:1;s:10:\"SC_OPTIONS\";i:1;s:22:\"SC_OPTIONS.tslib/class\";i:1;s:31:\"SC_OPTIONS.tslib/class.tslib_fe\";i:1;s:35:\"SC_OPTIONS.tslib/class.tslib_fe.php\";i:1;}s:26:\"node_formYamlConfiguration\";a:39:{s:31:\"mixins.translationSettingsMixin\";i:1;s:43:\"mixins.translationSettingsMixin.translation\";i:1;s:60:\"mixins.translationSettingsMixin.translation.translationFiles\";i:1;s:93:\"prototypes.standard.finishersDefinition.EmailToReceiver.formEditor.predefinedDefaults.options\";i:1;s:81:\"prototypes.standard.finishersDefinition.EmailToReceiver.options.templateRootPaths\";i:1;s:85:\"prototypes.standard.finishersDefinition.EmailToReceiver.formEditor.predefinedDefaults\";i:1;s:64:\"prototypes.standard.finishersDefinition.EmailToSender.formEditor\";i:1;s:83:\"prototypes.standard.finishersDefinition.EmailToSender.formEditor.predefinedDefaults\";i:1;s:91:\"prototypes.standard.finishersDefinition.EmailToSender.formEditor.predefinedDefaults.options\";i:1;s:83:\"prototypes.standard.finishersDefinition.EmailToSystem.formEditor.predefinedDefaults\";i:1;s:91:\"prototypes.standard.finishersDefinition.EmailToSystem.formEditor.predefinedDefaults.options\";i:1;s:10:\"prototypes\";i:1;s:19:\"prototypes.standard\";i:1;s:47:\"prototypes.standard.formElementsDefinition.Form\";i:1;s:58:\"prototypes.standard.formElementsDefinition.Form.formEditor\";i:1;s:78:\"prototypes.standard.formElementsDefinition.Form.formEditor.propertyCollections\";i:1;s:88:\"prototypes.standard.formElementsDefinition.Form.formEditor.propertyCollections.finishers\";i:1;s:92:\"prototypes.standard.formElementsDefinition.Form.formEditor.propertyCollections.finishers.110\";i:1;s:100:\"prototypes.standard.formElementsDefinition.Form.formEditor.propertyCollections.finishers.110.editors\";i:1;s:91:\"prototypes.standard.formElementsDefinition.Form.formEditor.propertyCollections.finishers.20\";i:1;s:117:\"prototypes.standard.formElementsDefinition.Form.formEditor.propertyCollections.finishers.20.editors.750.gridColumns.0\";i:1;s:117:\"prototypes.standard.formElementsDefinition.Form.formEditor.propertyCollections.finishers.20.editors.750.gridColumns.1\";i:1;s:104:\"prototypes.standard.formElementsDefinition.Form.formEditor.propertyCollections.finishers.110.editors.300\";i:1;s:99:\"prototypes.standard.formElementsDefinition.Form.formEditor.propertyCollections.finishers.20.editors\";i:1;s:115:\"prototypes.standard.formElementsDefinition.Form.formEditor.propertyCollections.finishers.20.editors.350.gridColumns\";i:1;s:117:\"prototypes.standard.formElementsDefinition.Form.formEditor.propertyCollections.finishers.20.editors.350.gridColumns.0\";i:1;s:117:\"prototypes.standard.formElementsDefinition.Form.formEditor.propertyCollections.finishers.20.editors.350.gridColumns.1\";i:1;s:105:\"prototypes.standard.formElementsDefinition.Form.formEditor.propertyCollections.finishers.110.editors.1300\";i:1;s:53:\"prototypes.standard.finishersDefinition.EmailToSystem\";i:1;s:55:\"prototypes.standard.finishersDefinition.EmailToReceiver\";i:1;s:73:\"prototypes.standard.finishersDefinition.EmailToSystem.FormEngine.elements\";i:1;s:74:\"prototypes.standard.finishersDefinition.EmailToSystem.FormEngine._elements\";i:1;s:75:\"prototypes.standard.finishersDefinition.EmailToReceiver.FormEngine.elements\";i:1;s:66:\"prototypes.standard.finishersDefinition.EmailToReceiver.formEditor\";i:1;s:64:\"prototypes.standard.finishersDefinition.EmailToSystem.formEditor\";i:1;s:103:\"prototypes.standard.formElementsDefinition.Form.formEditor.propertyCollections.finishers.20.editors.100\";i:1;s:104:\"prototypes.standard.formElementsDefinition.Form.formEditor.propertyCollections.finishers.20.editors.1300\";i:1;s:104:\"prototypes.standard.formElementsDefinition.Form.formEditor.propertyCollections.finishers.20.editors.1400\";i:1;s:39:\"prototypes.standard.finishersDefinition\";i:1;}s:19:\"node_eventListeners\";a:9:{s:50:\"TYPO3\\CMS\\Frontend\\Event\\ModifyHrefLangTagsEvent.0\";i:1;s:58:\"TYPO3\\CMS\\Extbase\\Event\\Persistence\\EntityPersistedEvent.0\";i:1;s:58:\"TYPO3\\CMS\\Extbase\\Event\\Persistence\\EntityPersistedEvent.1\";i:1;s:72:\"TYPO3\\CMS\\Backend\\Controller\\Event\\AfterFormEnginePageInitializedEvent.0\";i:1;s:72:\"TYPO3\\CMS\\Backend\\Controller\\Event\\AfterFormEnginePageInitializedEvent.1\";i:1;s:56:\"TYPO3\\CMS\\Core\\Package\\Event\\AfterPackageActivationEvent\";i:1;s:58:\"TYPO3\\CMS\\Core\\Package\\Event\\AfterPackageActivationEvent.0\";i:1;s:58:\"TYPO3\\CMS\\Core\\Package\\Event\\AfterPackageActivationEvent.1\";i:1;s:58:\"TYPO3\\CMS\\Core\\Package\\Event\\AfterPackageActivationEvent.2\";i:1;}s:15:\"node_pagesTypes\";a:4:{s:7:\"default\";i:1;i:255;i:1;i:254;i:1;i:6;i:1;}s:22:\"node_siteConfiguration\";a:0:{}}s:9:\"file_list\";a:1:{s:13:\"displayThumbs\";s:1:\"1\";}s:16:\"browse_links.php\";a:1:{s:12:\"expandFolder\";s:21:\"1:/grevman/Documents/\";}s:8:\"web_info\";a:5:{s:8:\"function\";s:48:\"TYPO3\\CMS\\Belog\\Module\\BackendLogModuleBootstrap\";s:12:\"tsconf_parts\";s:1:\"0\";s:5:\"pages\";s:1:\"0\";s:5:\"depth\";s:1:\"0\";s:4:\"lang\";s:1:\"0\";}s:4:\"page\";a:1:{s:28:\"gridelementsCollapsedColumns\";a:4:{s:7:\"365_101\";s:1:\"1\";s:7:\"468_101\";s:1:\"1\";s:7:\"469_101\";s:1:\"1\";s:7:\"468_201\";s:1:\"1\";}}s:9:\"clipboard\";a:5:{s:6:\"normal\";a:1:{s:4:\"mode\";s:0:\"\";}s:5:\"tab_1\";a:1:{s:4:\"mode\";s:0:\"\";}s:5:\"tab_2\";a:1:{s:4:\"mode\";s:0:\"\";}s:5:\"tab_3\";a:1:{s:4:\"mode\";s:0:\"\";}s:7:\"current\";s:6:\"normal\";}s:16:\"extensionbuilder\";a:1:{s:9:\"firstTime\";i:0;}s:18:\"list/displayFields\";a:7:{s:33:\"tx_timelog_domain_model_taskgroup\";a:1:{i:0;s:0:\"\";}s:28:\"tx_timelog_domain_model_task\";a:2:{i:0;s:0:\"\";i:1;s:10:\"task_group\";}s:25:\"tx_news_domain_model_news\";a:5:{i:0;s:0:\"\";i:1;s:8:\"datetime\";i:2;s:9:\"event_end\";i:3;s:9:\"organizer\";i:4;s:8:\"location\";}s:27:\"tx_vinfo_domain_model_query\";a:2:{i:0;s:0:\"\";i:1;s:6:\"status\";}s:8:\"fe_users\";a:2:{i:0;s:0:\"\";i:1;s:8:\"password\";}s:36:\"tx_grevman_domain_model_registration\";a:2:{i:0;s:0:\"\";i:1;s:5:\"state\";}s:29:\"tx_grevman_domain_model_event\";a:3:{i:0;s:0:\"\";i:1;s:9:\"startdate\";i:2;s:7:\"enddate\";}}s:28:\"dashboard/current_dashboard/\";s:40:\"e03f4772850a5196ac12827aca28b5ca22369aa6\";s:12:\"system_dbint\";a:3:{s:8:\"function\";s:8:\"refindex\";s:6:\"search\";s:3:\"raw\";s:22:\"search_query_makeQuery\";s:3:\"all\";}s:20:\"system_txschedulerM1\";a:1:{s:8:\"function\";s:9:\"scheduler\";}}s:19:\"thumbnailsByDefault\";i:1;s:14:\"emailMeAtLogin\";i:0;s:11:\"startModule\";s:0:\"\";s:8:\"titleLen\";s:2:\"50\";s:8:\"edit_RTE\";i:1;s:20:\"edit_docModuleUpload\";i:1;s:15:\"resizeTextareas\";i:1;s:25:\"resizeTextareas_MaxHeight\";s:3:\"500\";s:24:\"resizeTextareas_Flexible\";i:0;s:4:\"lang\";s:0:\"\";s:19:\"firstLoginTimeStamp\";i:1550653944;s:15:\"moduleSessionID\";a:16:{s:10:\"web_layout\";s:32:\"80752a3cde1ee17090c6c3b7ee011b3c\";s:8:\"web_list\";s:32:\"2636b9364ad923e6b0e30abbbd2dd09c\";s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";s:40:\"400f503beb19a6d21b3dd9bdea300c9434637a4d\";s:10:\"FormEngine\";s:40:\"400f503beb19a6d21b3dd9bdea300c9434637a4d\";s:16:\"opendocs::recent\";s:40:\"727f7614b5d2df317d9d1df672012fc835466337\";s:6:\"web_ts\";s:40:\"727f7614b5d2df317d9d1df672012fc835466337\";s:9:\"tx_beuser\";s:40:\"727f7614b5d2df317d9d1df672012fc835466337\";s:9:\"file_list\";s:32:\"21ef62a3917ad2a2c8dd1717915f81e4\";s:16:\"browse_links.php\";s:40:\"c72855bc858b3be918fd6f64e928fb448e9d6ee8\";s:8:\"web_info\";s:40:\"727f7614b5d2df317d9d1df672012fc835466337\";s:9:\"clipboard\";s:40:\"727f7614b5d2df317d9d1df672012fc835466337\";s:16:\"extensionbuilder\";s:40:\"fdf21a2e497df6c100fd699da8e9b3c2123850ce\";s:18:\"list/displayFields\";s:40:\"c72855bc858b3be918fd6f64e928fb448e9d6ee8\";s:28:\"dashboard/current_dashboard/\";s:40:\"c6b9350d27d7b7730388cfb53c9ba604154abafe\";s:12:\"system_dbint\";s:40:\"727f7614b5d2df317d9d1df672012fc835466337\";s:20:\"system_txschedulerM1\";s:40:\"727f7614b5d2df317d9d1df672012fc835466337\";}s:17:\"BackendComponents\";a:1:{s:6:\"States\";a:3:{s:8:\"Pagetree\";a:1:{s:9:\"stateHash\";a:30:{s:3:\"0_1\";s:1:\"1\";s:4:\"0_80\";s:1:\"1\";s:4:\"0_91\";s:1:\"0\";s:4:\"0_82\";s:1:\"0\";s:5:\"0_103\";s:1:\"0\";s:5:\"0_109\";s:1:\"0\";s:4:\"0_18\";s:1:\"0\";s:4:\"0_27\";s:1:\"0\";s:4:\"0_97\";s:1:\"1\";s:4:\"0_52\";s:1:\"0\";s:5:\"0_117\";s:1:\"0\";s:4:\"0_94\";s:1:\"0\";s:4:\"0_67\";s:1:\"0\";s:4:\"0_57\";s:1:\"1\";s:4:\"0_93\";s:1:\"1\";s:5:\"0_120\";s:1:\"1\";s:5:\"0_190\";s:1:\"1\";s:5:\"0_192\";s:1:\"0\";s:5:\"0_123\";s:1:\"1\";s:5:\"0_194\";s:1:\"0\";s:5:\"0_200\";s:1:\"0\";s:5:\"0_201\";s:1:\"1\";s:4:\"0_88\";s:1:\"0\";s:5:\"0_205\";s:1:\"0\";s:5:\"0_187\";s:1:\"1\";s:5:\"0_207\";s:1:\"0\";s:5:\"0_206\";s:1:\"0\";s:5:\"0_197\";s:1:\"0\";s:5:\"0_220\";s:1:\"0\";s:5:\"0_223\";s:1:\"1\";}}s:17:\"typo3-module-menu\";a:1:{s:9:\"collapsed\";s:4:\"true\";}s:16:\"ExtensionManager\";a:1:{s:6:\"filter\";s:6:\"System\";}}}s:10:\"inlineView\";s:5471:\"{\"site\":{\"1\":{\"site_language\":{\"4\":\"2\",\"5\":\"0\"},\"site_route\":{\"2\":\"0\"}}},\"tx_timelog_domain_model_task\":{\"11\":{\"tx_timelog_domain_model_interval\":[30,\"\"]},\"NEW5eabe448b4c9b302528992\":{\"tx_timelog_domain_model_interval\":[31]},\"15\":{\"tx_timelog_domain_model_interval\":{\"1\":\"31\"}},\"NEW5eabe81cee99f334710387\":{\"tx_timelog_domain_model_interval\":[32]},\"NEW5eabf241e11fd679532143\":{\"tx_timelog_domain_model_interval\":[33]},\"NEW5eabf497299b3463044971\":{\"tx_timelog_domain_model_interval\":[34]},\"NEW5eb3fcf14db0e244144717\":{\"tx_timelog_domain_model_interval\":[38]},\"21\":{\"tx_timelog_domain_model_interval\":[39,40]},\"NEW5eb6de97b6021897549832\":{\"tx_timelog_domain_model_interval\":[42]},\"23\":{\"tx_timelog_domain_model_interval\":[43]}},\"tx_timelog_domain_model_project\":{\"5\":{\"tx_timelog_domain_model_task\":[\"\"],\"tx_timelog_domain_model_taskgroup\":[3,4,5]},\"6\":{\"tx_timelog_domain_model_interval\":{\"0\":35,\"1\":36,\"2\":37,\"7\":\"39\",\"8\":\"38\",\"10\":\"40\"},\"tx_timelog_domain_model_task\":{\"1\":\"20\",\"12\":\"21\"},\"tx_timelog_domain_model_task_group\":[1],\"tx_timelog_domain_model_taskgroup\":{\"13\":\"\"}}},\"tx_timelog_domain_model_taskgroup\":{\"2\":{\"tx_timelog_domain_model_task\":[\"20\"],\"tx_timelog_domain_model_interval\":[41]},\"1\":{\"tx_timelog_domain_model_task\":{\"4\":\"19\"}}},\"tt_content\":{\"NEW5f2add01b7e53469777127\":{\"sys_file_reference\":[385]},\"780\":{\"sys_file_reference\":{\"0\":386,\"1\":387,\"5\":\"\"}},\"NEW5f3179d7b02b5269450631\":{\"sys_file_reference\":[389]},\"NEW5f317c6399b20292267607\":{\"sys_file_reference\":[390]},\"807\":{\"sys_file_reference\":[\"390\"]},\"NEW5f31819ba800d813646479\":{\"sys_file_reference\":[391]},\"NEW5f3181f0681c2273223467\":{\"sys_file_reference\":[392]},\"NEW5f318993c25af964292760\":{\"sys_file_reference\":[393]},\"NEW5f318b9daca8e298441350\":{\"sys_file_reference\":[394]},\"NEW5f351f4dda72b615681307\":{\"sys_file_reference\":[395]},\"NEW5f351f88d1f72931649153\":{\"sys_file_reference\":[396]},\"840\":{\"sys_file_reference\":[\"396\"]},\"908\":{\"sys_file_reference\":[400,401]},\"NEW5f97dd7244ed0897313902\":{\"sys_file_reference\":[408]},\"NEW5f9a6e96df043290247570\":{\"sys_file_reference\":[409]},\"NEW5fb386ed1d64e053298664\":{\"sys_file_reference\":[410]},\"933\":{\"sys_file_reference\":[\"410\"]},\"NEW5fb396c89acca079747674\":{\"sys_file_reference\":[411]},\"939\":{\"sys_file_reference\":[\"412\",\"413\",\"414\",\"415\",\"416\",\"417\"]},\"940\":{\"sys_file_reference\":[\"418\",\"419\",\"420\",\"421\"]},\"927\":{\"sys_file_reference\":[422]},\"NEW5fb794acb4ea3704436116\":{\"sys_file_reference\":[429]},\"NEW5fe0d8a11839d583393456\":{\"sys_file_reference\":[430]},\"NEW5fe0d8bad2fb7671705414\":{\"sys_file_reference\":[431]},\"952\":{\"sys_file_reference\":[]},\"953\":{\"sys_file_reference\":[433]},\"NEW5fe197f5c6c0c276005224\":{\"sys_file_reference\":[434,435,436,437]},\"NEW5fe1991baa27c056409945\":{\"sys_file_reference\":[438]},\"NEW5fe199ab2c7bc243589434\":{\"sys_file_reference\":[439]},\"NEW5fe199c208da8146119236\":{\"sys_file_reference\":[440]},\"NEW6030e278a968e209674347\":{\"sys_file_reference\":[441]},\"969\":{\"sys_file_reference\":{\"2\":\"441\"}},\"NEW6069ec3edb7ce036425900\":{\"sys_file_reference\":[442]},\"NEW6069eca507b42031334515\":{\"sys_file_reference\":[443]},\"NEW6069eccce24a2531932335\":{\"sys_file_reference\":[444]},\"NEW6069ece29bb88066886438\":{\"sys_file_reference\":[445]},\"NEW6069ed067aced069585528\":{\"sys_file_reference\":[446]},\"NEW6069ed1ce1fe7802245241\":{\"sys_file_reference\":[447]},\"NEW6069ed319c04b349158762\":{\"sys_file_reference\":[448]},\"997\":{\"sys_file_reference\":[449]},\"NEW6069eda81e75c784806946\":{\"sys_file_reference\":[450]},\"1000\":{\"sys_file_reference\":{\"1\":\"\"}},\"112\":{\"sys_file_reference\":[\"\",453,455]},\"NEW607091ee560d5021641125\":{\"sys_file_reference\":[456]},\"NEW60719598dcac7591053873\":{\"sys_file_reference\":[457]},\"NEW607195ccba83e628579393\":{\"sys_file_reference\":[458]},\"NEW607195e344db9750093181\":{\"sys_file_reference\":[459]},\"957\":{\"sys_file_reference\":[\"438\",460]},\"350\":{\"sys_file_reference\":[461]},\"NEW60db43dcb2af9413926434\":{\"sys_file_reference\":[465]},\"1018\":{\"sys_file_reference\":[\"465\"]}},\"tx_realer_domain_model_property\":{\"1\":{\"sys_file_reference\":[399]}},\"tx_news_domain_model_news\":{\"4\":{\"sys_file_reference\":[402]},\"7\":{\"sys_file_reference\":{\"1\":\"\"}},\"6\":{\"sys_file_reference\":[407],\"tx_news_domain_model_link\":[1]},\"1\":{\"sys_file_reference\":[\"4\"]},\"3\":{\"sys_file_reference\":{\"2\":\"6\"}},\"2\":{\"sys_file_reference\":[\"5\"]}},\"tx_vinfo_domain_model_vote\":{\"1\":{\"tx_vinfo_domain_model_business\":{\"1\":6,\"2\":\"1\",\"5\":\"4\",\"6\":\"5\",\"7\":\"3\"},\"tx_vinfo_domain_model_query\":[\"1\",8,9,10,11]},\"2\":{\"tx_vinfo_domain_model_business\":[\"2\"]},\"3\":{\"tx_vinfo_domain_model_query\":{\"6\":\"13\",\"7\":\"12\"},\"tx_vinfo_domain_model_business\":{\"1\":8,\"4\":\"7\"}}},\"tx_vinfo_domain_model_business\":{\"1\":{\"tx_vinfo_domain_model_query\":{\"4\":\"\"}},\"2\":{\"tx_vinfo_domain_model_query\":[2]},\"5\":{\"tx_vinfo_domain_model_query\":{\"1\":\"\"}}},\"tx_powermail_domain_model_form\":{\"NEW6089929b75ed9148230161\":{\"tx_powermail_domain_model_field\":[1,2,3],\"tx_powermail_domain_model_page\":[1]},\"1\":{\"tx_powermail_domain_model_page\":[\"1\"],\"tx_powermail_domain_model_field\":[\"\",4]}},\"tx_grevman_domain_model_event\":{\"1\":{\"tx_grevman_domain_model_registration\":{\"9\":\"1\",\"10\":\"2\"},\"tx_grevman_domain_model_note\":{\"5\":\"\"},\"sys_file_reference\":[462,463,469,470]},\"NEW60d2daae692c9447735987\":{\"sys_file_reference\":[464]},\"2\":{\"tx_grevman_domain_model_registration\":[3,4]}},\"fe_users\":{\"11\":{\"tx_grevman_domain_model_note\":{\"2\":\"\"}},\"10\":{\"tx_grevman_domain_model_registration\":{\"2\":\"\"},\"tx_grevman_domain_model_note\":[\"\"]}},\"tt_address\":{\"3\":{\"sys_file_reference\":[\"466\"]},\"2\":{\"sys_file_reference\":[\"467\"]}}}\";s:10:\"AdminPanel\";a:19:{s:11:\"display_top\";b:1;s:12:\"tsdebug_tree\";s:1:\"0\";s:20:\"tsdebug_displayTimes\";s:1:\"0\";s:23:\"tsdebug_displayMessages\";s:1:\"0\";s:10:\"tsdebug_LR\";s:1:\"0\";s:22:\"tsdebug_displayContent\";s:1:\"0\";s:28:\"tsdebug_forceTemplateParsing\";s:1:\"0\";s:26:\"debug_log_groupByComponent\";s:1:\"0\";s:22:\"debug_log_groupByLevel\";s:1:\"0\";s:20:\"debug_log_startLevel\";s:1:\"0\";s:23:\"preview_showHiddenPages\";s:1:\"0\";s:25:\"preview_showHiddenRecords\";s:1:\"0\";s:22:\"preview_showFluidDebug\";s:1:\"0\";s:20:\"preview_clearCacheId\";s:3:\"109\";s:20:\"preview_simulateDate\";s:0:\"\";s:25:\"preview_simulateUserGroup\";s:1:\"0\";s:13:\"cache_noCache\";s:1:\"0\";s:22:\"edit_displayFieldIcons\";s:1:\"1\";s:17:\"edit_displayIcons\";s:1:\"1\";}s:8:\"realName\";s:0:\"\";s:5:\"email\";s:0:\"\";s:8:\"password\";s:0:\"\";s:9:\"password2\";s:0:\"\";s:6:\"avatar\";s:0:\"\";s:25:\"showHiddenFilesAndFolders\";i:1;s:10:\"copyLevels\";s:3:\"100\";s:15:\"recursiveDelete\";i:1;s:18:\"resetConfiguration\";s:0:\"\";s:16:\"frontend_editing\";i:0;s:24:\"frontend_editing_overlay\";i:1;s:42:\"dragAndDropHideNewElementWizardInfoOverlay\";i:0;s:17:\"hideColumnHeaders\";i:0;s:18:\"hideContentPreview\";i:0;s:19:\"showGridInformation\";i:0;s:11:\"newsoverlay\";s:1:\"0\";s:11:\"browseTrees\";a:2:{s:6:\"folder\";s:91:\"{\"25218\":{\"62822724\":1,\"108689290\":1,\"218175286\":1,\"95683263\":1,\"66702825\":1,\"14248556\":1}}\";s:11:\"browsePages\";s:45:\"[{\"0\":1,\"1\":1,\"117\":1,\"91\":1,\"207\":1,\"97\":1}]\";}s:19:\"disableDragInWizard\";i:0;s:25:\"disableCopyFromPageButton\";i:0;s:21:\"recentSwitchedToUsers\";a:0:{}s:11:\"tx_recycler\";a:3:{s:14:\"depthSelection\";i:999;s:14:\"tableSelection\";s:0:\"\";s:11:\"resultLimit\";i:25;}}',NULL,NULL,1,'',0,'',1634635352,0,NULL,0,NULL,''),(6,0,1634547047,1634547047,0,0,0,0,0,NULL,'_cli_',0,'$argon2i$v=19$m=65536,t=16,p=1$ZHJzSktDRm9vRnQ0dFgwSg$xKq98eYv3MNo70MtZt6UzBg/CzT8Maf4IVdD0Li19kg',1,'','','',NULL,0,'',NULL,'','a:12:{s:14:\"interfaceSetup\";s:0:\"\";s:10:\"moduleData\";a:0:{}s:19:\"thumbnailsByDefault\";i:1;s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";i:50;s:8:\"edit_RTE\";s:1:\"1\";s:20:\"edit_docModuleUpload\";s:1:\"1\";s:15:\"resizeTextareas\";i:1;s:25:\"resizeTextareas_MaxHeight\";i:500;s:24:\"resizeTextareas_Flexible\";i:0;s:4:\"lang\";s:0:\"\";s:19:\"firstLoginTimeStamp\";i:1634547047;}',NULL,NULL,1,'',0,NULL,0,0,NULL,0,NULL,'');
/*!40000 ALTER TABLE `be_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_groups`
--

DROP TABLE IF EXISTS `fe_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fe_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_extbase_type` varchar(255) NOT NULL DEFAULT '0',
  `title` varchar(50) NOT NULL DEFAULT '',
  `lockToDomain` varchar(50) NOT NULL DEFAULT '',
  `subgroup` tinytext DEFAULT NULL,
  `TSconfig` text DEFAULT NULL,
  `felogin_redirectPid` tinytext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_groups`
--

LOCK TABLES `fe_groups` WRITE;
/*!40000 ALTER TABLE `fe_groups` DISABLE KEYS */;
INSERT INTO `fe_groups` VALUES (3,225,1624269519,1624269519,1,0,0,'','0','participants','','','',''),(4,226,1624619257,1624269526,1,0,0,'','0','leaders','','','','');
/*!40000 ALTER TABLE `fe_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_users`
--

DROP TABLE IF EXISTS `fe_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fe_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_extbase_type` varchar(255) NOT NULL DEFAULT '',
  `username` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(100) NOT NULL DEFAULT '',
  `usergroup` tinytext DEFAULT NULL,
  `name` varchar(160) NOT NULL DEFAULT '',
  `first_name` varchar(50) NOT NULL DEFAULT '',
  `middle_name` varchar(50) NOT NULL DEFAULT '',
  `last_name` varchar(50) NOT NULL DEFAULT '',
  `address` varchar(255) NOT NULL DEFAULT '',
  `telephone` varchar(30) NOT NULL DEFAULT '',
  `fax` varchar(30) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `lockToDomain` varchar(50) NOT NULL DEFAULT '',
  `uc` blob DEFAULT NULL,
  `title` varchar(40) NOT NULL DEFAULT '',
  `zip` varchar(10) NOT NULL DEFAULT '',
  `city` varchar(50) NOT NULL DEFAULT '',
  `country` varchar(40) NOT NULL DEFAULT '',
  `www` varchar(80) NOT NULL DEFAULT '',
  `company` varchar(80) NOT NULL DEFAULT '',
  `image` tinytext DEFAULT NULL,
  `TSconfig` text DEFAULT NULL,
  `lastlogin` int(10) unsigned NOT NULL DEFAULT 0,
  `is_online` int(10) unsigned NOT NULL DEFAULT 0,
  `felogin_redirectPid` tinytext DEFAULT NULL,
  `felogin_forgotHash` varchar(80) DEFAULT '',
  `member_groups` int(10) unsigned NOT NULL DEFAULT 0,
  `registrations` int(10) unsigned NOT NULL DEFAULT 0,
  `notes` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`username`(100)),
  KEY `username` (`username`(100)),
  KEY `is_online` (`is_online`),
  KEY `felogin_forgotHash` (`felogin_forgotHash`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_users`
--

LOCK TABLES `fe_users` WRITE;
/*!40000 ALTER TABLE `fe_users` DISABLE KEYS */;
INSERT INTO `fe_users` VALUES (10,225,1634111233,1624269453,1,0,0,0,0,'','Tx_Grevman_Member','participant1','$argon2i$v=19$m=65536,t=16,p=1$aG9SQ1NUd0ZjLnJudlh2QQ$mQZygI24MWftGLEQf2UQVoBXHlRurK2PrSSUMc+CXzE','3','','Participant1','','Last1','','','','','',NULL,'','','','','','','0','',1634134159,1634134159,'','',1,0,0),(11,225,1634111233,1624269566,1,0,0,0,0,'','Tx_Grevman_Member','participant2','$argon2i$v=19$m=65536,t=16,p=1$RkZhR2x6UXg1RHRYLkJKVA$MQJbTByuCRoiMd8PiTZ4lqs1aseg7WU3xhNGeN6sJ2I','3','','Participant2','','Last2','','','','','',NULL,'','','','','','','0','',1624550099,1624550099,'','',2,2,0),(12,225,1634111233,1624269577,1,0,0,0,0,'','Tx_Grevman_Member','participant3','$argon2i$v=19$m=65536,t=16,p=1$ZzAxN3JIR2FJTTh5RmFsYg$7sbzid0oWBvYK6jAhShHThm3fTF9lJWkZjwPzAJg6VM','3','','Participant3','','Last3','','','','','',NULL,'','','','','','',NULL,'',1626856058,1626856895,'','',0,0,0),(13,225,1634111233,1624269590,1,0,0,0,0,'','Tx_Grevman_Member','participant4','$argon2i$v=19$m=65536,t=16,p=1$eGlZeUwzWjlSdnpEeDRHcg$jqIFQKSzgo+IOEJy6HQTH6TEJCk++tlZYrvCBWkM2Wc','3','','Participant4','','Last4','','','','','',NULL,'','','','','','',NULL,'',1624555295,1624557039,'','',0,0,0),(14,226,1634111259,1624269607,1,0,0,0,0,'','Tx_Grevman_Member','leader1','$argon2i$v=19$m=65536,t=16,p=1$eDVvR1BiSS83S0hnQUppcA$MAMv8GcnbxCPiA0W7E4e7d+Z6EbUhkZm7bR2Y1y1FWo','4','','Trainer1','','','','','','trainer1@grevman.ch','',NULL,'','','','','','','0','',1624992069,1624993015,'','',1,0,0),(15,226,1634111259,1624269618,1,0,0,0,0,'','Tx_Grevman_Member','leader2','$argon2i$v=19$m=65536,t=16,p=1$bEgyVWxMRUh2Qm83eG5VSQ$g/2kEvI//xkQG+pCSeBoD/hP3DnN3NyYREWmHtl1QHM','4','','Trainer2','','','','','','','',NULL,'','','','','','','0','',0,0,'','',1,0,0),(16,225,1634111233,1624600945,1,0,0,0,0,'','Tx_Grevman_Member','participant11','$argon2i$v=19$m=65536,t=16,p=1$dFFmRk9WRUJRLzRmY0dpMw$51dIvMnmCtbq07YS+Znq9oegP3IPcoG/6N1O0H4aOVY','3','','Participant11','','Last11','','','','','',NULL,'','','','','','','0','',1624602576,1624610848,'','',0,1,0);
/*!40000 ALTER TABLE `fe_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_groupid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_user` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_group` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_everybody` smallint(5) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `slug` varchar(2048) DEFAULT NULL,
  `doktype` int(10) unsigned NOT NULL DEFAULT 0,
  `TSconfig` text DEFAULT NULL,
  `is_siteroot` smallint(6) NOT NULL DEFAULT 0,
  `php_tree_stop` smallint(6) NOT NULL DEFAULT 0,
  `url` varchar(255) NOT NULL DEFAULT '',
  `shortcut` int(10) unsigned NOT NULL DEFAULT 0,
  `shortcut_mode` int(10) unsigned NOT NULL DEFAULT 0,
  `subtitle` varchar(255) NOT NULL DEFAULT '',
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `target` varchar(80) NOT NULL DEFAULT '',
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `lastUpdated` int(10) unsigned NOT NULL DEFAULT 0,
  `keywords` text DEFAULT NULL,
  `cache_timeout` int(10) unsigned NOT NULL DEFAULT 0,
  `cache_tags` varchar(255) NOT NULL DEFAULT '',
  `newUntil` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `no_search` smallint(5) unsigned NOT NULL DEFAULT 0,
  `SYS_LASTCHANGED` int(10) unsigned NOT NULL DEFAULT 0,
  `abstract` text DEFAULT NULL,
  `module` varchar(255) NOT NULL DEFAULT '',
  `extendToSubpages` smallint(5) unsigned NOT NULL DEFAULT 0,
  `author` varchar(255) NOT NULL DEFAULT '',
  `author_email` varchar(255) NOT NULL DEFAULT '',
  `nav_title` varchar(255) NOT NULL DEFAULT '',
  `nav_hide` smallint(6) NOT NULL DEFAULT 0,
  `content_from_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid_ol` smallint(6) NOT NULL DEFAULT 0,
  `l18n_cfg` smallint(6) NOT NULL DEFAULT 0,
  `fe_login_mode` smallint(6) NOT NULL DEFAULT 0,
  `backend_layout` varchar(64) NOT NULL DEFAULT '',
  `backend_layout_next_level` varchar(64) NOT NULL DEFAULT '',
  `tsconfig_includes` text DEFAULT NULL,
  `legacy_overlay_uid` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `no_index` smallint(6) NOT NULL DEFAULT 0,
  `no_follow` smallint(6) NOT NULL DEFAULT 0,
  `og_title` varchar(255) NOT NULL DEFAULT '',
  `og_description` text DEFAULT NULL,
  `og_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_title` varchar(255) NOT NULL DEFAULT '',
  `twitter_description` text DEFAULT NULL,
  `twitter_image` int(10) unsigned NOT NULL DEFAULT 0,
  `canonical_link` varchar(2048) NOT NULL DEFAULT '',
  `categories` int(11) NOT NULL DEFAULT 0,
  `nav_icon` int(10) unsigned DEFAULT 0,
  `thumbnail` int(10) unsigned DEFAULT 0,
  `twitter_card` varchar(255) NOT NULL DEFAULT '',
  `sitemap_priority` decimal(2,1) NOT NULL DEFAULT 0.5,
  `sitemap_changefreq` varchar(10) NOT NULL DEFAULT '',
  `nav_icon_set` varchar(255) NOT NULL DEFAULT '',
  `nav_icon_identifier` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `determineSiteRoot` (`is_siteroot`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `slug` (`slug`(127)),
  KEY `translation_source` (`l10n_source`),
  KEY `legacy_overlay` (`legacy_overlay_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=234 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES (1,0,1634546075,1550653971,1,0,0,0,0,'',256,NULL,0,0,0,0,NULL,0,'a:36:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:9:\"nav_title\";N;s:8:\"subtitle\";N;s:12:\"nav_icon_set\";N;s:8:\"nav_icon\";N;s:13:\"shortcut_mode\";N;s:8:\"shortcut\";N;s:8:\"abstract\";N;s:6:\"author\";N;s:12:\"author_email\";N;s:11:\"lastUpdated\";N;s:6:\"layout\";N;s:8:\"newUntil\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:9:\"thumbnail\";N;s:6:\"target\";N;s:11:\"is_siteroot\";N;s:9:\"no_search\";N;s:13:\"php_tree_stop\";N;s:5:\"media\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:8:\"l18n_cfg\";N;s:6:\"hidden\";N;s:8:\"nav_hide\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:16:\"extendToSubpages\";N;s:8:\"fe_group\";N;s:13:\"fe_login_mode\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,1,1,31,27,0,'Pizpalue','/',1,'',1,0,'',0,0,'',0,'',0,0,'',0,'',0,'Diese Webseite dient als Basis zur Erstellung professioneller TYPO3-Webseiten. Das Grundgerüst besteht aus der Erweiterung bootstrap_package von Benjamin Kott. Dank der sorgfältigen Einbindung von zusätzlichen Erweiterungen können Inhalte ansprechend präsentiert und leicht verwaltet werden.',0,1634546075,'','',0,'','','',0,0,0,0,0,0,'pagets__default','pagets__default','',0,1,'',0,0,'',NULL,0,'',NULL,0,'',0,0,0,'summary',0.5,'','',''),(223,1,1624356361,1624269364,1,0,0,0,0,'',4928,NULL,0,0,0,0,NULL,0,'a:52:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:9:\"nav_title\";N;s:8:\"subtitle\";N;s:8:\"nav_icon\";N;s:9:\"seo_title\";N;s:11:\"description\";N;s:8:\"no_index\";N;s:9:\"no_follow\";N;s:14:\"canonical_link\";N;s:18:\"sitemap_changefreq\";N;s:16:\"sitemap_priority\";N;s:8:\"og_title\";N;s:14:\"og_description\";N;s:8:\"og_image\";N;s:13:\"twitter_title\";N;s:19:\"twitter_description\";N;s:13:\"twitter_image\";N;s:12:\"twitter_card\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:6:\"author\";N;s:12:\"author_email\";N;s:11:\"lastUpdated\";N;s:6:\"layout\";N;s:8:\"newUntil\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:9:\"thumbnail\";N;s:16:\"content_from_pid\";N;s:6:\"target\";N;s:13:\"cache_timeout\";N;s:10:\"cache_tags\";N;s:11:\"is_siteroot\";N;s:9:\"no_search\";N;s:13:\"php_tree_stop\";N;s:6:\"module\";N;s:5:\"media\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:8:\"l18n_cfg\";N;s:6:\"hidden\";N;s:8:\"nav_hide\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:16:\"extendToSubpages\";N;s:8:\"fe_group\";N;s:13:\"fe_login_mode\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,1,1,31,31,0,'Grevman','/grevman',1,'',0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1624356361,NULL,'',0,'','','',0,0,0,0,0,0,'','','EXT:grevman/Configuration/TsConfig/Page/Storage.tsconfig',0,0,'',0,0,'',NULL,0,'',NULL,0,'',0,0,0,'summary',0.5,'','',''),(224,223,1624269373,1624269373,1,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,0,'',0,0,0,0,0,0,0,1,1,31,31,0,'Data','/grevman/data',254,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,0,'','',NULL,0,0,'',0,0,'',NULL,0,'',NULL,0,'',0,0,0,'summary',0.5,'','',''),(225,223,1624356225,1624269489,1,0,0,0,0,'0',128,NULL,0,0,0,0,NULL,0,'a:13:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:6:\"module\";N;s:5:\"media\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:6:\"hidden\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,1,1,31,31,0,'Participants','/grevman/users',254,'TCAdefaults {\r\n  fe_users {\r\n    usergroup = 3\r\n  }\r\n}',0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,0,'','',NULL,0,0,'',0,0,'',NULL,0,'',NULL,0,'',0,0,0,'summary',0.5,'','',''),(226,223,1624619241,1624341123,1,0,0,0,0,'0',192,NULL,0,0,0,0,NULL,0,'a:13:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:6:\"module\";N;s:5:\"media\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:6:\"hidden\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,1,1,31,31,0,'Leaders','/grevman/leaders',254,'TCAdefaults {\r\n  fe_users {\r\n    usergroup = 4\r\n  }\r\n}',0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,0,'','',NULL,0,0,'',0,0,'',NULL,0,'',NULL,0,'',0,0,0,'summary',0.5,'','',''),(227,223,1624547407,1624547407,1,0,0,0,0,'0',64,NULL,0,0,0,0,NULL,0,'',0,0,0,0,0,0,0,1,1,31,31,0,'Login','/grevman/login',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1624547407,NULL,'',0,'','','',0,0,0,0,0,0,'','',NULL,0,0,'',0,0,'',NULL,0,'',NULL,0,'',0,0,0,'summary',0.5,'','','');
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_be_shortcuts`
--

DROP TABLE IF EXISTS `sys_be_shortcuts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_be_shortcuts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `module_name` varchar(255) NOT NULL DEFAULT '',
  `url` text DEFAULT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sc_group` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts`
--

LOCK TABLES `sys_be_shortcuts` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category`
--

DROP TABLE IF EXISTS `sys_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_category` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `title` tinytext NOT NULL,
  `parent` int(11) NOT NULL DEFAULT 0,
  `items` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `category_parent` (`parent`),
  KEY `category_list` (`pid`,`deleted`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category`
--

LOCK TABLES `sys_category` WRITE;
/*!40000 ALTER TABLE `sys_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category_record_mm`
--

DROP TABLE IF EXISTS `sys_category_record_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_category_record_mm` (
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(255) NOT NULL DEFAULT '',
  `fieldname` varchar(255) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  KEY `uid_local_foreign` (`uid_local`,`uid_foreign`),
  KEY `uid_foreign_tablefield` (`uid_foreign`,`tablenames`(40),`fieldname`(3),`sorting_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category_record_mm`
--

LOCK TABLES `sys_category_record_mm` WRITE;
/*!40000 ALTER TABLE `sys_category_record_mm` DISABLE KEYS */;
INSERT INTO `sys_category_record_mm` VALUES (1,339,'tt_content','categories',3,1),(1,342,'tt_content','categories',2,1),(2,1,'tx_news_domain_model_news','categories',1,0),(2,2,'tx_news_domain_model_news','categories',2,1),(2,3,'tx_news_domain_model_news','categories',3,2),(1,75,'pages','categories',1,0),(1,150,'pages','categories',0,1),(1,471,'tt_content','categories',0,1),(1,558,'tt_content','categories',0,1),(1,639,'tt_content','categories',0,1),(1,702,'tt_content','categories',0,1),(1,706,'tt_content','categories',0,1),(1,710,'tt_content','categories',0,1),(1,712,'tt_content','categories',0,1),(1,722,'tt_content','categories',0,1),(1,727,'tt_content','categories',0,1),(1,733,'tt_content','categories',0,1),(1,741,'tt_content','categories',0,1),(1,761,'tt_content','categories',0,1),(3,471,'tt_content','categories',1,0),(3,558,'tt_content','categories',2,0),(3,702,'tt_content','categories',3,0),(3,722,'tt_content','categories',4,0),(3,706,'tt_content','categories',5,0),(3,710,'tt_content','categories',6,0),(3,712,'tt_content','categories',7,0),(3,727,'tt_content','categories',8,0),(3,741,'tt_content','categories',9,0),(3,150,'pages','categories',10,0),(3,733,'tt_content','categories',11,0),(3,639,'tt_content','categories',12,0),(4,4,'tx_news_domain_model_news','categories',0,1),(5,5,'tx_news_domain_model_news','categories',0,1),(4,6,'tx_news_domain_model_news','categories',0,1),(5,6,'tx_news_domain_model_news','categories',0,2),(3,3,'tx_news_domain_model_news','categories',0,1),(1,3,'tx_news_domain_model_news','categories',0,3);
/*!40000 ALTER TABLE `sys_category_record_mm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_collection`
--

DROP TABLE IF EXISTS `sys_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_collection` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `type` varchar(32) NOT NULL DEFAULT 'static',
  `table_name` tinytext DEFAULT NULL,
  `items` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_collection`
--

LOCK TABLES `sys_collection` WRITE;
/*!40000 ALTER TABLE `sys_collection` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_collection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_collection_entries`
--

DROP TABLE IF EXISTS `sys_collection_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_collection_entries` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_collection_entries`
--

LOCK TABLES `sys_collection_entries` WRITE;
/*!40000 ALTER TABLE `sys_collection_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_collection_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file`
--

DROP TABLE IF EXISTS `sys_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `last_indexed` int(11) NOT NULL DEFAULT 0,
  `missing` smallint(6) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `type` varchar(10) NOT NULL DEFAULT '',
  `metadata` int(11) NOT NULL DEFAULT 0,
  `identifier` text DEFAULT NULL,
  `identifier_hash` varchar(40) NOT NULL DEFAULT '',
  `folder_hash` varchar(40) NOT NULL DEFAULT '',
  `extension` varchar(255) NOT NULL DEFAULT '',
  `mime_type` varchar(255) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `sha1` varchar(40) NOT NULL DEFAULT '',
  `size` bigint(20) unsigned NOT NULL DEFAULT 0,
  `creation_date` int(11) NOT NULL DEFAULT 0,
  `modification_date` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `sel01` (`storage`,`identifier_hash`),
  KEY `folder` (`storage`,`folder_hash`),
  KEY `tstamp` (`tstamp`),
  KEY `lastindex` (`last_indexed`),
  KEY `sha1` (`sha1`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=162 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file`
--

LOCK TABLES `sys_file` WRITE;
/*!40000 ALTER TABLE `sys_file` DISABLE KEYS */;
INSERT INTO `sys_file` VALUES (1,0,1550653951,0,0,0,'2',0,'/typo3/sysext/extensionmanager/Resources/Public/Images/OfficialBadge.svg','d22aa59153acac7bde2c812e19692ef3d67fe028','1cf85ef1d73acd511c8fa41549b4b86abf0f0e08','svg','image/svg+xml','OfficialBadge.svg','e60b9dbea1fc2711b7cf2445bd0a6f6b3391c9c6',8892,1549020173,1548151924),(3,0,1634548155,1634550227,0,1,'1',0,'/pizpalue/forms/GeneralContact.form.yaml','61f64e8241a78b9114819a793907eaeddb9f4268','41f59af009ee502633babd4749aebe179cf55b86','yaml','text/plain','GeneralContact.form.yaml','4537d405ab980baa8e4abe5928e2bbb50d4e38db',2868,1633601557,1633601557),(8,0,1634548156,1634550227,0,1,'2',0,'/pizpalue/icons/_ionicons_svg_ios-rocket.svg','f77d1f2409db4699d8c27abda1c5f119ffe70f3c','277966f15f79d765c6a0234ff74cc293f009c781','svg','image/svg+xml','_ionicons_svg_ios-rocket.svg','9278465a5d1228419dd75cb3480ab6d48b043c1c',936,1633601557,1633601557),(9,0,1634548155,1634550227,0,1,'2',0,'/pizpalue/icons/_ionicons_svg_ios-eye.svg','c50906192cb4247ac65d2b8b3475e95330e5a8bc','277966f15f79d765c6a0234ff74cc293f009c781','svg','image/svg+xml','_ionicons_svg_ios-eye.svg','8f1ca511989f851e82c3163f00920752cf3be789',657,1633601557,1633601557),(10,0,1634548155,1634550227,0,1,'2',0,'/pizpalue/icons/_ionicons_svg_ios-apps.svg','dc3d0797e4c71698fce2d3564c922792972c2608','277966f15f79d765c6a0234ff74cc293f009c781','svg','image/svg+xml','_ionicons_svg_ios-apps.svg','3800ad201042956c4bdabf407f9411285da9d17d',744,1633601557,1633601557),(107,0,1550654024,0,0,0,'2',0,'/typo3conf/ext/pizpalue/Resources/Public/Images/logo.svg','f58aecbf54576a74b25ac2b41de7ea67ab111985','dd94046bf22bb2ceaab9445e61808b94503ecba0','svg','image/svg+xml','logo.svg','f06d376c263f2fd9b38b3fd2bfacd746204689ff',6175,1550653973,1550653973),(108,0,1550654024,0,0,0,'2',0,'/typo3conf/ext/pizpalue/Resources/Public/Images/logo_inv.svg','6f173dfaa393763e1afe9baeac4ec8fcd222f105','dd94046bf22bb2ceaab9445e61808b94503ecba0','svg','image/svg+xml','logo_inv.svg','af6376bfe3872bccb5fcfe80ded9bfd118ab7898',6131,1550653973,1550653973),(109,0,1550654025,0,0,0,'2',0,'/typo3conf/ext/bootstrap_package/Resources/Public/Images/Icons/Ionicons/cube.svg','53c5eba1e15081cc075a5f9b45ec066307820c92','8c9fb93e56adfc16399e09008e98524eaf0381d6','svg','image/svg+xml','cube.svg','4a28e17279d0fafea57a5eb8525cd4ead9078ea7',1101,1550653974,1550653974),(110,0,1550654025,0,0,0,'2',0,'/typo3conf/ext/bootstrap_package/Resources/Public/Images/Icons/Ionicons/android-add.svg','0cff5113a5c7a9dd54b825a7f7880ddca3c6ef49','8c9fb93e56adfc16399e09008e98524eaf0381d6','svg','image/svg+xml','android-add.svg','6eccc0775aca6022c9712bb6d476c07da0adcc9c',170,1550653974,1550653974),(111,0,1550654025,0,0,0,'2',0,'/typo3conf/ext/bootstrap_package/Resources/Public/Images/Icons/Ionicons/ios-settings-strong.svg','a205e4ada228a2ff5bab99a9e0d7d2faf0a1b440','8c9fb93e56adfc16399e09008e98524eaf0381d6','svg','image/svg+xml','ios-settings-strong.svg','29d20cda98a2ec04cc2edcdcbfa2b04958da35e3',543,1550653974,1550653974),(112,0,1551332875,0,0,0,'1',0,'/typo3conf/ext/bootstrap_package/Resources/Private/Forms/Contact.form.yaml','2a55626b114d39e0df900fed7de4bce280b525e8','cb325869a98c4a4b1426fc4e5bff6efce9ef3234','yaml','text/plain','Contact.form.yaml','81cc5aae0a367bdf5cb3481b993f58c44f34730b',4738,1550653974,1550653974),(114,0,1551379380,0,0,0,'2',0,'/typo3conf/ext/bootstrap_package/Resources/Public/Images/BootstrapPackage.svg','53b7aaf32363271515e80e6c7b25293292185218','27aadec2782a38a84423e8476091a41d1dbdbc06','svg','image/svg+xml','BootstrapPackage.svg','432a35f0e0b0c1ec08dd5ad94b5903d93090403a',5508,1550653974,1550653974),(115,0,1551379380,0,0,0,'2',0,'/typo3conf/ext/bootstrap_package/Resources/Public/Images/BootstrapPackageInverted.svg','5b24af7f7f2c99d8a6188015bc8298396b952ab7','27aadec2782a38a84423e8476091a41d1dbdbc06','svg','image/svg+xml','BootstrapPackageInverted.svg','4725d40dd7fcd037fb7b12918b91d2c40c1acc3f',5444,1550653974,1550653974),(131,0,1634548156,1634550227,0,1,'2',0,'/pizpalue/icons/_ionicons_svg_md-git-branch.svg','b62ca3d53480a7a6ea032323c5851a29875ae98d','277966f15f79d765c6a0234ff74cc293f009c781','svg','image/svg+xml','_ionicons_svg_md-git-branch.svg','b109b283597f824c64cb891643a448b36c4e6ce2',794,1633601557,1633601557),(132,0,1634548156,1634550227,0,1,'2',0,'/pizpalue/icons/_ionicons_svg_md-star-outline.svg','10544694c3dbd32cbb9c3fcea0a1307e519706e5','277966f15f79d765c6a0234ff74cc293f009c781','svg','image/svg+xml','_ionicons_svg_md-star-outline.svg','a469e5acbfe65576d1b3f54e7ffb7d83ac418bd4',551,1633601557,1633601557),(133,0,1634548156,1634550227,0,1,'2',0,'/pizpalue/icons/_ionicons_svg_md-stopwatch.svg','0fcb72914c87e32a5992b9c51d29225472a0f33c','277966f15f79d765c6a0234ff74cc293f009c781','svg','image/svg+xml','_ionicons_svg_md-stopwatch.svg','813ea27e4160d1d3187dac6f860e6b3b5ca9e71a',677,1633601557,1633601557),(134,0,1634548155,1634550227,0,1,'2',0,'/pizpalue/icons/_ionicons_svg_ios-keypad.svg','ecd36110ce07a3b1c83db49ab9ce4b38e7d13711','277966f15f79d765c6a0234ff74cc293f009c781','svg','image/svg+xml','_ionicons_svg_ios-keypad.svg','664a7731f6cb9457bc3e6d53cad1e3e2118335c4',1008,1633601557,1633601557),(141,0,1602651319,0,0,0,'2',0,'/typo3conf/ext/pizpalue/Extensions/news/Resources/Public/Images/knewsticker3.png','6143bc1b719814d092f423dfdf158e8eeb4bf6ad','3879b2cd4eea90d01e841aa6cc3435be3ecd8ce8','png','image/png','knewsticker3.png','853d5c2b0563a9ba79db9c3f191c7a234cadd64d',34964,1600502409,1600502409),(146,0,1613469525,0,0,0,'2',0,'/typo3conf/ext/pizpalue/Resources/Public/Images/backend-login-logo.png','889b5399229a788fa2ffc347045e08aafb3091ea','dd94046bf22bb2ceaab9445e61808b94503ecba0','png','image/png','backend-login-logo.png','96e541d48dc5adfe67df76e65887e8df34323040',35948,1605897902,1605897902),(149,0,1623078230,1634550227,0,1,'1',0,'/.htaccess','3450b1e7f2decdc58edd085ce04b19bc7f5d6fac','42099b4af021e53fd8fd4e056c2568d7c2e3ffa8','htaccess','text/plain','.htaccess','c0a8c528b8fade00660181fa87f5960cd42fe398',1645,1615095235,1615095235),(153,0,1634112199,1634550227,0,1,'2',0,'/grevman/Images/Flower.jpg','90f9f93d6d46bf8406ab9243e845de5750505141','3ca9be218693b7053c940d70813c5e10c1ddb3fb','jpg','image/jpeg','Flower.jpg','5c821b2dac07c0eb54768afe489d4d1cf26e619b',91442,1634112184,1634112184),(154,0,1634112991,1634550227,0,1,'5',0,'/grevman/Documents/Snowman.pdf','23a0d622e3ba327b5a40c56def6fb160dce67ec9','4be2cffa9cd60eb90312c6b28f550dc4c84c4589','pdf','application/pdf','Snowman.pdf','ce9a3382919a1146befd2fddfb732909173ae76d',235686,1634112973,1634112837),(156,0,1634548155,1634550227,0,1,'1',0,'/_temp_/index.html','1cd5eec12b9b11599c0b4c6b2d43342c4fb53a7b','0258f8a5f703dd44c350fbfcddeecb1634d46ad4','html','text/html','index.html','86f257eae12059ed5daf12ce6e5508f5f893012a',116,1633601541,1633601541),(157,0,1634548156,1634550227,0,1,'2',0,'/pizpalue/icons/_ionicons_svg_ios-star-outline.svg','bedef99f67a4e2dae525e72bad35e56a283d3ddb','277966f15f79d765c6a0234ff74cc293f009c781','svg','image/svg+xml','_ionicons_svg_ios-star-outline.svg','458f41c127c89c3c6e5c455e0da87c29f76f4b17',890,1633601557,1633601557),(158,0,1634549575,1634550227,0,1,'0',0,'/user_upload/index.html','c25533f303185517ca3e1e24b215d53aa74076d2','19669f1e02c2f16705ec7587044c66443be70725','html','inode/x-empty','index.html','da39a3ee5e6b4b0d3255bfef95601890afd80709',0,1633601541,1633601541),(159,0,1634549575,1634550227,0,1,'1',0,'/user_upload/_temp_/importexport/index.html','68614dc2826769e93d8a8ead62af30ac99aaa83a','0795cf796b4fc959be0ec00b183c0f47609dd9a5','html','text/html','index.html','86f257eae12059ed5daf12ce6e5508f5f893012a',116,1633601541,1633601541),(160,0,1634549575,1634550227,0,1,'0',0,'/user_upload/_temp_/index.html','a3ef597b554ed2a28c720b3e90e51edc9ec642b1','4e0743c93934dd9a02564d8e654d714bd2dc3d20','html','inode/x-empty','index.html','da39a3ee5e6b4b0d3255bfef95601890afd80709',0,1633601541,1633601541),(161,0,1634558479,0,0,1,'1',0,'/user_upload/_temp_/importexport/test.xml','32244c3c7d5af86813e362bb2d347db97281f442','0795cf796b4fc959be0ec00b183c0f47609dd9a5','xml','text/xml','test.xml','69c940339745525f7a36456222d0f98675b4ba4f',183421,1634558479,1634558479);
/*!40000 ALTER TABLE `sys_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_collection`
--

DROP TABLE IF EXISTS `sys_file_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_collection` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `type` varchar(30) NOT NULL DEFAULT 'static',
  `files` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `folder` text DEFAULT NULL,
  `recursive` smallint(6) NOT NULL DEFAULT 0,
  `category` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_collection`
--

LOCK TABLES `sys_file_collection` WRITE;
/*!40000 ALTER TABLE `sys_file_collection` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_collection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_metadata`
--

DROP TABLE IF EXISTS `sys_file_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_metadata` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `file` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `width` int(11) NOT NULL DEFAULT 0,
  `height` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `categories` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `file` (`file`),
  KEY `fal_filelist` (`l10n_parent`,`sys_language_uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_metadata`
--

LOCK TABLES `sys_file_metadata` WRITE;
/*!40000 ALTER TABLE `sys_file_metadata` DISABLE KEYS */;
INSERT INTO `sys_file_metadata` VALUES (1,0,1634550227,1634550227,1,0,0,NULL,0,'',0,0,0,0,0,0,0,149,NULL,0,0,NULL,NULL,0),(2,0,1634550227,1634550227,1,0,0,NULL,0,'',0,0,0,0,0,0,0,153,NULL,0,0,NULL,NULL,0),(3,0,1634550227,1634550227,1,0,0,NULL,0,'',0,0,0,0,0,0,0,154,NULL,0,0,NULL,NULL,0),(4,0,1634550227,1634550227,1,0,0,NULL,0,'',0,0,0,0,0,0,0,3,NULL,0,0,NULL,NULL,0),(5,0,1634550227,1634550227,1,0,0,NULL,0,'',0,0,0,0,0,0,0,9,NULL,0,0,NULL,NULL,0),(6,0,1634550227,1634550227,1,0,0,NULL,0,'',0,0,0,0,0,0,0,10,NULL,0,0,NULL,NULL,0),(7,0,1634550227,1634550227,1,0,0,NULL,0,'',0,0,0,0,0,0,0,134,NULL,0,0,NULL,NULL,0),(8,0,1634550227,1634550227,1,0,0,NULL,0,'',0,0,0,0,0,0,0,156,NULL,0,0,NULL,NULL,0),(9,0,1634550227,1634550227,1,0,0,NULL,0,'',0,0,0,0,0,0,0,8,NULL,0,0,NULL,NULL,0),(10,0,1634550227,1634550227,1,0,0,NULL,0,'',0,0,0,0,0,0,0,131,NULL,0,0,NULL,NULL,0),(11,0,1634550227,1634550227,1,0,0,NULL,0,'',0,0,0,0,0,0,0,132,NULL,0,0,NULL,NULL,0),(12,0,1634550227,1634550227,1,0,0,NULL,0,'',0,0,0,0,0,0,0,133,NULL,0,0,NULL,NULL,0),(13,0,1634550227,1634550227,1,0,0,NULL,0,'',0,0,0,0,0,0,0,157,NULL,0,0,NULL,NULL,0),(14,0,1634550227,1634550227,1,0,0,NULL,0,'',0,0,0,0,0,0,0,158,NULL,0,0,NULL,NULL,0),(15,0,1634550227,1634550227,1,0,0,NULL,0,'',0,0,0,0,0,0,0,159,NULL,0,0,NULL,NULL,0),(16,0,1634550227,1634550227,1,0,0,NULL,0,'',0,0,0,0,0,0,0,160,NULL,0,0,NULL,NULL,0),(17,0,1634558480,1634550933,1,0,0,NULL,0,'',0,0,0,0,0,0,0,161,NULL,0,0,NULL,NULL,0);
/*!40000 ALTER TABLE `sys_file_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_processedfile`
--

DROP TABLE IF EXISTS `sys_file_processedfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_processedfile` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `original` int(11) NOT NULL DEFAULT 0,
  `identifier` varchar(512) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `configuration` blob DEFAULT NULL,
  `configurationsha1` varchar(40) NOT NULL DEFAULT '',
  `originalfilesha1` varchar(40) NOT NULL DEFAULT '',
  `task_type` varchar(200) NOT NULL DEFAULT '',
  `checksum` varchar(10) NOT NULL DEFAULT '',
  `width` int(11) DEFAULT 0,
  `height` int(11) DEFAULT 0,
  `processing_url` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `combined_1` (`original`,`task_type`(100),`configurationsha1`),
  KEY `identifier` (`storage`,`identifier`(180))
) ENGINE=InnoDB AUTO_INCREMENT=2111 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_processedfile`
--

LOCK TABLES `sys_file_processedfile` WRITE;
/*!40000 ALTER TABLE `sys_file_processedfile` DISABLE KEYS */;
INSERT INTO `sys_file_processedfile` VALUES (1,1550653969,1550653946,0,1,'',NULL,'a:7:{s:5:\"width\";i:64;s:6:\"height\";i:64;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','2b8ba9da9dae9da80f2f4e84e0d8b848075b00e6','e60b9dbea1fc2711b7cf2445bd0a6f6b3391c9c6','Image.CropScaleMask','dc56bdaaeb',64,64,NULL),(2,1587571998,1550654024,0,107,'',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','f06d376c263f2fd9b38b3fd2bfacd746204689ff','Image.CropScaleMask','4ef2460073',1669,600,NULL),(3,1587571999,1550654024,0,108,'',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','af6376bfe3872bccb5fcfe80ded9bfd118ab7898','Image.CropScaleMask','1bea6dc5fc',1669,600,NULL),(80,1585935674,1551379380,0,114,'',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','432a35f0e0b0c1ec08dd5ad94b5903d93090403a','Image.CropScaleMask','617787ccc0',244,68,NULL),(81,1585935674,1551379380,0,115,'',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','4725d40dd7fcd037fb7b12918b91d2c40c1acc3f','Image.CropScaleMask','f20bfd129e',244,68,NULL),(856,1587573085,1587572057,0,136,'',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','1194c6cf4260ec3bd6cf87c3d0e3d7b2fecfb4f2','Image.CropScaleMask','fec6586dd1',1779,600,NULL),(857,1587573085,1587572057,0,137,'',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','ef8c2a6c4f15c2e10c5573b67f2617dc01fa2e7e','Image.CropScaleMask','2d0e8c6134',1779,600,NULL),(1088,1602651319,1602651319,0,141,'',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','853d5c2b0563a9ba79db9c3f191c7a234cadd64d','Image.CropScaleMask','45d9c6d831',NULL,NULL,NULL),(1309,1613469525,1613469525,0,146,'/typo3temp/assets/_processed_/2/7/csm_backend-login-logo_63e3fc75e8.png','csm_backend-login-logo_63e3fc75e8.png','a:7:{s:5:\"width\";i:150;s:6:\"height\";i:41;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','d178e7acc997e39ab598e80ec3f5861ddd06745a','96e541d48dc5adfe67df76e65887e8df34323040','Image.CropScaleMask','63e3fc75e8',150,41,NULL),(1990,1623059699,1623059699,0,147,'',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','31a17c9dc68423a74f769bd6a285ed329abf457f','Image.CropScaleMask','b5ba4feeba',399,198,''),(1991,1623059699,1623059699,0,148,'',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','398ae2c7dc57151f036030af8cea1a05027bdb72','Image.CropScaleMask','5696c6a1aa',399,198,''),(2109,1634548526,1634548526,1,153,'/_processed_/3/7/csm_Flower_f260506965.jpg','csm_Flower_f260506965.jpg','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','5c821b2dac07c0eb54768afe489d4d1cf26e619b','Image.CropScaleMask','f260506965',68,45,NULL),(2110,1634548526,1634548526,1,154,'/_processed_/5/f/csm_Snowman_0c6848bdd0.png','csm_Snowman_0c6848bdd0.png','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','ce9a3382919a1146befd2fddfb732909173ae76d','Image.CropScaleMask','0c6848bdd0',32,45,NULL);
/*!40000 ALTER TABLE `sys_file_processedfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_reference`
--

DROP TABLE IF EXISTS `sys_file_reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_reference` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  `table_local` varchar(64) NOT NULL DEFAULT '',
  `title` tinytext DEFAULT NULL,
  `description` text DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `link` varchar(1024) NOT NULL DEFAULT '',
  `crop` varchar(4000) NOT NULL DEFAULT '',
  `autoplay` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `tablenames_fieldname` (`tablenames`(32),`fieldname`(12)),
  KEY `deleted` (`deleted`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`),
  KEY `combined_1` (`l10n_parent`,`t3ver_oid`,`t3ver_wsid`,`t3ver_state`,`deleted`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=471 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_reference`
--

LOCK TABLES `sys_file_reference` WRITE;
/*!40000 ALTER TABLE `sys_file_reference` DISABLE KEYS */;
INSERT INTO `sys_file_reference` VALUES (469,224,1634113031,1634112250,1,0,0,0,0,NULL,'a:5:{s:5:\"title\";N;s:11:\"description\";N;s:9:\"uid_local\";N;s:6:\"hidden\";N;s:16:\"sys_language_uid\";N;}',0,0,0,0,0,0,0,153,1,'tx_grevman_domain_model_event','images',1,'sys_file','Drop mirroring flower','Drop mirroring flower',NULL,'','',0),(470,224,1634113031,1634113031,1,0,0,0,0,NULL,'',0,0,0,0,0,0,0,154,1,'tx_grevman_domain_model_event','files',1,'sys_file','Movie review from \"The Snowman\"','Movie review from \"The Snowman\"',NULL,'','',0);
/*!40000 ALTER TABLE `sys_file_reference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_storage`
--

DROP TABLE IF EXISTS `sys_file_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_storage` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `driver` tinytext DEFAULT NULL,
  `configuration` text DEFAULT NULL,
  `is_default` smallint(6) NOT NULL DEFAULT 0,
  `is_browsable` smallint(6) NOT NULL DEFAULT 0,
  `is_public` smallint(6) NOT NULL DEFAULT 0,
  `is_writable` smallint(6) NOT NULL DEFAULT 0,
  `is_online` smallint(6) NOT NULL DEFAULT 1,
  `auto_extract_metadata` smallint(6) NOT NULL DEFAULT 1,
  `processingfolder` tinytext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_storage`
--

LOCK TABLES `sys_file_storage` WRITE;
/*!40000 ALTER TABLE `sys_file_storage` DISABLE KEYS */;
INSERT INTO `sys_file_storage` VALUES (1,0,1634548746,1550653946,0,0,'This is the local fileadmin/ directory. This storage mount has been created automatically by TYPO3.','fileadmin/ (auto-created)','Local','<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"basePath\">\n                    <value index=\"vDEF\">fileadmin/</value>\n                </field>\n                <field index=\"pathType\">\n                    <value index=\"vDEF\">relative</value>\n                </field>\n                <field index=\"caseSensitive\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"baseUri\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',1,1,1,1,1,1,NULL);
/*!40000 ALTER TABLE `sys_file_storage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_filemounts`
--

DROP TABLE IF EXISTS `sys_filemounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_filemounts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `path` varchar(255) NOT NULL DEFAULT '',
  `base` int(10) unsigned NOT NULL DEFAULT 0,
  `read_only` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_filemounts`
--

LOCK TABLES `sys_filemounts` WRITE;
/*!40000 ALTER TABLE `sys_filemounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_filemounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_history`
--

DROP TABLE IF EXISTS `sys_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_history` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `actiontype` smallint(6) NOT NULL DEFAULT 0,
  `usertype` varchar(2) NOT NULL DEFAULT 'BE',
  `userid` int(10) unsigned DEFAULT NULL,
  `originaluserid` int(10) unsigned DEFAULT NULL,
  `recuid` int(11) NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `history_data` mediumtext DEFAULT NULL,
  `workspace` int(11) DEFAULT 0,
  `correlation_id` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `recordident_1` (`tablename`(100),`recuid`),
  KEY `recordident_2` (`tablename`(100),`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_history`
--

LOCK TABLES `sys_history` WRITE;
/*!40000 ALTER TABLE `sys_history` DISABLE KEYS */;
INSERT INTO `sys_history` VALUES (1,1634548746,2,'BE',1,0,1,'sys_file_storage','{\"oldRecord\":{\"configuration\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"basePath\\\">\\n                    <value index=\\\"vDEF\\\">fileadmin\\/<\\/value>\\n                <\\/field>\\n                <field index=\\\"pathType\\\">\\n                    <value index=\\\"vDEF\\\">relative<\\/value>\\n                <\\/field>\\n                <field index=\\\"caseSensitive\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\"},\"newRecord\":{\"configuration\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"basePath\\\">\\n                    <value index=\\\"vDEF\\\">fileadmin\\/<\\/value>\\n                <\\/field>\\n                <field index=\\\"pathType\\\">\\n                    <value index=\\\"vDEF\\\">relative<\\/value>\\n                <\\/field>\\n                <field index=\\\"caseSensitive\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n                <field index=\\\"baseUri\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\"}}',0,'0400$918eb68a3f1821038e16d342b1d74210:32ab7b2d76d9aac74acffbd63c980a82');
/*!40000 ALTER TABLE `sys_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_language`
--

DROP TABLE IF EXISTS `sys_language`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_language` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `title` varchar(80) NOT NULL DEFAULT '',
  `flag` varchar(20) NOT NULL DEFAULT '',
  `language_isocode` varchar(2) NOT NULL DEFAULT '',
  `nav_title` varchar(255) NOT NULL DEFAULT '',
  `locale` varchar(20) NOT NULL DEFAULT '',
  `hreflang` varchar(20) NOT NULL DEFAULT '',
  `direction` varchar(3) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_language`
--

LOCK TABLES `sys_language` WRITE;
/*!40000 ALTER TABLE `sys_language` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_language` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_lockedrecords`
--

DROP TABLE IF EXISTS `sys_lockedrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_lockedrecords` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `record_table` varchar(255) NOT NULL DEFAULT '',
  `record_uid` int(11) NOT NULL DEFAULT 0,
  `record_pid` int(11) NOT NULL DEFAULT 0,
  `username` varchar(50) NOT NULL DEFAULT '',
  `feuserid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=4592 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_lockedrecords`
--

LOCK TABLES `sys_lockedrecords` WRITE;
/*!40000 ALTER TABLE `sys_lockedrecords` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_lockedrecords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_news`
--

DROP TABLE IF EXISTS `sys_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_news` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `content` mediumtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_news`
--

LOCK TABLES `sys_news` WRITE;
/*!40000 ALTER TABLE `sys_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_note`
--

DROP TABLE IF EXISTS `sys_note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_note` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `subject` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `message` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `personal` smallint(5) unsigned NOT NULL DEFAULT 0,
  `category` smallint(5) unsigned NOT NULL DEFAULT 0,
  `position` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_note`
--

LOCK TABLES `sys_note` WRITE;
/*!40000 ALTER TABLE `sys_note` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_refindex`
--

DROP TABLE IF EXISTS `sys_refindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_refindex` (
  `hash` varchar(32) NOT NULL DEFAULT '',
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `recuid` int(11) NOT NULL DEFAULT 0,
  `field` varchar(64) NOT NULL DEFAULT '',
  `flexpointer` varchar(255) NOT NULL DEFAULT '',
  `softref_key` varchar(30) NOT NULL DEFAULT '',
  `softref_id` varchar(40) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `deleted` smallint(6) NOT NULL DEFAULT 0,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `ref_table` varchar(255) NOT NULL DEFAULT '',
  `ref_uid` int(11) NOT NULL DEFAULT 0,
  `ref_string` varchar(1024) NOT NULL DEFAULT '',
  PRIMARY KEY (`hash`),
  KEY `lookup_rec` (`tablename`(100),`recuid`),
  KEY `lookup_uid` (`ref_table`(100),`ref_uid`),
  KEY `lookup_string` (`ref_string`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_refindex`
--

LOCK TABLES `sys_refindex` WRITE;
/*!40000 ALTER TABLE `sys_refindex` DISABLE KEYS */;
INSERT INTO `sys_refindex` VALUES ('01cb009e7852c4f428d7e298591a76ae','tx_grevman_domain_model_note',4,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('01f8b912eb8187c1e86fc215657a64ce','tx_grevman_domain_model_event',1,'registrations','','','',3,0,0,'tx_grevman_domain_model_registration',9,''),('0204000d4a4e2ef620d0b364d2e6f87c','tx_grevman_domain_model_group',2,'members','','','',3,0,0,'fe_users',15,''),('04e0adcc93e873137b87611176c47cf6','tx_grevman_domain_model_group',2,'members','','','',0,0,0,'fe_users',11,''),('099f32de05408ef16265c5151d3374ee','sys_file_metadata',13,'file','','','',0,0,0,'sys_file',157,''),('0f4689da842510666e5c180db7bff1d6','sys_file',160,'storage','','','',0,0,0,'sys_file_storage',1,''),('10a7bb014e60de546e797f7094044501','sys_file',159,'metadata','','','',0,0,0,'sys_file_metadata',15,''),('138bf8a5829d97585477a39f1c64efa8','tx_grevman_domain_model_event',2,'registrations','','','',3,0,0,'tx_grevman_domain_model_registration',7,''),('14c48df2bd95ce5fe34fd6d860d352c7','tx_grevman_domain_model_event',2,'registrations','','','',0,0,0,'tx_grevman_domain_model_registration',3,''),('16ac2ba4b044f2d38558832e8e4d9918','sys_file_metadata',11,'file','','','',0,0,0,'sys_file',132,''),('16c09a560a4456ca49fbcdfc36b48f90','tt_content',1015,'pi_flexform','sDEF/lDEF/settings.pages/vDEF/','','',0,0,0,'pages',223,''),('16ea39f012efe8f389568e407489adc7','fe_users',13,'registrations','','','',0,0,0,'tx_grevman_domain_model_registration',5,''),('18224243638d17705ba5114ebe4f7dab','tx_grevman_domain_model_group',2,'members','','','',2,0,0,'fe_users',13,''),('18e21a6b9c1ef4ffc10c2c8a195ace27','sys_file',154,'storage','','','',0,0,0,'sys_file_storage',1,''),('1af27c2ca6bb6fb45bfd146b8a09d747','tx_grevman_domain_model_group',1,'members','','','',2,0,0,'fe_users',14,''),('1b9697be81dbf7e30804bfce8d1d1421','tx_grevman_domain_model_event',1,'images','','','',0,0,0,'sys_file_reference',469,''),('1c6b3ffd36f17c70f12a4768a19549cc','sys_file',8,'storage','','','',0,0,0,'sys_file_storage',1,''),('1cfdd23f9f4e6e479ebab83fe681c9c5','sys_file',8,'metadata','','','',0,0,0,'sys_file_metadata',9,''),('1d8643261836802c9fff9d93d47c1627','fe_users',14,'usergroup','','','',0,0,0,'fe_groups',4,''),('22cc06ad269b284f4099bd7a829b3acc','tx_grevman_domain_model_registration',3,'member','','','',0,0,0,'fe_users',11,''),('282d5ea219f8a0c2e8e21d1ab16a380c','sys_file',149,'storage','','','',0,0,0,'sys_file_storage',1,''),('29424eaffe4e892fe4000115d2b4d5d5','sys_file',157,'storage','','','',0,0,0,'sys_file_storage',1,''),('2a4347d1cf93c71387f784df9bbc6365','tx_grevman_domain_model_event',1,'notes','','','',3,0,0,'tx_grevman_domain_model_note',4,''),('2a9f248233fb050239297f92ec071149','tx_grevman_domain_model_registration',6,'member','','','',0,0,0,'fe_users',16,''),('2c96bed31efed3180cf888507d8cb0b1','tx_grevman_domain_model_event',1,'registrations','','','',2,0,0,'tx_grevman_domain_model_registration',6,''),('2e4c4303d94202dcbebafd519372f730','tx_grevman_domain_model_event',1,'notes','','','',0,0,0,'tx_grevman_domain_model_note',1,''),('2fd742e028fe0ca0d14d236f6bbec820','tx_grevman_domain_model_note',5,'event','','','',0,0,0,'tx_grevman_domain_model_event',2,''),('367c38dbbb34b0fdc224df6ff3347f4c','tx_grevman_domain_model_registration',1,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('3730136e46b90c89adc7369bfa1bae43','sys_file_metadata',15,'file','','','',0,0,0,'sys_file',159,''),('37cfef152835132aa022478f8b03c76b','sys_file',154,'metadata','','','',0,0,0,'sys_file_metadata',3,''),('3f0338b68898aa3dc4a359a00e001ae0','sys_file',153,'storage','','','',0,0,0,'sys_file_storage',1,''),('3fd99083ae61269d051a3a1e52f1d037','tx_grevman_domain_model_event',2,'registrations','','','',1,0,0,'tx_grevman_domain_model_registration',4,''),('440ed6957be335484b4fcfa65b4d7afc','fe_users',10,'notes','','','',4,0,0,'tx_grevman_domain_model_note',5,''),('49f5b261c10ec452775ef504d417cc18','tx_grevman_domain_model_registration',5,'member','','','',0,0,0,'fe_users',13,''),('4a251fd4de86b8cbd0e2e7ac47550128','sys_file',9,'metadata','','','',0,0,0,'sys_file_metadata',5,''),('4c1caae8d89a57f4fa07cc63018f4075','sys_file_metadata',5,'file','','','',0,0,0,'sys_file',9,''),('4c7c08533e856a6a524f70ff4e82e915','sys_file',156,'metadata','','','',0,0,0,'sys_file_metadata',8,''),('5176e2db5d6ee2bc2c222bcf118e977b','sys_file',149,'metadata','','','',0,0,0,'sys_file_metadata',1,''),('5189a70b8f7d1e7047ba2f297fc8e06d','fe_users',12,'registrations','','','',0,0,0,'tx_grevman_domain_model_registration',4,''),('52a4161f81c6b2de9556128ff1e2a149','sys_file_reference',470,'uid_local','','','',0,0,0,'sys_file',154,''),('533df6a7c6ca585cc2f9f24ec1bcfc9c','tx_grevman_domain_model_registration',2,'member','','','',0,0,0,'fe_users',11,''),('53534cd6f6bacf264153265bab3c631f','tx_grevman_domain_model_registration',3,'event','','','',0,0,0,'tx_grevman_domain_model_event',2,''),('56247186f9f28bf598e1a4405ead5f77','sys_file',132,'storage','','','',0,0,0,'sys_file_storage',1,''),('56b7d9296369d0e9fb200a89ecef8cd2','sys_file',156,'storage','','','',0,0,0,'sys_file_storage',1,''),('585e5f148115d86b84f55effad6ff92c','tx_grevman_domain_model_group',1,'members','','','',0,0,0,'fe_users',10,''),('5861abc1656c2191c47a82b35eb879c6','sys_file_reference',469,'uid_local','','','',0,0,0,'sys_file',153,''),('58ff3fbece6fb3f5231ce06da504f70f','tx_grevman_domain_model_note',3,'member','','','',0,0,0,'fe_users',10,''),('59a3077df72718e572428cc883bea72c','fe_users',10,'notes','','','',0,0,0,'tx_grevman_domain_model_note',1,''),('5b881762b986130165828828c4621b74','tx_grevman_domain_model_registration',6,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('5c422f23adc530a5885d00758af7f904','sys_file',158,'metadata','','','',0,0,0,'sys_file_metadata',14,''),('606f1c4fdf4a389fca649caba815e452','tx_grevman_domain_model_note',2,'member','','','',0,0,0,'fe_users',10,''),('606f2cc25e7f6dbb84eeefc31cacedcd','tx_grevman_domain_model_note',1,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('60a50a17d03f17b5f9ba30d93fd81b6a','tx_grevman_domain_model_registration',4,'event','','','',0,0,0,'tx_grevman_domain_model_event',2,''),('6303c581826d5effaeae367eb4b881a7','tx_grevman_domain_model_event',1,'files','','','',0,0,0,'sys_file_reference',470,''),('6428b55d98ae893e7e386fb51120b410','sys_file',158,'storage','','','',0,0,0,'sys_file_storage',1,''),('64f04d2820c99349129c0ce55b66b3a5','fe_users',16,'usergroup','','','',0,0,0,'fe_groups',3,''),('6931a823f985a3a6c1163ed3492743d1','sys_file_metadata',9,'file','','','',0,0,0,'sys_file',8,''),('6a36beed9ff784b7aafdaa581f2fe6d3','sys_file_metadata',8,'file','','','',0,0,0,'sys_file',156,''),('6e14bc3f29eb0f54d2625384a09e4fe2','tx_grevman_domain_model_registration',7,'event','','','',0,0,0,'tx_grevman_domain_model_event',2,''),('71fbfedc9f9bd8eec01c5e8f516dbba5','fe_users',12,'usergroup','','','',0,0,0,'fe_groups',3,''),('74232e43786d98a976ce30e058ac11fe','tx_grevman_domain_model_event',2,'member_groups','','','',0,0,0,'tx_grevman_domain_model_group',2,''),('7ca2f14169a403f8ced06bc447d90f48','tx_grevman_domain_model_event',2,'notes','','','',0,0,0,'tx_grevman_domain_model_note',5,''),('7f16bed780b6bb1ef7d28f0705c256e7','tx_grevman_domain_model_event',2,'registrations','','','',2,0,0,'tx_grevman_domain_model_registration',5,''),('7f57eb3565315220ab1b4d2c85a262be','tx_grevman_domain_model_registration',1,'member','','','',0,0,0,'fe_users',10,''),('81bcd44042c4cd2c3ff749f0b527a649','tx_grevman_domain_model_registration',9,'member','','','',0,0,0,'fe_users',12,''),('838c5d608404ada62b12917c1b1a5e3a','tx_grevman_domain_model_event',1,'registrations','','','',1,0,0,'tx_grevman_domain_model_registration',2,''),('83ac951d8c25be6a8758d738d874a1ee','sys_file',10,'storage','','','',0,0,0,'sys_file_storage',1,''),('842da01c3a4b0ce0270152bde5d0930a','sys_file',131,'storage','','','',0,0,0,'sys_file_storage',1,''),('8522e237ae16c2cb7cd6a5e9700c0db9','sys_file',159,'storage','','','',0,0,0,'sys_file_storage',1,''),('85852137d6f1ff85b4fcaa47cd757b04','fe_users',10,'usergroup','','','',0,0,0,'fe_groups',3,''),('893e20b39f66903f90c681e8c41b6297','sys_file',3,'storage','','','',0,0,0,'sys_file_storage',1,''),('894e5abbf0935840bd26b3f426e968b3','tx_grevman_domain_model_event',1,'registrations','','','',0,0,0,'tx_grevman_domain_model_registration',1,''),('8a67dea5247f1ac6af58fcaa78a82576','sys_file_metadata',12,'file','','','',0,0,0,'sys_file',133,''),('8df08dc9fba8f86b82990ebbbadd7c13','fe_users',11,'registrations','','','',0,0,0,'tx_grevman_domain_model_registration',2,''),('935bf56f19abf10263af333b23fb7e78','sys_file_metadata',7,'file','','','',0,0,0,'sys_file',134,''),('9977e66c5865a8a5df336fcb7a5d2f59','sys_file_metadata',1,'file','','','',0,0,0,'sys_file',149,''),('9b7ce411ff080acf3c9e811d231554ba','sys_file_metadata',16,'file','','','',0,0,0,'sys_file',160,''),('9c0943aec6907e8882a475828725ab72','fe_users',10,'registrations','','','',0,0,0,'tx_grevman_domain_model_registration',1,''),('9c5e42231b9a316fb3bc2b1d44fd3cdf','sys_file_metadata',6,'file','','','',0,0,0,'sys_file',10,''),('a41d94dfba6c62893ad64790411bbb79','tx_grevman_domain_model_note',1,'member','','','',0,0,0,'fe_users',10,''),('a4ccd22794aa259f362a141b5349ff8a','tx_grevman_domain_model_registration',9,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('a576d18bb58bf2554266c975add5eabc','tx_grevman_domain_model_group',1,'members','','','',1,0,0,'fe_users',11,''),('a7b1bc88c81537449019c9052a1ab545','sys_file',3,'metadata','','','',0,0,0,'sys_file_metadata',4,''),('ace76d95bfcbb07b9caca03c29c85aa8','fe_users',11,'usergroup','','','',0,0,0,'fe_groups',3,''),('b2d512a742f7239a2321c9796018346f','fe_users',10,'notes','','','',1,0,0,'tx_grevman_domain_model_note',2,''),('b6a7601f4c3e71210caa68e1072752e5','tx_grevman_domain_model_note',4,'member','','','',0,0,0,'fe_users',10,''),('bab86bff5b0630894866fe8aaff620c2','sys_file',134,'metadata','','','',0,0,0,'sys_file_metadata',7,''),('bb8723624214941cb0e472034d5b31c8','sys_file_metadata',14,'file','','','',0,0,0,'sys_file',158,''),('c2db2d185e97fb2ed9859cfebdbe6718','sys_file',9,'storage','','','',0,0,0,'sys_file_storage',1,''),('c6037e489548db31e3d6a1da42dabcf3','tx_grevman_domain_model_registration',2,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('c71cd195955f5402f9410c7c77111195','sys_file',133,'metadata','','','',0,0,0,'sys_file_metadata',12,''),('c928091493edcdc7ed39f8f8aefe8393','tx_grevman_domain_model_event',1,'guests','','','',0,0,0,'tx_grevman_domain_model_guest',1,''),('cbca2cfbb7d6709d41a8f58c91ed5fc9','sys_file',10,'metadata','','','',0,0,0,'sys_file_metadata',6,''),('cc0835a91a2ae654f64deb38ce219501','fe_users',13,'usergroup','','','',0,0,0,'fe_groups',3,''),('d31346526510da096e893f7dff19ef42','tx_grevman_domain_model_note',2,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('d79ce914b37575ded27c428d76f477b6','fe_users',10,'registrations','','','',1,0,0,'tx_grevman_domain_model_registration',7,''),('d86b49f21dead4f88292a5a6b2e7c6e5','sys_file',161,'metadata','','','',0,0,0,'sys_file_metadata',17,''),('d88682a2dccb362600e2bf60030d0bb5','sys_file',133,'storage','','','',0,0,0,'sys_file_storage',1,''),('d9144f47a99deb66fdd41ff79cc8c772','fe_users',15,'usergroup','','','',0,0,0,'fe_groups',4,''),('d9da32922453ad27c5b3559db5fc3e82','tx_grevman_domain_model_event',1,'notes','','','',2,0,0,'tx_grevman_domain_model_note',3,''),('dae5aaba178217b95e034163eb916702','tx_grevman_domain_model_registration',7,'member','','','',0,0,0,'fe_users',10,''),('dcfe609dcdc1419e203b204d9cb97806','fe_users',16,'registrations','','','',0,0,0,'tx_grevman_domain_model_registration',6,''),('dd7df7432619d47e367e8ee8f18bac00','sys_file_metadata',3,'file','','','',0,0,0,'sys_file',154,''),('de3e4227bfc48d9074f1dcfe9b8fa821','sys_file',160,'metadata','','','',0,0,0,'sys_file_metadata',16,''),('de75d3422e6b4cbd7ff40272c5cc5a1e','fe_users',10,'notes','','','',2,0,0,'tx_grevman_domain_model_note',3,''),('e08ff63ae379a53ab0b017fa627a37f3','sys_file',153,'metadata','','','',0,0,0,'sys_file_metadata',2,''),('e1309f91a996007a8d03d76463649451','tx_grevman_domain_model_event',1,'notes','','','',1,0,0,'tx_grevman_domain_model_note',2,''),('e41fb6147c19a8248c8ea185507493d4','sys_file',157,'metadata','','','',0,0,0,'sys_file_metadata',13,''),('e56819111d15d25d89389c958cf6dccf','sys_file',132,'metadata','','','',0,0,0,'sys_file_metadata',11,''),('e5eb9473f660dbbe340e15cf40047cb2','sys_file_metadata',10,'file','','','',0,0,0,'sys_file',131,''),('e7df0dafb5fd50d0c5de44b75648b983','tx_grevman_domain_model_group',2,'members','','','',1,0,0,'fe_users',12,''),('e83f3d666be13ffe3a9042a459ce96f0','sys_file_metadata',2,'file','','','',0,0,0,'sys_file',153,''),('e895059f7502862e0426d074f93a7e7c','tx_grevman_domain_model_event',1,'member_groups','','','',0,0,0,'tx_grevman_domain_model_group',1,''),('eb1c46427bd721bf4a9c70b052103161','fe_users',12,'registrations','','','',1,0,0,'tx_grevman_domain_model_registration',9,''),('ed1894847977aafa423f995fcaee3826','sys_file',134,'storage','','','',0,0,0,'sys_file_storage',1,''),('ed9def4e795c51310ad067edfccc0eb7','tx_grevman_domain_model_registration',4,'member','','','',0,0,0,'fe_users',12,''),('ef16fd164356408bf178d6c7b29c9a08','tx_grevman_domain_model_note',3,'event','','','',0,0,0,'tx_grevman_domain_model_event',1,''),('ef841049530f6f5b418de5d0a6d7d7c5','tx_grevman_domain_model_note',5,'member','','','',0,0,0,'fe_users',10,''),('f07b8e2c8e8dece26f6e9ce4c9a85d2f','fe_users',10,'notes','','','',3,0,0,'tx_grevman_domain_model_note',4,''),('f17951f8a720ed2d637d2ce339af5bbb','tx_grevman_domain_model_registration',5,'event','','','',0,0,0,'tx_grevman_domain_model_event',2,''),('f478c879e596705782b023ec9310a31f','sys_file',131,'metadata','','','',0,0,0,'sys_file_metadata',10,''),('f4cc0ec07d9e36e638a3ebaeed8200a2','fe_users',11,'registrations','','','',1,0,0,'tx_grevman_domain_model_registration',3,''),('fae06194d499c4885944df1b67cfe7d3','sys_file',161,'storage','','','',0,0,0,'sys_file_storage',1,''),('fe178ae11c9d44f03eed68235f0e3130','tx_grevman_domain_model_event',2,'link','','typolink','f992614796c62361b6d1a023a4f61baa:0',-1,0,0,'pages',1,''),('ff13cb81328a7ac8aca161313df2d3db','sys_file_metadata',4,'file','','','',0,0,0,'sys_file',3,'');
/*!40000 ALTER TABLE `sys_refindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_registry`
--

DROP TABLE IF EXISTS `sys_registry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_registry` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_namespace` varchar(128) NOT NULL DEFAULT '',
  `entry_key` varchar(128) NOT NULL DEFAULT '',
  `entry_value` mediumblob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `entry_identifier` (`entry_namespace`,`entry_key`)
) ENGINE=InnoDB AUTO_INCREMENT=129 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_registry`
--

LOCK TABLES `sys_registry` WRITE;
/*!40000 ALTER TABLE `sys_registry` DISABLE KEYS */;
INSERT INTO `sys_registry` VALUES (1,'installUpdate','TYPO3\\CMS\\Install\\Updates\\ExtensionManagerTables','i:1;'),(2,'installUpdate','TYPO3\\CMS\\Install\\Updates\\WizardDoneToRegistry','i:1;'),(3,'installUpdate','TYPO3\\CMS\\Install\\Updates\\StartModuleUpdate','i:1;'),(4,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FrontendUserImageUpdateWizard','i:1;'),(5,'installUpdate','TYPO3\\CMS\\Install\\Updates\\DatabaseRowsUpdateWizard','i:1;'),(6,'installUpdate','TYPO3\\CMS\\Install\\Updates\\CommandLineBackendUserRemovalUpdate','i:1;'),(7,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FillTranslationSourceField','i:1;'),(8,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SectionFrameToFrameClassUpdate','i:1;'),(9,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SplitMenusUpdate','i:1;'),(10,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BulletContentElementUpdate','i:1;'),(11,'installUpdate','TYPO3\\CMS\\Install\\Updates\\UploadContentElementUpdate','i:1;'),(12,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigrateFscStaticTemplateUpdate','i:1;'),(13,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FileReferenceUpdate','i:1;'),(14,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigrateFeSessionDataUpdate','i:1;'),(15,'installUpdate','TYPO3\\CMS\\Install\\Updates\\Compatibility7ExtractionUpdate','i:1;'),(16,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FormLegacyExtractionUpdate','i:1;'),(17,'installUpdate','TYPO3\\CMS\\Install\\Updates\\RteHtmlAreaExtractionUpdate','i:1;'),(18,'installUpdate','TYPO3\\CMS\\Install\\Updates\\LanguageSortingUpdate','i:1;'),(19,'installUpdate','TYPO3\\CMS\\Install\\Updates\\Typo3DbExtractionUpdate','i:1;'),(20,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FuncExtractionUpdate','i:1;'),(21,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigrateUrlTypesInPagesUpdate','i:1;'),(22,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SeparateSysHistoryFromSysLogUpdate','i:1;'),(23,'installUpdate','TYPO3\\CMS\\Install\\Updates\\RedirectExtractionUpdate','i:1;'),(24,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendUserStartModuleUpdate','i:1;'),(25,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigratePagesLanguageOverlayUpdate','i:1;'),(26,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigratePagesLanguageOverlayBeGroupsAccessRights','i:1;'),(27,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendLayoutIconUpdateWizard','i:1;'),(28,'installUpdate','TYPO3\\CMS\\Install\\Updates\\RedirectsExtensionUpdate','i:1;'),(29,'installUpdate','TYPO3\\CMS\\Install\\Updates\\AdminPanelInstall','i:1;'),(30,'installUpdate','TYPO3\\CMS\\Install\\Updates\\PopulatePageSlugs','i:1;'),(31,'installUpdate','TYPO3\\CMS\\Install\\Updates\\Argon2iPasswordHashes','i:1;'),(32,'installUpdate','TYPO3\\CMS\\Form\\Hooks\\FormFileExtensionUpdate','i:1;'),(34,'extensionDataImport','typo3conf/ext/news/ext_tables_static+adt.sql','s:0:\"\";'),(35,'extensionDataImport','typo3conf/ext/bootstrap_package/ext_tables_static+adt.sql','s:0:\"\";'),(36,'extensionDataImport','typo3conf/ext/vhs/ext_tables_static+adt.sql','s:0:\"\";'),(37,'extensionDataImport','typo3conf/ext/gridelements/ext_tables_static+adt.sql','s:0:\"\";'),(38,'extensionDataImport','typo3conf/ext/slickcarousel/ext_tables_static+adt.sql','s:0:\"\";'),(39,'extensionDataImport','typo3conf/ext/ws_flexslider/ext_tables_static+adt.sql','s:0:\"\";'),(40,'extensionDataImport','typo3/sysext/indexed_search/ext_tables_static+adt.sql','s:0:\"\";'),(41,'extensionDataImport','typo3conf/ext/user_customer/Initialisation/Files','i:1;'),(42,'extensionDataImport','typo3conf/ext/user_customer/ext_tables_static+adt.sql','s:0:\"\";'),(43,'extensionDataImport','typo3conf/ext/pizpalue/Initialisation/Files','i:1;'),(44,'extensionDataImport','typo3conf/ext/pizpalue/ext_tables_static+adt.sql','s:0:\"\";'),(45,'extensionDataImport','typo3conf/ext/pizpalue/Initialisation/dataImported','i:1;'),(46,'extensionDataImport','typo3conf/ext/timelog/ext_tables_static+adt.sql','s:0:\"\";'),(47,'extensionDataImport','typo3/sysext/feedit/ext_tables_static+adt.sql','s:0:\"\";'),(48,'extensionDataImport','typo3conf/ext/frontend_editing/ext_tables_static+adt.sql','s:0:\"\";'),(49,'extensionDataImport','typo3conf/ext/tt_address/ext_tables_static+adt.sql','s:0:\"\";'),(56,'languagePacks','baseUrl','s:33:\"https://localize.typo3.org/xliff/\";'),(57,'languagePacks','de-pizpalue','i:1585553744;'),(58,'languagePacks','de-slickcarousel','i:1585553744;'),(59,'languagePacks','de-timelog','i:1585553747;'),(60,'languagePacks','de-ws_flexslider','i:1585553747;'),(61,'languagePacks','de','i:1624432022;'),(62,'extensionDataImport','typo3conf/ext/auxlibs/ext_tables_static+adt.sql','s:0:\"\";'),(64,'extensionDataImport','typo3conf/ext/extension_builder/ext_tables_static+adt.sql','s:0:\"\";'),(65,'extensionDataImport','typo3/sysext/seo/ext_tables_static+adt.sql','s:0:\"\";'),(66,'extensionDataImport','typo3conf/ext/flux/ext_tables_static+adt.sql','s:0:\"\";'),(67,'extensionDataImport','typo3conf/ext/ppflux/ext_tables_static+adt.sql','s:0:\"\";'),(68,'extensionDataImport','typo3conf/ext/flux_element/ext_tables_static+adt.sql','s:0:\"\";'),(69,'extensionDataImport','typo3conf/ext/flux_elements/ext_tables_static+adt.sql','s:0:\"\";'),(70,'languagePacks','de-flux_elements','i:1585553741;'),(71,'languagePacks','de-user_customer','i:1585553747;'),(73,'extensionDataImport','typo3conf/ext/pp_gridelements/ext_tables_static+adt.sql','s:0:\"\";'),(74,'extensionDataImport','typo3conf/ext/books/ext_tables_static+adt.sql','s:0:\"\";'),(75,'extensionDataImport','typo3conf/ext/pizpalue_distribution/ext_tables_static+adt.sql','s:0:\"\";'),(76,'extensionDataImport','typo3conf/ext/pizpalue_distribution/Initialisation/dataImported','i:1;'),(77,'extensionDataImport','typo3/sysext/setup/ext_tables_static+adt.sql','s:0:\"\";'),(78,'extensionDataImport','typo3conf/ext/delme/ext_tables_static+adt.sql','s:0:\"\";'),(79,'installUpdate','TYPO3\\CMS\\Install\\Updates\\RsaauthExtractionUpdate','i:1;'),(80,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FeeditExtractionUpdate','i:1;'),(81,'installUpdate','TYPO3\\CMS\\Install\\Updates\\TaskcenterExtractionUpdate','i:1;'),(82,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysActionExtractionUpdate','i:1;'),(83,'siteConfigImport','default','i:1;'),(84,'extensionDataImport','typo3conf/ext/di_examples/ext_tables_static+adt.sql','s:0:\"\";'),(85,'extensionDataImport','typo3conf/ext/user_pizpalue/Initialisation/Files','i:1;'),(86,'extensionDataImport','typo3conf/ext/user_pizpalue/ext_tables_static+adt.sql','s:0:\"\";'),(87,'extensionDataImport','typo3conf/ext/container/ext_tables_static+adt.sql','s:0:\"\";'),(88,'extensionDataImport','typo3conf/ext/container_elements/ext_tables_static+adt.sql','s:0:\"\";'),(89,'extensionDataImport','typo3conf/ext/wasist/ext_tables_static+adt.sql','s:0:\"\";'),(90,'extensionDataImport','typo3conf/ext/realer/ext_tables_static+adt.sql','s:0:\"\";'),(91,'extensionDataImport','typo3/sysext/t3editor/ext_tables_static+adt.sql','s:0:\"\";'),(92,'extensionDataImport','typo3conf/ext/eventnews/ext_tables_static+adt.sql','s:0:\"\";'),(101,'extensionDataImport','typo3conf/ext/vinfo/ext_tables_static+adt.sql','s:0:\"\";'),(102,'extensionDataImport','typo3conf/ext/vinfo/Initialisation/Files','i:1;'),(105,'core','formProtectionSessionToken:3','s:64:\"623f02b0171e0daa5a58d2e763ac4372456dc32f393d301d3bcb4ef766c304a9\";'),(106,'core','formProtectionSessionToken:4','s:64:\"0bd617c9bc8cb1bc7ec8ed24d8ea30cbfb19cc5b6ea3dde626c79cfc1c02a9ba\";'),(108,'extensionDataImport','typo3conf/ext/typoscript_rendering/ext_tables_static+adt.sql','s:0:\"\";'),(109,'extensionDataImport','typo3conf/ext/bookmark_pages/ext_tables_static+adt.sql','s:0:\"\";'),(110,'extensionDataImport','typo3/sysext/felogin/ext_tables_static+adt.sql','s:0:\"\";'),(111,'extensionDataImport','typo3conf/ext/powermail/ext_tables_static+adt.sql','s:0:\"\";'),(112,'languagePacks','de-container','i:1624432017;'),(113,'languagePacks','de-bookmark_pages','i:1619683385;'),(114,'extensionDataImport','typo3conf/ext/grevman/ext_tables_static+adt.sql','s:0:\"\";'),(115,'languagePacks','de-grevman','i:1624432019;'),(116,'languagePacks','de-user_pizpalue','i:1624432022;'),(117,'languagePacks','de-wasist','i:1624432022;'),(118,'extensionDataImport','typo3conf/ext/user_grevman/ext_tables_static+adt.sql','s:0:\"\";'),(119,'extensionDataImport','typo3/sysext/recycler/ext_tables_static+adt.sql','s:0:\"\";'),(123,'core','formProtectionSessionToken:1','s:64:\"5051dfa07cd033fa669fc8f3dfeffee9d01b1bf8aebfe54927ef2b76aa0aa352\";'),(124,'extensionDataImport','typo3conf/ext/femanager/ext_tables_static+adt.sql','s:0:\"\";'),(125,'extensionDataImport','typo3conf/ext/grevman/Initialisation/Files','i:1;'),(126,'core','sys_refindex_lastUpdate','i:1634550263;'),(127,'extensionDataImport','typo3/sysext/scheduler/ext_tables_static+adt.sql','s:0:\"\";'),(128,'tx_scheduler','lastRun','a:3:{s:5:\"start\";i:1634550227;s:3:\"end\";i:1634550227;s:4:\"type\";s:6:\"manual\";}');
/*!40000 ALTER TABLE `sys_registry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_template`
--

DROP TABLE IF EXISTS `sys_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_template` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `sitetitle` varchar(255) NOT NULL DEFAULT '',
  `root` smallint(5) unsigned NOT NULL DEFAULT 0,
  `clear` smallint(5) unsigned NOT NULL DEFAULT 0,
  `include_static_file` text DEFAULT NULL,
  `constants` text DEFAULT NULL,
  `config` text DEFAULT NULL,
  `basedOn` tinytext DEFAULT NULL,
  `includeStaticAfterBasedOn` smallint(5) unsigned NOT NULL DEFAULT 0,
  `static_file_mode` smallint(5) unsigned NOT NULL DEFAULT 0,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `roottemplate` (`deleted`,`hidden`,`root`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_template`
--

LOCK TABLES `sys_template` WRITE;
/*!40000 ALTER TABLE `sys_template` DISABLE KEYS */;
INSERT INTO `sys_template` VALUES (3,1,1634544826,1550653971,1,0,0,0,0,256,'',0,0,0,0,0,0,0,0,'Pizpalue','',1,3,'EXT:bootstrap_package/Configuration/TypoScript,EXT:form/Configuration/TypoScript/,EXT:pizpalue/Configuration/TypoScript/Main','pizpalue.agency.siteMode = 1','','',0,0,2),(27,223,1624698849,1624374369,1,0,0,0,0,256,NULL,0,0,0,0,0,0,0,0,'+ext','',0,0,'EXT:grevman/Configuration/TypoScript',NULL,NULL,'',0,0,0);
/*!40000 ALTER TABLE `sys_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tt_content`
--

DROP TABLE IF EXISTS `tt_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tt_content` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rowDescription` text DEFAULT NULL,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l18n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l18n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `CType` varchar(255) NOT NULL DEFAULT '',
  `header` varchar(255) NOT NULL DEFAULT '',
  `header_position` varchar(255) NOT NULL DEFAULT '',
  `bodytext` mediumtext DEFAULT NULL,
  `bullets_type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_description` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `assets` int(10) unsigned NOT NULL DEFAULT 0,
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `imagewidth` int(10) unsigned NOT NULL DEFAULT 0,
  `imageorient` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imagecols` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imageborder` smallint(5) unsigned NOT NULL DEFAULT 0,
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` varchar(255) NOT NULL DEFAULT '',
  `frame_class` varchar(60) NOT NULL DEFAULT 'default',
  `cols` int(10) unsigned NOT NULL DEFAULT 0,
  `space_before_class` varchar(60) NOT NULL DEFAULT '',
  `space_after_class` varchar(60) NOT NULL DEFAULT '',
  `records` text DEFAULT NULL,
  `pages` text DEFAULT NULL,
  `colPos` int(10) unsigned NOT NULL DEFAULT 0,
  `subheader` varchar(255) NOT NULL DEFAULT '',
  `header_link` varchar(1024) NOT NULL DEFAULT '',
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  `header_layout` varchar(30) NOT NULL DEFAULT '0',
  `list_type` varchar(255) NOT NULL DEFAULT '',
  `sectionIndex` smallint(5) unsigned NOT NULL DEFAULT 0,
  `linkToTop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `file_collections` text DEFAULT NULL,
  `filelink_size` smallint(5) unsigned NOT NULL DEFAULT 0,
  `filelink_sorting` varchar(64) NOT NULL DEFAULT '',
  `filelink_sorting_direction` varchar(4) NOT NULL DEFAULT '',
  `target` varchar(30) NOT NULL DEFAULT '',
  `date` int(10) unsigned NOT NULL DEFAULT 0,
  `recursive` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imageheight` int(10) unsigned NOT NULL DEFAULT 0,
  `pi_flexform` mediumtext DEFAULT NULL,
  `accessibility_title` varchar(30) NOT NULL DEFAULT '',
  `accessibility_bypass` smallint(5) unsigned NOT NULL DEFAULT 0,
  `accessibility_bypass_text` varchar(30) NOT NULL DEFAULT '',
  `selected_categories` text DEFAULT NULL,
  `category_field` varchar(64) NOT NULL DEFAULT '',
  `table_class` varchar(60) NOT NULL DEFAULT '',
  `table_caption` varchar(255) DEFAULT NULL,
  `table_delimiter` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_enclosure` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_header_position` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_tfoot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `categories` int(11) NOT NULL DEFAULT 0,
  `teaser` text DEFAULT NULL,
  `readmore_label` varchar(255) NOT NULL DEFAULT '',
  `quote_source` varchar(255) NOT NULL DEFAULT '',
  `quote_link` varchar(1024) NOT NULL DEFAULT '',
  `panel_class` varchar(60) NOT NULL DEFAULT 'default',
  `file_folder` text DEFAULT NULL,
  `icon` varchar(255) NOT NULL DEFAULT '',
  `icon_set` varchar(255) NOT NULL DEFAULT '',
  `icon_file` int(10) unsigned DEFAULT 0,
  `icon_position` varchar(255) NOT NULL DEFAULT '',
  `icon_size` varchar(60) NOT NULL DEFAULT 'default',
  `icon_type` varchar(60) NOT NULL DEFAULT 'default',
  `icon_color` varchar(255) NOT NULL DEFAULT '',
  `icon_background` varchar(255) NOT NULL DEFAULT '',
  `external_media_source` varchar(1024) NOT NULL DEFAULT '',
  `external_media_ratio` varchar(10) NOT NULL DEFAULT '',
  `tx_bootstrappackage_card_group_item` int(10) unsigned DEFAULT 0,
  `tx_bootstrappackage_carousel_item` int(10) unsigned DEFAULT 0,
  `tx_bootstrappackage_accordion_item` int(10) unsigned DEFAULT 0,
  `tx_bootstrappackage_icon_group_item` int(10) unsigned DEFAULT 0,
  `tx_bootstrappackage_tab_item` int(10) unsigned DEFAULT 0,
  `tx_bootstrappackage_timeline_item` int(10) unsigned DEFAULT 0,
  `background_color_class` varchar(255) NOT NULL DEFAULT '',
  `background_image` int(10) unsigned DEFAULT 0,
  `background_image_options` mediumtext DEFAULT NULL,
  `tx_pizpalue_classes` varchar(255) NOT NULL DEFAULT '',
  `tx_pizpalue_style` text DEFAULT NULL,
  `tx_pizpalue_attributes` varchar(255) NOT NULL DEFAULT '',
  `tx_pizpalue_animation` varchar(255) NOT NULL DEFAULT '',
  `tx_pizpalue_image_variants` varchar(255) NOT NULL DEFAULT 'variants',
  `tx_pizpalue_image_scaling` text DEFAULT NULL,
  `tx_pizpalue_layout_breakpoint` varchar(15) NOT NULL DEFAULT '',
  `aspect_ratio` varchar(255) NOT NULL DEFAULT '1.3333333333333',
  `items_per_page` int(10) unsigned DEFAULT 10,
  `tx_pizpalue_background_image_variants` varchar(255) NOT NULL DEFAULT 'pageVariants',
  `tx_container_parent` int(11) NOT NULL DEFAULT 0,
  `tx_pizpalue_header_class` varchar(255) NOT NULL DEFAULT '',
  `tx_pizpalue_subheader_class` varchar(255) NOT NULL DEFAULT '',
  `tx_pizpalue_image_aspect_ratio` text DEFAULT NULL,
  `frame_layout` varchar(255) NOT NULL DEFAULT 'default',
  `frame_options` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`sorting`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l18n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`),
  KEY `container_parent` (`tx_container_parent`)
) ENGINE=InnoDB AUTO_INCREMENT=1034 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tt_content`
--

LOCK TABLES `tt_content` WRITE;
/*!40000 ALTER TABLE `tt_content` DISABLE KEYS */;
INSERT INTO `tt_content` VALUES (344,NULL,1,1634545047,1550653971,1,0,0,0,0,'',2624,0,0,0,0,NULL,0,'a:37:{s:5:\"CType\";N;s:6:\"colPos\";N;s:19:\"tx_container_parent\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:24:\"tx_pizpalue_header_class\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:27:\"tx_pizpalue_subheader_class\";N;s:8:\"bodytext\";N;s:6:\"layout\";N;s:29:\"tx_pizpalue_layout_breakpoint\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:11:\"frame_class\";N;s:12:\"frame_layout\";N;s:13:\"frame_options\";N;s:22:\"background_color_class\";N;s:16:\"background_image\";N;s:24:\"background_image_options\";N;s:37:\"tx_pizpalue_background_image_variants\";N;s:21:\"tx_pizpalue_animation\";N;s:19:\"tx_pizpalue_classes\";N;s:17:\"tx_pizpalue_style\";N;s:22:\"tx_pizpalue_attributes\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,'text','Kundeninfo','','<p><strong>###ppCustomerCompany###</strong><br /> ###ppCustomerContactAddress###<br /> ###ppCustomerContactZip### ###ppCustomerContactCity###</p>',0,0,0,0,0,0,0,1,0,0,'0','default',0,'','','','',10,'','',0,'100','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,207,0,'','','','','default','','','',0,'0','default','default','','','','',0,0,0,0,0,0,'none',0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"parallax\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fade\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"filter\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"behaviour\">\n                    <value index=\"vDEF\">cover</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','','','','0','variants',NULL,'','1.3333333333333',10,'pageVariants',0,'none','none','0','default',''),(1014,'',223,1624372778,1624372778,1,0,0,0,0,'',256,0,0,0,0,NULL,0,'',0,0,0,0,0,0,0,'list','','',NULL,0,0,0,0,0,0,0,2,0,0,'0','default',0,'','',NULL,'',0,'','',0,'0','grevman_events',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0,NULL,'','','','default',NULL,'','',0,'','default','default','#FFFFFF','#333333','','',0,0,0,0,0,0,'none',0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"parallax\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fade\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"filter\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','','','','0','variants','xl: 1.0,\nlg: 1.0,\nmd: 1.0,\nsm: 1.0,\nxs: 1.0','','1.3333333333333',10,'pageVariants',0,'none','none','xl: 0,\nlg: 0,\nmd: 0,\nsm: 0,\nxs: 0','default',''),(1015,'',227,1624547430,1624547430,1,0,0,0,0,'',256,0,0,0,0,NULL,0,'',0,0,0,0,0,0,0,'login','','',NULL,0,0,0,0,0,0,0,2,0,0,'0','default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.showForgotPassword\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.showPermaLogin\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"settings.showLogoutFormAfterLogin\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.pages\">\n                    <value index=\"vDEF\">223</value>\n                </field>\n                <field index=\"settings.recursive\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"s_redirect\">\n            <language index=\"lDEF\">\n                <field index=\"settings.redirectMode\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.redirectFirstMethod\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.redirectPageLogin\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.redirectPageLoginError\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.redirectPageLogout\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.redirectDisable\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"s_messages\">\n            <language index=\"lDEF\">\n                <field index=\"settings.welcome_header\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.welcome_message\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.success_header\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.success_message\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.error_header\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.error_message\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.status_header\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.status_message\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.logout_header\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.logout_message\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.forgot_header\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.forgot_reset_message\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'',NULL,'','',NULL,124,0,0,0,0,0,NULL,'','','','default',NULL,'','',0,'','default','default','#FFFFFF','#333333','','',0,0,0,0,0,0,'none',0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"parallax\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fade\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"filter\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','','','','0','variants','xl: 1.0,\nlg: 1.0,\nmd: 1.0,\nsm: 1.0,\nxs: 1.0','','1.3333333333333',10,'pageVariants',0,'none','none','xl: 0,\nlg: 0,\nmd: 0,\nsm: 0,\nxs: 0','default',''),(1033,'',1,1633542717,1633542717,1,0,0,0,0,'',1312,0,0,0,0,NULL,0,'',0,0,0,0,0,0,0,'header','Grevman development site','center',NULL,0,0,0,0,0,0,0,1,0,0,'0','default',0,'','',NULL,NULL,0,'','',0,'1','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0,NULL,'','','','default',NULL,'','',0,'','default','default','#FFFFFF','#333333','','',0,0,0,0,0,0,'primary',0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"behaviour\">\n                    <value index=\"vDEF\">cover</value>\n                </field>\n                <field index=\"parallax\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fade\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"filter\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','','','','0','variants','xxl: 1.0,\nxl: 1.0,\nlg: 1.0,\nmd: 1.0,\nsm: 1.0,\nxs: 1.0','','1.3333333333333',10,'pageVariants',0,'none','none','xxl: 0,\nxl: 0,\nlg: 0,\nmd: 0,\nsm: 0,\nxs: 0','default','');
/*!40000 ALTER TABLE `tt_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_bootstrappackage_accordion_item`
--

DROP TABLE IF EXISTS `tx_bootstrappackage_accordion_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_bootstrappackage_accordion_item` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) NOT NULL DEFAULT '',
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `tt_content` int(10) unsigned DEFAULT 0,
  `header` varchar(255) NOT NULL DEFAULT '',
  `bodytext` text DEFAULT NULL,
  `media` int(10) unsigned DEFAULT 0,
  `mediaorient` varchar(60) NOT NULL DEFAULT 'left',
  `imagecols` smallint(5) unsigned NOT NULL DEFAULT 1,
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l10n_parent`,`sys_language_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_bootstrappackage_accordion_item`
--

LOCK TABLES `tx_bootstrappackage_accordion_item` WRITE;
/*!40000 ALTER TABLE `tx_bootstrappackage_accordion_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_bootstrappackage_accordion_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_bootstrappackage_card_group_item`
--

DROP TABLE IF EXISTS `tx_bootstrappackage_card_group_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_bootstrappackage_card_group_item` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) NOT NULL DEFAULT '',
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `tt_content` int(10) unsigned DEFAULT 0,
  `header` varchar(255) NOT NULL DEFAULT '',
  `subheader` varchar(255) NOT NULL DEFAULT '',
  `image` int(11) NOT NULL DEFAULT 0,
  `bodytext` text DEFAULT NULL,
  `link` varchar(1024) NOT NULL DEFAULT '',
  `link_title` varchar(255) NOT NULL DEFAULT '',
  `link_icon` int(10) unsigned DEFAULT 0,
  `link_class` varchar(255) NOT NULL DEFAULT '',
  `link_icon_set` varchar(255) NOT NULL DEFAULT '',
  `link_icon_identifier` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l10n_parent`,`sys_language_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_bootstrappackage_card_group_item`
--

LOCK TABLES `tx_bootstrappackage_card_group_item` WRITE;
/*!40000 ALTER TABLE `tx_bootstrappackage_card_group_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_bootstrappackage_card_group_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_bootstrappackage_carousel_item`
--

DROP TABLE IF EXISTS `tx_bootstrappackage_carousel_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_bootstrappackage_carousel_item` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) NOT NULL DEFAULT '',
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `tt_content` int(10) unsigned DEFAULT 0,
  `item_type` varchar(255) NOT NULL DEFAULT '',
  `header` varchar(255) NOT NULL DEFAULT '',
  `header_layout` smallint(5) unsigned NOT NULL DEFAULT 1,
  `header_class` varchar(255) NOT NULL DEFAULT '',
  `subheader` varchar(255) NOT NULL DEFAULT '',
  `subheader_layout` smallint(5) unsigned NOT NULL DEFAULT 2,
  `subheader_class` varchar(255) NOT NULL DEFAULT '',
  `nav_title` varchar(255) NOT NULL DEFAULT '',
  `button_text` varchar(255) NOT NULL DEFAULT '',
  `bodytext` text DEFAULT NULL,
  `image` int(10) unsigned DEFAULT 0,
  `link` varchar(1024) NOT NULL DEFAULT '',
  `text_color` varchar(255) NOT NULL DEFAULT '',
  `background_color` varchar(255) NOT NULL DEFAULT '',
  `background_image` int(10) unsigned DEFAULT 0,
  `background_image_options` mediumtext DEFAULT NULL,
  `header_position` varchar(255) NOT NULL DEFAULT 'center',
  `layout` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l10n_parent`,`sys_language_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_bootstrappackage_carousel_item`
--

LOCK TABLES `tx_bootstrappackage_carousel_item` WRITE;
/*!40000 ALTER TABLE `tx_bootstrappackage_carousel_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_bootstrappackage_carousel_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_bootstrappackage_icon_group_item`
--

DROP TABLE IF EXISTS `tx_bootstrappackage_icon_group_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_bootstrappackage_icon_group_item` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) NOT NULL DEFAULT '',
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `tt_content` int(10) unsigned DEFAULT 0,
  `header` varchar(255) NOT NULL DEFAULT '',
  `subheader` varchar(255) NOT NULL DEFAULT '',
  `icon_file` int(10) unsigned DEFAULT 0,
  `link` varchar(1024) NOT NULL DEFAULT '',
  `bodytext` text DEFAULT NULL,
  `icon_set` varchar(255) NOT NULL DEFAULT '',
  `icon_identifier` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l10n_parent`,`sys_language_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_bootstrappackage_icon_group_item`
--

LOCK TABLES `tx_bootstrappackage_icon_group_item` WRITE;
/*!40000 ALTER TABLE `tx_bootstrappackage_icon_group_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_bootstrappackage_icon_group_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_bootstrappackage_tab_item`
--

DROP TABLE IF EXISTS `tx_bootstrappackage_tab_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_bootstrappackage_tab_item` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) NOT NULL DEFAULT '',
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `tt_content` int(10) unsigned DEFAULT 0,
  `header` varchar(255) NOT NULL DEFAULT '',
  `bodytext` text DEFAULT NULL,
  `media` int(10) unsigned DEFAULT 0,
  `mediaorient` varchar(60) NOT NULL DEFAULT 'left',
  `imagecols` smallint(5) unsigned NOT NULL DEFAULT 1,
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l10n_parent`,`sys_language_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_bootstrappackage_tab_item`
--

LOCK TABLES `tx_bootstrappackage_tab_item` WRITE;
/*!40000 ALTER TABLE `tx_bootstrappackage_tab_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_bootstrappackage_tab_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_bootstrappackage_timeline_item`
--

DROP TABLE IF EXISTS `tx_bootstrappackage_timeline_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_bootstrappackage_timeline_item` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) NOT NULL DEFAULT '',
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `tt_content` int(10) unsigned DEFAULT 0,
  `date` datetime DEFAULT NULL,
  `header` varchar(255) NOT NULL DEFAULT '',
  `bodytext` text DEFAULT NULL,
  `icon_file` int(10) unsigned DEFAULT 0,
  `image` int(10) unsigned DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `icon_set` varchar(255) NOT NULL DEFAULT '',
  `icon_identifier` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l10n_parent`,`sys_language_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_bootstrappackage_timeline_item`
--

LOCK TABLES `tx_bootstrappackage_timeline_item` WRITE;
/*!40000 ALTER TABLE `tx_bootstrappackage_timeline_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_bootstrappackage_timeline_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_extensionmanager_domain_model_extension`
--

DROP TABLE IF EXISTS `tx_extensionmanager_domain_model_extension`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_extensionmanager_domain_model_extension` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `extension_key` varchar(60) NOT NULL DEFAULT '',
  `repository` int(10) unsigned NOT NULL DEFAULT 1,
  `version` varchar(15) NOT NULL DEFAULT '',
  `alldownloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `downloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(150) NOT NULL DEFAULT '',
  `description` mediumtext DEFAULT NULL,
  `state` int(11) NOT NULL DEFAULT 0,
  `review_state` int(11) NOT NULL DEFAULT 0,
  `category` int(11) NOT NULL DEFAULT 0,
  `last_updated` int(10) unsigned NOT NULL DEFAULT 0,
  `serialized_dependencies` mediumtext DEFAULT NULL,
  `author_name` varchar(255) NOT NULL DEFAULT '',
  `author_email` varchar(255) NOT NULL DEFAULT '',
  `ownerusername` varchar(50) NOT NULL DEFAULT '',
  `md5hash` varchar(35) NOT NULL DEFAULT '',
  `update_comment` mediumtext DEFAULT NULL,
  `authorcompany` varchar(255) NOT NULL DEFAULT '',
  `integer_version` int(11) NOT NULL DEFAULT 0,
  `current_version` int(11) NOT NULL DEFAULT 0,
  `lastreviewedversion` int(11) NOT NULL DEFAULT 0,
  `documentation_link` varchar(2048) DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `versionextrepo` (`extension_key`,`version`,`repository`),
  KEY `index_extrepo` (`extension_key`,`repository`),
  KEY `index_versionrepo` (`integer_version`,`repository`,`extension_key`),
  KEY `index_currentversions` (`current_version`,`review_state`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_extensionmanager_domain_model_extension`
--

LOCK TABLES `tx_extensionmanager_domain_model_extension` WRITE;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_extensionmanager_domain_model_repository`
--

DROP TABLE IF EXISTS `tx_extensionmanager_domain_model_repository`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_extensionmanager_domain_model_repository` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(150) NOT NULL DEFAULT '',
  `description` mediumtext DEFAULT NULL,
  `wsdl_url` varchar(100) NOT NULL DEFAULT '',
  `mirror_list_url` varchar(100) NOT NULL DEFAULT '',
  `last_update` int(10) unsigned NOT NULL DEFAULT 0,
  `extension_count` int(11) NOT NULL DEFAULT 0,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_extensionmanager_domain_model_repository`
--

LOCK TABLES `tx_extensionmanager_domain_model_repository` WRITE;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_repository` DISABLE KEYS */;
INSERT INTO `tx_extensionmanager_domain_model_repository` VALUES (1,'TYPO3.org Main Repository','Main repository on typo3.org. This repository has some mirrors configured which are available with the mirror url.','https://typo3.org/wsdl/tx_ter_wsdl.php','https://repositories.typo3.org/mirrors.xml.gz',1624267671,1806,0);
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_repository` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_grevman_domain_model_event`
--

DROP TABLE IF EXISTS `tx_grevman_domain_model_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_grevman_domain_model_event` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `member_groups` int(10) unsigned NOT NULL DEFAULT 0,
  `registrations` int(10) unsigned NOT NULL DEFAULT 0,
  `notes` int(10) unsigned NOT NULL DEFAULT 0,
  `guests` int(10) unsigned NOT NULL DEFAULT 0,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `startdate` int(11) NOT NULL DEFAULT 0,
  `enddate` int(11) NOT NULL DEFAULT 0,
  `teaser` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` double NOT NULL DEFAULT 0,
  `link` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `program` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `images` int(10) unsigned NOT NULL DEFAULT 0,
  `files` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_grevman_domain_model_event`
--

LOCK TABLES `tx_grevman_domain_model_event` WRITE;
/*!40000 ALTER TABLE `tx_grevman_domain_model_event` DISABLE KEYS */;
INSERT INTO `tx_grevman_domain_model_event` VALUES (1,224,1634113031,1624338623,1,0,0,0,0,NULL,'a:18:{s:5:\"title\";N;s:4:\"slug\";N;s:9:\"startdate\";N;s:7:\"enddate\";N;s:6:\"teaser\";N;s:11:\"description\";N;s:7:\"program\";N;s:4:\"link\";N;s:8:\"location\";N;s:5:\"price\";N;s:6:\"images\";N;s:5:\"files\";N;s:13:\"member_groups\";N;s:13:\"registrations\";N;s:5:\"notes\";N;s:6:\"guests\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;}',0,0,0,0,0,0,0,'event1',1,4,4,1,'event1',1690556880,0,'<p>Teaser text goes here. Teaser text goes here. Teaser text goes here. Teaser text goes here. Teaser text goes here. Teaser text goes here. Teaser text goes here. Teaser text goes here. Teaser text goes here. Teaser text goes here. Teaser text goes here. Teaser text goes here. Teaser text goes here. Teaser text goes here.</p>','<p>Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here.</p>\r\n<p>Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here. Description goes here.</p>',50,'https://www.diemtigtal.ch/','<p>Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here. Program goes here.</p>\r\n<ol> 	<li>Start</li> 	<li>Pause</li> 	<li>Teil1</li> 	<li>Pause</li> 	<li>Teil2</li> 	<li>Üben</li> 	<li>Zusammenfassung</li> 	<li>Dank</li> </ol>','Altes Schulhaus, Sportwil',1,1),(2,224,1634111837,1624431427,1,0,0,0,0,NULL,'a:18:{s:5:\"title\";N;s:4:\"slug\";N;s:9:\"startdate\";N;s:7:\"enddate\";N;s:6:\"teaser\";N;s:11:\"description\";N;s:7:\"program\";N;s:4:\"link\";N;s:8:\"location\";N;s:5:\"price\";N;s:6:\"images\";N;s:5:\"files\";N;s:13:\"member_groups\";N;s:13:\"registrations\";N;s:5:\"notes\";N;s:6:\"guests\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;}',0,0,0,0,0,0,0,'event2',1,4,1,0,'event2',1690704000,1690797600,'<p>This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser. This is the teaser.</p>','<p>This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description.</p>\r\n<p>This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description. This is the description.</p>',0,'t3://page?uid=1','<p>This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program. This is the program.</p>','Sunebühel',0,0);
/*!40000 ALTER TABLE `tx_grevman_domain_model_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_grevman_domain_model_group`
--

DROP TABLE IF EXISTS `tx_grevman_domain_model_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_grevman_domain_model_group` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `members` int(10) unsigned NOT NULL DEFAULT 0,
  `events` int(10) unsigned NOT NULL DEFAULT 0,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_grevman_domain_model_group`
--

LOCK TABLES `tx_grevman_domain_model_group` WRITE;
/*!40000 ALTER TABLE `tx_grevman_domain_model_group` DISABLE KEYS */;
INSERT INTO `tx_grevman_domain_model_group` VALUES (1,224,1624893901,1624338555,1,0,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,3,1,'group1'),(2,224,1624893903,1624431273,1,0,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,4,0,'group2');
/*!40000 ALTER TABLE `tx_grevman_domain_model_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_grevman_domain_model_guest`
--

DROP TABLE IF EXISTS `tx_grevman_domain_model_guest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_grevman_domain_model_guest` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_grevman_domain_model_guest`
--

LOCK TABLES `tx_grevman_domain_model_guest` WRITE;
/*!40000 ALTER TABLE `tx_grevman_domain_model_guest` DISABLE KEYS */;
INSERT INTO `tx_grevman_domain_model_guest` VALUES (1,224,1626764780,1624351729,1,0,0,0,0,0,0,NULL,'a:8:{s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:10:\"first_name\";N;s:9:\"last_name\";N;s:5:\"phone\";N;s:5:\"email\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;}',0,0,0,0,0,0,0,'Guest1','Last1','111','info@info.info');
/*!40000 ALTER TABLE `tx_grevman_domain_model_guest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_grevman_domain_model_note`
--

DROP TABLE IF EXISTS `tx_grevman_domain_model_note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_grevman_domain_model_note` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `event` int(10) unsigned NOT NULL DEFAULT 0,
  `text` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `member` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_grevman_domain_model_note`
--

LOCK TABLES `tx_grevman_domain_model_note` WRITE;
/*!40000 ALTER TABLE `tx_grevman_domain_model_note` DISABLE KEYS */;
INSERT INTO `tx_grevman_domain_model_note` VALUES (1,224,1634113031,1624356562,1,0,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,1,'Testtext',10),(2,224,1634113031,1624706821,0,0,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,1,'dies is ein test',10),(3,224,1634113031,1624706845,0,0,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,1,'ein neuer test',10),(4,224,1634113031,1624951336,0,0,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,1,'Hey, let\'s hack this: <a href=\"javascript:alert(\'send passwords\')\">hacked link</a>',10),(5,224,1634111837,1626765326,0,0,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,2,'Unfortunatly I have to learn for the upcoming exam...! Next time I\'ll join!',10);
/*!40000 ALTER TABLE `tx_grevman_domain_model_note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_grevman_domain_model_registration`
--

DROP TABLE IF EXISTS `tx_grevman_domain_model_registration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_grevman_domain_model_registration` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `event` int(10) unsigned NOT NULL DEFAULT 0,
  `member` int(10) unsigned NOT NULL DEFAULT 0,
  `state` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_grevman_domain_model_registration`
--

LOCK TABLES `tx_grevman_domain_model_registration` WRITE;
/*!40000 ALTER TABLE `tx_grevman_domain_model_registration` DISABLE KEYS */;
INSERT INTO `tx_grevman_domain_model_registration` VALUES (1,224,1634134189,1624356511,1,0,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,1,10,6),(2,224,1634113031,1624521847,1,0,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,1,11,6),(3,224,1634111837,1624521879,1,0,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,2,11,6),(4,224,1634111837,1624537824,1,0,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,2,12,9),(5,224,1634111837,1624555322,0,0,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,2,13,6),(6,224,1634113031,1624602639,0,0,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,1,16,6),(7,224,1634111837,1624951103,0,0,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,2,10,9),(9,224,1634113031,1626856940,0,0,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,1,12,9);
/*!40000 ALTER TABLE `tx_grevman_domain_model_registration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_grevman_event_group_mm`
--

DROP TABLE IF EXISTS `tx_grevman_event_group_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_grevman_event_group_mm` (
  `uid_local` int(10) unsigned NOT NULL DEFAULT 0,
  `uid_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid_local`,`uid_foreign`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_grevman_event_group_mm`
--

LOCK TABLES `tx_grevman_event_group_mm` WRITE;
/*!40000 ALTER TABLE `tx_grevman_event_group_mm` DISABLE KEYS */;
INSERT INTO `tx_grevman_event_group_mm` VALUES (1,1,1,1),(2,2,1,0);
/*!40000 ALTER TABLE `tx_grevman_event_group_mm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_grevman_event_guest_mm`
--

DROP TABLE IF EXISTS `tx_grevman_event_guest_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_grevman_event_guest_mm` (
  `uid_local` int(10) unsigned NOT NULL DEFAULT 0,
  `uid_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid_local`,`uid_foreign`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_grevman_event_guest_mm`
--

LOCK TABLES `tx_grevman_event_guest_mm` WRITE;
/*!40000 ALTER TABLE `tx_grevman_event_guest_mm` DISABLE KEYS */;
INSERT INTO `tx_grevman_event_guest_mm` VALUES (1,1,1,0);
/*!40000 ALTER TABLE `tx_grevman_event_guest_mm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_grevman_group_member_mm`
--

DROP TABLE IF EXISTS `tx_grevman_group_member_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_grevman_group_member_mm` (
  `uid_local` int(10) unsigned NOT NULL DEFAULT 0,
  `uid_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid_local`,`uid_foreign`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_grevman_group_member_mm`
--

LOCK TABLES `tx_grevman_group_member_mm` WRITE;
/*!40000 ALTER TABLE `tx_grevman_group_member_mm` DISABLE KEYS */;
INSERT INTO `tx_grevman_group_member_mm` VALUES (1,10,1,1),(1,11,2,1),(1,14,3,1),(2,11,1,2),(2,12,2,0),(2,13,3,0),(2,15,4,1);
/*!40000 ALTER TABLE `tx_grevman_group_member_mm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_impexp_presets`
--

DROP TABLE IF EXISTS `tx_impexp_presets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_impexp_presets` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_uid` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `public` smallint(6) NOT NULL DEFAULT 0,
  `item_uid` int(11) NOT NULL DEFAULT 0,
  `preset_data` blob DEFAULT NULL,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `lookup` (`item_uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_impexp_presets`
--

LOCK TABLES `tx_impexp_presets` WRITE;
/*!40000 ALTER TABLE `tx_impexp_presets` DISABLE KEYS */;
INSERT INTO `tx_impexp_presets` VALUES (1,1,'grevman-test',1,0,'a:15:{s:8:\"pagetree\";a:3:{s:2:\"id\";s:1:\"0\";s:6:\"levels\";s:3:\"999\";s:6:\"tables\";a:9:{i:0;s:14:\"backend_layout\";i:1;s:9:\"be_groups\";i:2;s:8:\"be_users\";i:3;s:9:\"fe_groups\";i:4;s:8:\"fe_users\";i:5;s:12:\"sys_language\";i:6;s:12:\"sys_template\";i:7;s:10:\"tt_content\";i:8;s:29:\"tx_grevman_domain_model_event\";}}s:12:\"external_ref\";a:1:{s:6:\"tables\";a:1:{i:0;s:4:\"_ALL\";}}s:15:\"external_static\";a:1:{s:6:\"tables\";s:0:\"\";}s:19:\"showStaticRelations\";s:0:\"\";s:15:\"excludeDisabled\";s:1:\"1\";s:20:\"download_export_name\";s:14:\"tree_PID0_L999\";s:6:\"preset\";a:2:{s:5:\"title\";s:12:\"grevman-test\";s:6:\"public\";i:1;}s:4:\"meta\";a:3:{s:5:\"title\";s:0:\"\";s:11:\"description\";s:0:\"\";s:5:\"notes\";s:0:\"\";}s:8:\"filetype\";s:3:\"xml\";s:8:\"filename\";s:0:\"\";s:24:\"excludeHTMLfileResources\";s:0:\"\";s:26:\"saveFilesOutsideExportFile\";s:0:\"\";s:13:\"extension_dep\";s:0:\"\";s:10:\"softrefCfg\";a:2:{s:32:\"1c8d070c152eeab20233c19daf5679df\";a:1:{s:4:\"mode\";s:0:\"\";}s:32:\"f992614796c62361b6d1a023a4f61baa\";a:1:{s:4:\"mode\";s:0:\"\";}}s:7:\"exclude\";a:0:{}}',0,1634550886,1634550886),(2,1,'grevman-test-static',1,0,'a:15:{s:8:\"pagetree\";a:3:{s:2:\"id\";s:1:\"0\";s:6:\"levels\";s:3:\"999\";s:6:\"tables\";a:18:{i:0;s:14:\"backend_layout\";i:1;s:9:\"be_groups\";i:2;s:8:\"be_users\";i:3;s:9:\"fe_groups\";i:4;s:8:\"fe_users\";i:5;s:8:\"sys_file\";i:6;s:17:\"sys_file_metadata\";i:7;s:18:\"sys_file_reference\";i:8;s:16:\"sys_file_storage\";i:9;s:14:\"sys_filemounts\";i:10;s:12:\"sys_language\";i:11;s:12:\"sys_template\";i:12;s:10:\"tt_content\";i:13;s:29:\"tx_grevman_domain_model_event\";i:14;s:29:\"tx_grevman_domain_model_group\";i:15;s:29:\"tx_grevman_domain_model_guest\";i:16;s:28:\"tx_grevman_domain_model_note\";i:17;s:36:\"tx_grevman_domain_model_registration\";}}s:12:\"external_ref\";a:1:{s:6:\"tables\";s:0:\"\";}s:15:\"external_static\";a:1:{s:6:\"tables\";a:1:{i:0;s:4:\"_ALL\";}}s:19:\"showStaticRelations\";s:1:\"1\";s:15:\"excludeDisabled\";s:1:\"1\";s:20:\"download_export_name\";s:14:\"tree_PID0_L999\";s:6:\"preset\";a:2:{s:5:\"title\";s:19:\"grevman-test-static\";s:6:\"public\";i:1;}s:4:\"meta\";a:3:{s:5:\"title\";s:0:\"\";s:11:\"description\";s:0:\"\";s:5:\"notes\";s:0:\"\";}s:8:\"filetype\";s:3:\"xml\";s:8:\"filename\";s:8:\"test.xml\";s:24:\"excludeHTMLfileResources\";s:0:\"\";s:26:\"saveFilesOutsideExportFile\";s:0:\"\";s:13:\"extension_dep\";s:0:\"\";s:10:\"softrefCfg\";a:2:{s:32:\"1c8d070c152eeab20233c19daf5679df\";a:1:{s:4:\"mode\";s:0:\"\";}s:32:\"f992614796c62361b6d1a023a4f61baa\";a:1:{s:4:\"mode\";s:0:\"\";}}s:7:\"exclude\";a:0:{}}',0,1634559000,1634559000);
/*!40000 ALTER TABLE `tx_impexp_presets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_scheduler_task`
--

DROP TABLE IF EXISTS `tx_scheduler_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_scheduler_task` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `nextexecution` int(10) unsigned NOT NULL DEFAULT 0,
  `lastexecution_time` int(10) unsigned NOT NULL DEFAULT 0,
  `lastexecution_failure` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastexecution_context` varchar(3) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `serialized_task_object` mediumblob DEFAULT NULL,
  `serialized_executions` mediumblob DEFAULT NULL,
  `task_group` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `index_nextexecution` (`nextexecution`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_scheduler_task`
--

LOCK TABLES `tx_scheduler_task` WRITE;
/*!40000 ALTER TABLE `tx_scheduler_task` DISABLE KEYS */;
INSERT INTO `tx_scheduler_task` VALUES (1,1634548145,1,0,'',0,1634549575,'','BE','O:48:\"TYPO3\\CMS\\Scheduler\\Task\\FileStorageIndexingTask\":10:{s:10:\"storageUid\";i:1;s:12:\"\0*\0scheduler\";N;s:10:\"\0*\0taskUid\";i:1;s:11:\"\0*\0disabled\";b:1;s:19:\"\0*\0runOnNextCronJob\";b:0;s:12:\"\0*\0execution\";O:29:\"TYPO3\\CMS\\Scheduler\\Execution\":6:{s:8:\"\0*\0start\";i:1634548107;s:6:\"\0*\0end\";i:1634548107;s:11:\"\0*\0interval\";i:0;s:11:\"\0*\0multiple\";i:0;s:10:\"\0*\0cronCmd\";s:0:\"\";s:23:\"\0*\0isNewSingleExecution\";b:0;}s:16:\"\0*\0executionTime\";i:1634548107;s:14:\"\0*\0description\";s:0:\"\";s:12:\"\0*\0taskGroup\";i:0;s:9:\"\0*\0logger\";N;}','',0),(2,1634548426,1,0,'',0,1634549579,'','BE','O:54:\"TYPO3\\CMS\\Scheduler\\Task\\RecyclerGarbageCollectionTask\":10:{s:12:\"numberOfDays\";i:30;s:12:\"\0*\0scheduler\";N;s:10:\"\0*\0taskUid\";i:2;s:11:\"\0*\0disabled\";b:1;s:19:\"\0*\0runOnNextCronJob\";b:0;s:12:\"\0*\0execution\";O:29:\"TYPO3\\CMS\\Scheduler\\Execution\":6:{s:8:\"\0*\0start\";i:1634548400;s:6:\"\0*\0end\";i:1634548400;s:11:\"\0*\0interval\";i:0;s:11:\"\0*\0multiple\";i:0;s:10:\"\0*\0cronCmd\";s:0:\"\";s:23:\"\0*\0isNewSingleExecution\";b:0;}s:16:\"\0*\0executionTime\";i:1634548400;s:14:\"\0*\0description\";s:0:\"\";s:12:\"\0*\0taskGroup\";i:0;s:9:\"\0*\0logger\";N;}','',0),(3,1634550162,1,0,'',0,1634550227,'','BE','O:50:\"TYPO3\\CMS\\Scheduler\\Task\\FileStorageExtractionTask\":11:{s:10:\"storageUid\";i:1;s:12:\"maxFileCount\";i:100;s:12:\"\0*\0scheduler\";N;s:10:\"\0*\0taskUid\";i:3;s:11:\"\0*\0disabled\";b:1;s:19:\"\0*\0runOnNextCronJob\";b:0;s:12:\"\0*\0execution\";O:29:\"TYPO3\\CMS\\Scheduler\\Execution\":6:{s:8:\"\0*\0start\";i:1634550147;s:6:\"\0*\0end\";i:1634550147;s:11:\"\0*\0interval\";i:0;s:11:\"\0*\0multiple\";i:0;s:10:\"\0*\0cronCmd\";s:0:\"\";s:23:\"\0*\0isNewSingleExecution\";b:0;}s:16:\"\0*\0executionTime\";i:1634550147;s:14:\"\0*\0description\";s:0:\"\";s:12:\"\0*\0taskGroup\";i:0;s:9:\"\0*\0logger\";N;}','',0);
/*!40000 ALTER TABLE `tx_scheduler_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_scheduler_task_group`
--

DROP TABLE IF EXISTS `tx_scheduler_task_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_scheduler_task_group` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `groupName` varchar(80) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_scheduler_task_group`
--

LOCK TABLES `tx_scheduler_task_group` WRITE;
/*!40000 ALTER TABLE `tx_scheduler_task_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_scheduler_task_group` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-10-19 17:17:18
